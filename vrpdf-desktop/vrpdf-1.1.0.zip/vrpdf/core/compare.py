"""Comparar duas versões de um PDF: diferenças de texto realçadas num relatório PDF."""
from __future__ import annotations

import difflib
from pathlib import Path

import pymupdf

from .util import unique_path


def _words(page):
    return [(w[4], pymupdf.Rect(w[:4])) for w in page.get_text("words", sort=True)]


def compare(old_path: str, new_path: str, dst: str | None = None) -> tuple[Path, dict]:
    """Gera um PDF com as duas versões lado a lado:
    a vermelho o que saiu (na versão antiga), a verde o que entrou (na nova)."""
    a = pymupdf.open(old_path)
    b = pymupdf.open(new_path)
    out = pymupdf.open()
    stats = {"removidas": 0, "acrescentadas": 0, "paginas_alteradas": 0, "paginas": max(a.page_count, b.page_count)}
    red, green = (0.85, 0.15, 0.15), (0.1, 0.6, 0.3)
    for i in range(stats["paginas"]):
        pa = a[i] if i < a.page_count else None
        pb = b[i] if i < b.page_count else None
        wa = _words(pa) if pa else []
        wb = _words(pb) if pb else []
        sm = difflib.SequenceMatcher(a=[w for w, _ in wa], b=[w for w, _ in wb], autojunk=False)
        del_r, add_r = [], []
        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag in ("replace", "delete"):
                del_r += [r for _, r in wa[i1:i2]]
            if tag in ("replace", "insert"):
                add_r += [r for _, r in wb[j1:j2]]
        stats["removidas"] += len(del_r)
        stats["acrescentadas"] += len(add_r)
        if del_r or add_r or (pa is None) != (pb is None):
            stats["paginas_alteradas"] += 1
        ref = pa or pb
        w, h = ref.rect.width, ref.rect.height
        gap = 20
        page = out.new_page(width=2 * w + gap, height=h + 40)
        page.insert_text((10, 24), f"Página {i + 1}   Antiga: {Path(old_path).name}", fontsize=10, color=red)
        page.insert_text((w + gap + 10, 24), f"Nova: {Path(new_path).name}", fontsize=10, color=green)
        left = pymupdf.Rect(0, 40, w, 40 + h)
        right = pymupdf.Rect(w + gap, 40, 2 * w + gap, 40 + h)
        if pa:
            page.show_pdf_page(left, a, i)
        if pb:
            page.show_pdf_page(right, b, i)
        for r in del_r:
            rr = pymupdf.Rect(r.x0, r.y0 + 40, r.x1, r.y1 + 40)
            annot = page.add_highlight_annot(rr)
            annot.set_colors(stroke=(1, 0.55, 0.55))
            annot.update()
        for r in add_r:
            rr = pymupdf.Rect(r.x0 + w + gap, r.y0 + 40, r.x1 + w + gap, r.y1 + 40)
            annot = page.add_highlight_annot(rr)
            annot.set_colors(stroke=(0.55, 0.95, 0.6))
            annot.update()
    dst = Path(dst) if dst else unique_path(Path(new_path).with_name(f"Comparação - {Path(new_path).stem}.pdf"))
    out.save(dst, garbage=3, deflate=True)
    out.close()
    a.close()
    b.close()
    return dst, stats
