"""Edição de conteúdo: texto, imagens, tapar, rasurar, cabeçalhos/rodapés, marcas d'água."""
from __future__ import annotations

import datetime as _dt
import os
import sys
from dataclasses import dataclass

import pymupdf


# ------------------------------------------------------------------ fontes
def _win_fonts() -> str:
    return os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")


FONT_FILES = {
    # nome visível: (normal, negrito, itálico, negrito+itálico)
    "Arial": ("arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf"),
    "Calibri": ("calibri.ttf", "calibrib.ttf", "calibrii.ttf", "calibriz.ttf"),
    "Times New Roman": ("times.ttf", "timesbd.ttf", "timesi.ttf", "timesbi.ttf"),
    "Verdana": ("verdana.ttf", "verdanab.ttf", "verdanai.ttf", "verdanaz.ttf"),
    "Courier New": ("cour.ttf", "courbd.ttf", "couri.ttf", "courbi.ttf"),
    "Cambria": ("cambria.ttc", "cambriab.ttf", "cambriai.ttf", "cambriaz.ttf"),
}
BASE14 = {
    "Arial": ("helv", "hebo", "heit", "hebi"),
    "Calibri": ("helv", "hebo", "heit", "hebi"),
    "Verdana": ("helv", "hebo", "heit", "hebi"),
    "Times New Roman": ("tiro", "tibo", "tiit", "tibi"),
    "Cambria": ("tiro", "tibo", "tiit", "tibi"),
    "Courier New": ("cour", "cobo", "coit", "cobi"),
}


def font_names() -> list[str]:
    return list(FONT_FILES)


def _style_idx(bold: bool, italic: bool) -> int:
    return (1 if bold else 0) + (2 if italic else 0)


def resolve_font(family: str, bold=False, italic=False) -> tuple[str, str | None]:
    """Devolve (fontname para o PDF, ficheiro TTF ou None se base-14)."""
    fam = family if family in FONT_FILES else _guess_family(family)
    idx = _style_idx(bold, italic)
    fpath = os.path.join(_win_fonts(), FONT_FILES[fam][idx])
    if os.path.isfile(fpath):
        tag = ("F" + fam.replace(" ", "") + str(idx))[:30]
        return tag, fpath
    # tentar fontes do Linux (para testes)
    for cand in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                 "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"):
        if os.path.isfile(cand) and fam in ("Arial", "Calibri", "Verdana") and idx == 0:
            return "FLinuxSans", cand
    return BASE14[fam][idx], None


def _guess_family(pdf_font_name: str) -> str:
    n = (pdf_font_name or "").lower()
    if "calibri" in n:
        return "Calibri"
    if "cambria" in n:
        return "Cambria"
    if "times" in n or "serif" in n and "sans" not in n or "roman" in n or "georgia" in n:
        return "Times New Roman"
    if "courier" in n or "mono" in n or "consol" in n:
        return "Courier New"
    if "verdana" in n or "tahoma" in n:
        return "Verdana"
    return "Arial"


def _hex_to_rgb(c) -> tuple[float, float, float]:
    if isinstance(c, (tuple, list)):
        return tuple(float(x) for x in c[:3])
    if isinstance(c, int):
        return ((c >> 16 & 255) / 255, (c >> 8 & 255) / 255, (c & 255) / 255)
    c = str(c).lstrip("#")
    return (int(c[0:2], 16) / 255, int(c[2:4], 16) / 255, int(c[4:6], 16) / 255)


# ------------------------------------------------------------------ localizar texto
@dataclass
class TextLine:
    page: int
    rect: pymupdf.Rect
    text: str
    font: str
    size: float
    color: tuple
    bold: bool
    italic: bool
    origin: pymupdf.Point


def lines_on_page(page) -> list[TextLine]:
    res = []
    d = page.get_text("dict", flags=pymupdf.TEXT_PRESERVE_WHITESPACE)
    for b in d["blocks"]:
        for l in b.get("lines", []):
            spans = [s for s in l.get("spans", []) if s["text"]]
            if not spans:
                continue
            text = "".join(s["text"] for s in spans)
            if not text.strip():
                continue
            main = max(spans, key=lambda s: len(s["text"].strip()))
            r = pymupdf.Rect(l["bbox"])
            fl = main["flags"]
            res.append(TextLine(page.number, r, text, main["font"], main["size"],
                                _hex_to_rgb(main["color"]), bool(fl & 16) or "bold" in main["font"].lower(),
                                bool(fl & 2) or "italic" in main["font"].lower() or "oblique" in main["font"].lower(),
                                pymupdf.Point(spans[0]["origin"])))
    return res


def line_at(page, point) -> TextLine | None:
    pt = pymupdf.Point(point)
    best = None
    for ln in lines_on_page(page):
        r = ln.rect + (-2, -2, 2, 2)
        if r.contains(pt):
            if best is None or ln.rect.get_area() < best.rect.get_area():
                best = ln
    return best


# ------------------------------------------------------------------ edição de texto
def replace_line(page, line: TextLine, new_text: str, family: str | None = None,
                 size: float | None = None, color=None, bold=None, italic=None) -> None:
    """Substitui uma linha de texto: apaga a original (só o texto) e escreve a nova com a fonte mais próxima."""
    fam = family or _guess_family(line.font)
    b = line.bold if bold is None else bold
    it = line.italic if italic is None else italic
    sz = size or line.size
    col = _hex_to_rgb(color) if color is not None else line.color
    page.add_redact_annot(line.rect, fill=False)
    page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE,
                          text=pymupdf.PDF_REDACT_TEXT_REMOVE)
    if not new_text:
        return
    fontname, fontfile = resolve_font(fam, b, it)
    kw = dict(fontname=fontname, fontsize=sz, color=col)
    if fontfile:
        kw["fontfile"] = fontfile
    page.insert_text(line.origin, new_text, **kw)


def find_and_replace(doc, find: str, replace: str, match_case: bool = False, pages=None) -> int:
    """Substitui todas as ocorrências de um texto (palavras ou frases numa linha)."""
    count = 0
    pages = pages if pages is not None else range(doc.page_count)
    for pno in pages:
        page = doc[pno]
        hits = page.search_for(find)
        if not hits:
            continue
        # informação de fonte de cada ocorrência
        infos = []
        lines = lines_on_page(page)
        for r in hits:
            ln = next((l for l in lines if l.rect.intersects(r)), None)
            infos.append((r, ln))
        for r, _ in infos:
            page.add_redact_annot(r, fill=False)
        page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE)
        for r, ln in infos:
            if not replace:
                continue
            if ln:
                fontname, fontfile = resolve_font(_guess_family(ln.font), ln.bold, ln.italic)
                size, col = ln.size, ln.color
                y = ln.origin.y
            else:
                fontname, fontfile = resolve_font("Arial")
                size, col, y = r.height * 0.8, (0, 0, 0), r.y1 - r.height * 0.2
            kw = dict(fontname=fontname, fontsize=size, color=col)
            if fontfile:
                kw["fontfile"] = fontfile
            page.insert_text(pymupdf.Point(r.x0, y), replace, **kw)
            count += 1
    return count


def add_textbox(page, rect, text: str, family="Arial", size=11.0, color="#000000",
                bold=False, italic=False, align: int = 0, background=None) -> None:
    rect = pymupdf.Rect(rect)
    if background:
        page.draw_rect(rect, color=None, fill=_hex_to_rgb(background), overlay=True)
    fontname, fontfile = resolve_font(family, bold, italic)
    kw = dict(fontname=fontname, fontsize=size, color=_hex_to_rgb(color), align=align)
    if fontfile:
        kw["fontfile"] = fontfile
    # aumenta a caixa para baixo se o texto não couber
    r = pymupdf.Rect(rect)
    shape = page.new_shape()
    rc = shape.insert_textbox(r, text, **kw)
    grow = 0
    while rc < 0 and grow < 40:
        grow += 1
        r.y1 += size
        shape = page.new_shape()
        rc = shape.insert_textbox(r, text, **kw)
    shape.commit()


# ------------------------------------------------------------------ imagens
def insert_image(page, rect, path: str | None = None, stream: bytes | None = None, keep_proportion=True) -> int:
    rect = pymupdf.Rect(rect)
    if path:
        return page.insert_image(rect, filename=path, keep_proportion=keep_proportion, overlay=True)
    return page.insert_image(rect, stream=stream, keep_proportion=keep_proportion, overlay=True)


def images_on_page(page) -> list[dict]:
    """[{xref, rect}] das imagens visíveis na página."""
    res = []
    for info in page.get_image_info(xrefs=True):
        if info.get("xref"):
            res.append({"xref": info["xref"], "rect": pymupdf.Rect(info["bbox"])})
    return res


def image_at(page, point) -> dict | None:
    pt = pymupdf.Point(point)
    cands = [i for i in images_on_page(page) if i["rect"].contains(pt)]
    return min(cands, key=lambda i: i["rect"].get_area()) if cands else None


def remove_image_area(page, rect) -> None:
    page.add_redact_annot(pymupdf.Rect(rect), fill=False)
    page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_REMOVE, graphics=pymupdf.PDF_REDACT_LINE_ART_NONE,
                          text=pymupdf.PDF_REDACT_TEXT_NONE)


def move_image(page, img: dict, new_rect) -> None:
    """Move/redimensiona uma imagem: extrai, remove da posição antiga e volta a inserir."""
    doc = page.parent
    pix = pymupdf.Pixmap(doc, img["xref"])
    if pix.alpha == 0:
        try:
            info = doc.extract_image(img["xref"])
            if info.get("smask"):
                pix = pymupdf.Pixmap(pix, pymupdf.Pixmap(doc, info["smask"]))
        except Exception:
            pass
    data = pix.tobytes("png")
    remove_image_area(page, img["rect"])
    page.insert_image(pymupdf.Rect(new_rect), stream=data, keep_proportion=False, overlay=True)


def replace_image(page, img: dict, path: str) -> None:
    r = img["rect"]
    remove_image_area(page, r)
    page.insert_image(r, filename=path, keep_proportion=True, overlay=True)


# ------------------------------------------------------------------ tapar / rasurar
def whiteout(page, rect, color="#FFFFFF") -> None:
    page.draw_rect(pymupdf.Rect(rect), color=None, fill=_hex_to_rgb(color), overlay=True)


def redact_area(page, rect, fill=(0, 0, 0)) -> None:
    """Rasura definitiva: remove texto, imagens e desenhos por baixo."""
    page.add_redact_annot(pymupdf.Rect(rect), fill=fill)
    page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_PIXELS)


def redact_text(doc, needle: str, fill=(0, 0, 0)) -> int:
    n = 0
    for page in doc:
        hits = page.search_for(needle)
        for r in hits:
            page.add_redact_annot(r, fill=fill)
        if hits:
            page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_PIXELS)
            n += len(hits)
    return n


REDACT_PATTERNS = {
    "NIF / NIPC (9 dígitos)": r"\b[125689]\d{8}\b",
    "IBAN": r"\bPT50\s?(?:\d{4}\s?){5}\d\b",
    "Email": r"[\w.+-]+@[\w-]+\.[\w.]+",
    "Telefone": r"\b(?:\+351\s?)?[29]\d{2}\s?\d{3}\s?\d{3}\b",
    "Valores em euros": r"\d{1,3}(?:[.\s’']\d{3})*,\d{2}\s?€|€\s?\d+(?:[.,]\d+)*",
}


def redact_pattern(doc, pattern: str, fill=(0, 0, 0)) -> int:
    """Rasura todas as ocorrências de uma expressão regular (ex.: NIF, IBAN, emails)."""
    import re
    rx = re.compile(pattern)
    n = 0
    for page in doc:
        text = page.get_text()
        found = set(m.group(0) for m in rx.finditer(text))
        hits = []
        for f in found:
            hits += page.search_for(f)
        for r in hits:
            page.add_redact_annot(r, fill=fill)
        if hits:
            page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_PIXELS)
            n += len(hits)
    return n


# ------------------------------------------------------------------ cabeçalho, rodapé, numeração
def _expand(tpl: str, n: int, total: int, filename: str) -> str:
    today = _dt.date.today().strftime("%d/%m/%Y")
    return (tpl.replace("{n}", str(n)).replace("{total}", str(total))
            .replace("{data}", today).replace("{ficheiro}", filename))


def header_footer(doc, *, header_left="", header_center="", header_right="",
                  footer_left="", footer_center="", footer_right="",
                  size=9.0, color="#333333", margin_mm=10.0, family="Arial",
                  pages=None, start_number=1, filename="") -> None:
    """Textos com marcadores: {n} página, {total} nº de páginas, {data}, {ficheiro}."""
    pages = list(pages) if pages is not None else list(range(doc.page_count))
    total = len(pages) + start_number - 1
    fontname, fontfile = resolve_font(family)
    col = _hex_to_rgb(color)
    m = margin_mm * 72 / 25.4
    font = pymupdf.Font(fontfile=fontfile) if fontfile else pymupdf.Font(fontname)
    for k, pno in enumerate(pages):
        page = doc[pno]
        r = page.rect
        n = start_number + k
        rows = [(header_left, header_center, header_right, m + size),
                (footer_left, footer_center, footer_right, r.height - m)]
        for left, center, right, y in rows:
            for txt, al in ((left, 0), (center, 1), (right, 2)):
                if not txt:
                    continue
                s = _expand(txt, n, total, filename)
                w = font.text_length(s, fontsize=size)
                x = m if al == 0 else (r.width - w) / 2 if al == 1 else r.width - m - w
                kw = dict(fontname=fontname, fontsize=size, color=col)
                if fontfile:
                    kw["fontfile"] = fontfile
                # coordenadas não rodadas: compensar rotação da página
                pt = pymupdf.Point(x, y) * page.derotation_matrix
                page.insert_text(pt, s, rotate=page.rotation, **kw)


def watermark_text(doc, text: str, size=60.0, color="#C8302B", opacity=0.18, angle=45.0,
                   family="Arial", bold=True, pages=None) -> None:
    pages = list(pages) if pages is not None else list(range(doc.page_count))
    fontname, fontfile = resolve_font(family, bold=bold)
    font = pymupdf.Font(fontfile=fontfile) if fontfile else pymupdf.Font(fontname)
    for pno in pages:
        page = doc[pno]
        r = page.rect
        w = font.text_length(text, fontsize=size)
        c = pymupdf.Point(r.width / 2, r.height / 2)
        tw = pymupdf.TextWriter(r, opacity=opacity, color=_hex_to_rgb(color))
        tw.append(pymupdf.Point(c.x - w / 2, c.y + size / 3), text, font=font, fontsize=size)
        tw.write_text(page, morph=(c, pymupdf.Matrix(-angle)), overlay=True)


def watermark_image(doc, path: str, opacity=0.2, scale=0.5, pages=None) -> None:
    from PIL import Image
    import io
    im = Image.open(path).convert("RGBA")
    a = im.split()[3].point(lambda v: int(v * opacity))
    im.putalpha(a)
    buf = io.BytesIO()
    im.save(buf, "PNG")
    data = buf.getvalue()
    pages = list(pages) if pages is not None else list(range(doc.page_count))
    for pno in pages:
        page = doc[pno]
        r = page.rect
        w = r.width * scale
        h = w * im.height / im.width
        rect = pymupdf.Rect((r.width - w) / 2, (r.height - h) / 2, (r.width + w) / 2, (r.height + h) / 2)
        page.insert_image(rect, stream=data, overlay=True)
