"""Renomear PDFs pelo conteúdo: data, tipo de documento, número e entidade lidos do próprio PDF."""
from __future__ import annotations

import re
from pathlib import Path

import pymupdf

from .util import unique_path

MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro",
         "outubro", "novembro", "dezembro"]

ENTIDADES = ["Galp", "Petrogal", "EDP", "E-Redes", "Endesa", "Iberdrola", "Goldenergy", "Repsol", "Luzboa",
             "EPAL", "Águas de Portugal", "SIMAS", "SMAS", "Climaespaço", "MEO", "NOS", "Vodafone", "Via Verde",
             "Ventura Rodrigues", "BestAir", "Teixeira Duarte", "Schneider", "ABB", "Legrand", "Hager", "Siemens",
             "Rexel", "Sonepar", "Finanças", "Segurança Social", "DGEG", "Certiel"]

TIPOS = [
    (r"\bnota\s+de\s+cr[ée]dito\b", "Nota de Crédito"),
    (r"\bfatura[\s-]*recibo\b|\bfactura[\s-]*recibo\b", "Fatura-Recibo"),
    (r"\bfatura\b|\bfactura\b|\binvoice\b", "Fatura"),
    (r"\brecibo\b", "Recibo"),
    (r"\bor[çc]amento\b", "Orçamento"),
    (r"\bproposta\b", "Proposta"),
    (r"\bguia\s+de\s+remessa\b", "Guia de Remessa"),
    (r"\bencomenda\b", "Encomenda"),
    (r"\brelat[óo]rio\b", "Relatório"),
    (r"\bcertificado\b", "Certificado"),
    (r"\bcontrato\b", "Contrato"),
    (r"\bauto\s+de\s+medi[çc][ãa]o\b", "Auto de Medição"),
]


def extract_info(path: str, max_pages: int = 2) -> dict:
    doc = pymupdf.open(path)
    text = "\n".join(doc[i].get_text() for i in range(min(max_pages, doc.page_count)))
    doc.close()
    info = {"data": "", "tipo": "", "numero": "", "entidade": "", "nif": ""}
    low = text.lower()

    # data: prefere "Data de emissão", "Data:", senão a primeira data válida
    m = re.search(r"data(?:\s+de\s+emiss[ãa]o|\s+do\s+documento)?\s*[:\-]?\s*(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})", low)
    if not m:
        m = re.search(r"\b(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})\b", text)
    if m:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            info["data"] = f"{y:04d}-{mo:02d}-{d:02d}"
    if not info["data"]:
        m = re.search(r"\b(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})\b", text)
        if m:
            info["data"] = f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    if not info["data"]:
        m = re.search(r"(\d{1,2})\s+de\s+(" + "|".join(MESES) + r")\s+de\s+(\d{4})", low)
        if m:
            info["data"] = f"{int(m.group(3)):04d}-{MESES.index(m.group(2)) + 1:02d}-{int(m.group(1)):02d}"

    for rx, nome in TIPOS:
        if re.search(rx, low):
            info["tipo"] = nome
            break

    # número: "Fatura nº FT 2026/123", "N.º Documento: ...", "Proposta nº 5330/26", código AT "FT A/123"
    pats = [r"\b(F[TRS]|NC|ND|FR|GR|OR)\s?[A-Z0-9]{0,6}\s?/\s?\d+\b",
            r"(?:fatura|factura|proposta|or[çc]amento|documento|recibo|encomenda)\s*(?:n\.?\s?[ºo°]|nr\.?|n[úu]mero)\s*[:\-]?\s*([A-Z0-9][\w/\-.]{1,30})",
            r"\bn\.?\s?[ºo°]\s*(?:do\s+documento)?\s*[:\-]?\s*([A-Z0-9][\w/\-.]{2,30})"]
    for k, rx in enumerate(pats):
        m = re.search(rx, text, re.I)
        if m:
            num = (m.group(0) if k == 0 else m.group(1)).strip().rstrip(".")
            info["numero"] = re.sub(r"\s+", " ", num)
            break

    for ent in ENTIDADES:
        if re.search(r"\b" + re.escape(ent) + r"\b", text, re.I):
            info["entidade"] = ent
            break
    if not info["entidade"]:
        m = re.search(r"\b([A-ZÀ-Ý][\wÀ-ÿ&.\- ]{2,40}?)\s*,?\s*(?:Lda|S\.?A\.?|Unipessoal)\b", text)
        if m:
            info["entidade"] = m.group(1).strip()
    m = re.search(r"(?:NIF|NIPC|Contribuinte)\s*(?:n\.?\s?[ºo°])?\s*[:\-]?\s*(?:PT)?\s*(\d{9})", text, re.I)
    if m:
        info["nif"] = m.group(1)
    return info


def build_name(info: dict, template: str = "{data} {tipo} {numero} {entidade}") -> str:
    name = template
    for k, v in info.items():
        name = name.replace("{" + k + "}", v or "")
    name = re.sub(r'[\\/:*?"<>|]+', "-", name)
    name = re.sub(r"\s+", " ", name).strip(" -_")
    return name


def propose(paths: list[str], template: str) -> list[tuple[str, str]]:
    """Devolve [(caminho original, novo nome sugerido)]."""
    res = []
    for p in paths:
        try:
            info = extract_info(p)
            new = build_name(info, template)
        except Exception:
            new = ""
        res.append((p, (new or Path(p).stem) + ".pdf"))
    return res


def apply(pairs: list[tuple[str, str]]) -> list[Path]:
    out = []
    for src, new_name in pairs:
        s = Path(src)
        if not new_name or new_name == s.name:
            out.append(s)
            continue
        dst = unique_path(s.with_name(new_name))
        s.rename(dst)
        out.append(dst)
    return out
