"""Assinaturas: manuscrita (imagem), digital com certificado (.pfx) e Cartão de Cidadão (PKCS#11)."""
from __future__ import annotations

import io
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pymupdf

from .util import app_data_dir, unique_path

SIG_DIR = app_data_dir() / "assinaturas"


# ---------------------------------------------------------------- manuscrita
def saved_signatures() -> list[Path]:
    SIG_DIR.mkdir(parents=True, exist_ok=True)
    return sorted(SIG_DIR.glob("*.png"))


def save_signature_png(data: bytes, name: str = "assinatura") -> Path:
    SIG_DIR.mkdir(parents=True, exist_ok=True)
    p = unique_path(SIG_DIR / f"{name}.png")
    p.write_bytes(data)
    return p


def clean_signature_image(path: str) -> bytes:
    """Imagem de assinatura digitalizada -> fundo transparente, traço azul escuro ou preto."""
    from PIL import Image, ImageOps
    im = Image.open(path).convert("L")
    im = ImageOps.autocontrast(im)
    alpha = im.point(lambda v: 255 - v if v < 200 else 0)
    ink = Image.new("RGBA", im.size, (20, 30, 90, 255))
    ink.putalpha(alpha)
    bbox = alpha.getbbox()
    if bbox:
        ink = ink.crop(bbox)
    buf = io.BytesIO()
    ink.save(buf, "PNG")
    return buf.getvalue()


def place_signature(page, rect, png_path: str) -> None:
    page.insert_image(pymupdf.Rect(rect), filename=png_path, keep_proportion=True, overlay=True)


# ---------------------------------------------------------------- digital (pyHanko)
def _visible_field_spec(page_no: int, rect, name: str):
    from pyhanko.sign.fields import SigFieldSpec
    r = pymupdf.Rect(rect)
    return SigFieldSpec(sig_field_name=name, on_page=page_no, box=(r.x0, r.y0, r.x1, r.y1))


def _pdf_box(doc_path: str, page_no: int, rect):
    """Converte o retângulo (coordenadas do ecrã, origem em cima) para coordenadas PDF (origem em baixo)."""
    d = pymupdf.open(doc_path)
    page = d[page_no]
    r = pymupdf.Rect(rect) * ~page.transformation_matrix  # ecrã (MuPDF) -> espaço PDF
    d.close()
    r.normalize()
    return (r.x0, r.y0, r.x1, r.y1)


def sign_with_pfx(src: str, dst: str, pfx_path: str, password: str, page_no: int = 0,
                  rect=None, reason: str = "Aprovação", location: str = "Portugal", name: str | None = None) -> Path:
    from pyhanko.sign import signers, fields
    from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
    from pyhanko.sign.fields import SigFieldSpec
    signer = signers.SimpleSigner.load_pkcs12(pfx_file=pfx_path, passphrase=password.encode() if password else None)
    if signer is None:
        raise RuntimeError("Não consegui abrir o certificado. Confirma a palavra-passe do ficheiro .pfx.")
    return _do_sign(src, dst, signer, page_no, rect, reason, location, name)


def _do_sign(src, dst, signer, page_no, rect, reason, location, name):
    from pyhanko.sign import signers, fields
    from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
    from pyhanko.sign.fields import SigFieldSpec
    from pyhanko import stamp
    field_name = "Assinatura" + str(abs(hash((src, page_no))) % 10000)
    dst = Path(dst)
    with open(src, "rb") as f:
        w = IncrementalPdfFileWriter(f, strict=False)
        box = _pdf_box(src, page_no, rect) if rect is not None else None
        if box:
            fields.append_signature_field(w, SigFieldSpec(sig_field_name=field_name, on_page=page_no, box=box))
        meta = signers.PdfSignatureMetadata(field_name=field_name, reason=reason, location=location, name=name)
        style = stamp.TextStampStyle(stamp_text="Assinado digitalmente por:\n%(signer)s\nData: %(ts)s",
                                     border_width=1)
        pdf_signer = signers.PdfSigner(meta, signer=signer, stamp_style=style)
        with open(dst, "wb") as out:
            pdf_signer.sign_pdf(w, output=out)
    return dst


# ---------------------------------------------------------------- Cartão de Cidadão
def cc_pkcs11_lib() -> str | None:
    cands = [
        os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "System32", "pteidpkcs11.dll"),
        r"C:\Program Files\Portugal Identity Card\pteidpkcs11.dll",
        "/usr/local/lib/libpteidpkcs11.so", "/usr/lib/libpteidpkcs11.so",
    ]
    for c in cands:
        if os.path.isfile(c):
            return c
    return None


def sign_with_cc(src: str, dst: str, page_no: int = 0, rect=None, reason: str = "Aprovação",
                 location: str = "Portugal", pin: str | None = None) -> Path:
    """Assinatura qualificada com o Cartão de Cidadão (precisa do leitor e do Autenticação.gov instalado).
    O PIN de assinatura é pedido pelo próprio middleware quando não é passado."""
    lib = cc_pkcs11_lib()
    if not lib:
        raise RuntimeError("Não encontrei o middleware do Cartão de Cidadão. Instala a aplicação Autenticação.gov "
                           "(www.autenticacao.gov.pt) e liga o leitor de cartões.")
    from pyhanko.sign import pkcs11 as p11
    session = p11.open_pkcs11_session(lib, slot_no=None, token_label=None, user_pin=pin)
    try:
        signer = p11.PKCS11Signer(session, cert_label="CITIZEN SIGNATURE CERTIFICATE",
                                  key_label="CITIZEN SIGNATURE KEY",
                                  other_certs_to_pull=None, bulk_fetch=False)
        return _do_sign(src, dst, signer, page_no, rect, reason, location, None)
    finally:
        try:
            session.close()
        except Exception:
            pass


def autenticacao_gov_exe() -> str | None:
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", "")):
        if not base:
            continue
        for sub in ("Portugal Identity Card", "Autenticação.gov", "Autenticacao.gov"):
            for exe in ("pteidgui.exe", "eidguiV2.exe"):
                p = os.path.join(base, sub, exe)
                if os.path.isfile(p):
                    return p
    return shutil.which("eidguiV2") or shutil.which("pteidgui")


def open_in_autenticacao_gov(pdf_path: str) -> bool:
    """Para Chave Móvel Digital: abre a aplicação oficial, onde se escolhe 'Assinar' com CMD."""
    exe = autenticacao_gov_exe()
    if not exe:
        return False
    subprocess.Popen([exe, pdf_path])
    return True


def verify_signatures(path: str) -> list[dict]:
    from pyhanko.pdf_utils.reader import PdfFileReader
    from pyhanko.sign.validation import validate_pdf_signature
    res = []
    with open(path, "rb") as f:
        r = PdfFileReader(f, strict=False)
        for s in r.embedded_signatures:
            try:
                st = validate_pdf_signature(s)
                res.append({"campo": s.field_name, "assinante": st.signing_cert.subject.human_friendly,
                            "intacto": st.intact, "valido": st.valid, "data": str(getattr(st, "signer_reported_dt", ""))})
            except Exception as e:
                res.append({"campo": s.field_name, "erro": str(e)})
    return res
