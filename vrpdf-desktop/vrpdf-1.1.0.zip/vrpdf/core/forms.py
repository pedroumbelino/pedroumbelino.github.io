"""Formulários PDF: listar, preencher e criar campos."""
from __future__ import annotations

import pymupdf

FIELD_TYPES = {
    "Texto": pymupdf.PDF_WIDGET_TYPE_TEXT,
    "Caixa de seleção": pymupdf.PDF_WIDGET_TYPE_CHECKBOX,
    "Lista pendente": pymupdf.PDF_WIDGET_TYPE_COMBOBOX,
    "Opção (rádio)": pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON,
    "Assinatura": pymupdf.PDF_WIDGET_TYPE_SIGNATURE,
}


def list_fields(doc) -> list[dict]:
    res = []
    for page in doc:
        for w in page.widgets() or []:
            res.append({
                "page": page.number, "name": w.field_name, "type": w.field_type_string,
                "value": w.field_value, "options": list(w.choice_values or []), "rect": w.rect, "xref": w.xref,
                "on_state": w.on_state() if w.field_type in (pymupdf.PDF_WIDGET_TYPE_CHECKBOX, pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON) else None,
            })
    return res


def set_field(doc, page_no: int, xref: int, value) -> bool:
    page = doc[page_no]
    for w in page.widgets() or []:
        if w.xref == xref:
            if w.field_type in (pymupdf.PDF_WIDGET_TYPE_CHECKBOX, pymupdf.PDF_WIDGET_TYPE_RADIOBUTTON):
                w.field_value = w.on_state() if value in (True, "Sim", "sim", "1", 1, "On", w.on_state()) else "Off"
            else:
                w.field_value = "" if value is None else str(value)
            w.update()
            return True
    return False


def add_field(page, rect, kind: str, name: str, options: list[str] | None = None,
              value: str = "", fontsize: float = 10) -> None:
    w = pymupdf.Widget()
    w.field_type = FIELD_TYPES[kind]
    w.field_name = name
    w.rect = pymupdf.Rect(rect)
    w.text_fontsize = fontsize
    w.border_color = (0.4, 0.45, 0.55)
    w.border_width = 0.8
    w.fill_color = (0.94, 0.96, 1.0)
    if kind == "Lista pendente":
        w.choice_values = options or ["Opção 1", "Opção 2"]
        w.field_value = value or w.choice_values[0]
    elif kind in ("Caixa de seleção", "Opção (rádio)"):
        w.field_value = False
    elif kind == "Texto":
        w.field_value = value
    page.add_widget(w)


def flatten(doc) -> None:
    """Torna os campos preenchidos em conteúdo fixo (deixa de ser editável)."""
    try:
        doc.bake(annots=False, widgets=True)
    except Exception:
        # versões antigas: converter em PDF de novo
        pdfbytes = doc.convert_to_pdf()
        tmp = pymupdf.open("pdf", pdfbytes)
        doc.insert_pdf(tmp)
