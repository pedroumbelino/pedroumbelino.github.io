"""Utilitários partilhados: caminhos, nomes de saída, deteção de ferramentas externas."""
from __future__ import annotations

import os
import sys
import shutil
from pathlib import Path

APP_NAME = "VR PDF"
APP_VERSION = "1.1.0"


def resource_path(*parts: str) -> Path:
    """Caminho para recursos empacotados (funciona dentro do .exe do PyInstaller)."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    return base.joinpath(*parts)


def app_data_dir() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path.home() / ".config"
    d = base / "VR PDF"
    d.mkdir(parents=True, exist_ok=True)
    return d


def unique_path(path: str | Path) -> Path:
    """Devolve um caminho que ainda não existe (acrescenta (2), (3)...)."""
    p = Path(path)
    if not p.exists():
        return p
    i = 2
    while True:
        cand = p.with_name(f"{p.stem} ({i}){p.suffix}")
        if not cand.exists():
            return cand
        i += 1


def out_path(src: str | Path, suffix: str, tag: str = "", out_dir: str | Path | None = None) -> Path:
    """Nome de saída ao lado do original, sem sobrescrever."""
    s = Path(src)
    d = Path(out_dir) if out_dir else s.parent
    name = s.stem + (f" {tag}" if tag else "") + suffix
    return unique_path(d / name)


def find_tesseract() -> str | None:
    """Procura o Tesseract OCR (instalado pelo COMPILAR.bat ou pelo utilizador)."""
    cands = []
    exe = shutil.which("tesseract")
    if exe:
        cands.append(exe)
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                 os.environ.get("LOCALAPPDATA", "")):
        if base:
            cands.append(os.path.join(base, "Tesseract-OCR", "tesseract.exe"))
            cands.append(os.path.join(base, "Programs", "Tesseract-OCR", "tesseract.exe"))
    bundled = resource_path("tesseract", "tesseract.exe")
    cands.insert(0, str(bundled))
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return None


def tessdata_dir() -> str | None:
    """Pasta tessdata com por.traineddata, se existir."""
    env = os.environ.get("TESSDATA_PREFIX")
    cands = []
    if env:
        cands.append(env)
    cands.insert(0, str(resource_path("tessdata")))
    cands.append(str(app_data_dir() / "tessdata"))
    exe = find_tesseract()
    if exe:
        cands.append(os.path.join(os.path.dirname(exe), "tessdata"))
    cands += ["/usr/share/tesseract-ocr/5/tessdata", "/usr/share/tesseract-ocr/4.00/tessdata", "/usr/share/tessdata"]
    for c in cands:
        if c and (os.path.isfile(os.path.join(c, "por.traineddata")) or os.path.isfile(os.path.join(c, "eng.traineddata"))):
            return c
    return None


def ocr_languages() -> str:
    d = tessdata_dir()
    if not d:
        return "por"
    langs = [l for l in ("por", "eng") if os.path.isfile(os.path.join(d, f"{l}.traineddata"))]
    return "+".join(langs) or "eng"


def parse_page_ranges(text: str, page_count: int) -> list[int]:
    """'1-3, 5, 8-' -> índices 0-based. Páginas fora do documento são ignoradas."""
    pages: list[int] = []
    text = (text or "").replace(";", ",").replace(" ", "")
    if not text:
        return list(range(page_count))
    for part in text.split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start = int(a) if a else 1
            end = int(b) if b else page_count
            if start > end:
                start, end = end, start
            pages.extend(range(start - 1, min(end, page_count)))
        else:
            n = int(part)
            if 1 <= n <= page_count:
                pages.append(n - 1)
    seen = set()
    result = []
    for p in pages:
        if 0 <= p < page_count and p not in seen:
            seen.add(p)
            result.append(p)
    return result
