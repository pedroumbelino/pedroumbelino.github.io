"""Juntar, dividir, reorganizar e comprimir PDFs."""
from __future__ import annotations

import io
from pathlib import Path

import pymupdf

from .util import unique_path, out_path


def merge(paths: list[str], dst: str, bookmarks: bool = True, progress=None) -> Path:
    out = pymupdf.open()
    toc = []
    for k, p in enumerate(paths):
        if progress:
            progress(k, len(paths), Path(p).name)
        src = pymupdf.open(p)
        start = out.page_count
        out.insert_pdf(src)
        if bookmarks:
            toc.append([1, Path(p).stem, start + 1])
            for lvl, title, page, *_ in src.get_toc():
                toc.append([lvl + 1, title, start + page])
        src.close()
    if bookmarks and toc:
        try:
            out.set_toc(toc)
        except Exception:
            pass
    dst = unique_path(dst)
    out.save(dst, garbage=3, deflate=True)
    out.close()
    return dst


def split(src: str, mode: str, value: str | int, out_dir: str | None = None) -> list[Path]:
    """mode: 'cada' (página a página), 'n' (a cada N páginas), 'intervalos' ('1-3,4-6'), 'tamanho' (MB)."""
    doc = pymupdf.open(src)
    base = Path(src)
    od = Path(out_dir) if out_dir else base.parent
    groups: list[list[int]] = []
    n = doc.page_count
    if mode == "cada":
        groups = [[i] for i in range(n)]
    elif mode == "n":
        k = max(1, int(value))
        groups = [list(range(i, min(i + k, n))) for i in range(0, n, k)]
    elif mode == "intervalos":
        from .util import parse_page_ranges
        for part in str(value).replace(";", ",").split(","):
            part = part.strip()
            if part:
                g = parse_page_ranges(part, n)
                if g:
                    groups.append(g)
    elif mode == "tamanho":
        limit = float(value) * 1024 * 1024
        cur: list[int] = []
        for i in range(n):
            test = cur + [i]
            if cur and _size_of(doc, test) > limit:
                groups.append(cur)
                cur = [i]
            else:
                cur = test
        if cur:
            groups.append(cur)
    else:
        raise ValueError("Modo de divisão desconhecido")
    res = []
    for gi, g in enumerate(groups, 1):
        part = pymupdf.open()
        for pno in g:
            part.insert_pdf(doc, from_page=pno, to_page=pno)
        label = f"pág. {g[0] + 1}" if len(g) == 1 else f"pág. {g[0] + 1}-{g[-1] + 1}"
        p = unique_path(od / f"{base.stem} ({label}).pdf")
        part.save(p, garbage=3, deflate=True)
        part.close()
        res.append(p)
    doc.close()
    return res


def _size_of(doc, pages: list[int]) -> int:
    t = pymupdf.open()
    for p in pages:
        t.insert_pdf(doc, from_page=p, to_page=p)
    b = len(t.tobytes(garbage=3, deflate=True))
    t.close()
    return b


# ---- operações sobre um documento aberto (usadas pela interface) ----
def rotate_pages(doc, pages: list[int], angle: int):
    for p in pages:
        pg = doc[p]
        pg.set_rotation((pg.rotation + angle) % 360)


def delete_pages(doc, pages: list[int]):
    if len(pages) >= doc.page_count:
        raise ValueError("Não é possível apagar todas as páginas.")
    doc.delete_pages(sorted(set(pages)))


def duplicate_pages(doc, pages: list[int]):
    for p in sorted(pages, reverse=True):
        doc.fullcopy_page(p, p + 1)


def move_page(doc, src: int, dst: int):
    """Move a página src para a posição dst (índice final)."""
    if src == dst:
        return
    order = list(range(doc.page_count))
    order.insert(dst, order.pop(src))
    doc.select(order)


def reorder(doc, order: list[int]):
    doc.select(order)


def insert_blank(doc, at: int, like: int | None = None):
    ref = doc[like if like is not None else max(0, min(at, doc.page_count) - 1)] if doc.page_count else None
    w, h = (ref.rect.width, ref.rect.height) if ref else pymupdf.paper_size("a4")
    doc.new_page(pno=at, width=w, height=h)


def insert_from_file(doc, path: str, at: int, pages: list[int] | None = None):
    src = pymupdf.open(path)
    if pages is None:
        doc.insert_pdf(src, start_at=at)
    else:
        for k, p in enumerate(pages):
            doc.insert_pdf(src, from_page=p, to_page=p, start_at=at + k)
    src.close()


# ---- compressão ----
COMPRESS_LEVELS = {
    "leve": dict(dpi=200, quality=85),
    "média": dict(dpi=150, quality=72),
    "forte": dict(dpi=100, quality=60),
}


def compress_doc(doc, level: str = "média"):
    cfg = COMPRESS_LEVELS.get(level, COMPRESS_LEVELS["média"])
    try:
        doc.rewrite_images(dpi_threshold=cfg["dpi"] + 30, dpi_target=cfg["dpi"], quality=cfg["quality"],
                           lossy=True, lossless=True, bitonal=True, color=True, gray=True, set_to_gray=False)
    except TypeError:
        doc.rewrite_images(dpi_threshold=cfg["dpi"] + 30, dpi_target=cfg["dpi"], quality=cfg["quality"])
    try:
        doc.subset_fonts()
    except Exception:
        pass


def compress(src: str, dst: str | None = None, level: str = "média") -> tuple[Path, int, int]:
    """Devolve (caminho, tamanho antes, tamanho depois) em bytes."""
    before = Path(src).stat().st_size
    doc = pymupdf.open(src)
    compress_doc(doc, level)
    dst = Path(dst) if dst else out_path(src, ".pdf", "(comprimido)")
    doc.save(dst, garbage=4, deflate=True, deflate_images=True, deflate_fonts=True, clean=True, use_objstms=1)
    doc.close()
    after = dst.stat().st_size
    if after >= before:
        # não compensou: guarda cópia otimizada sem perdas
        doc = pymupdf.open(src)
        doc.save(dst, garbage=4, deflate=True, clean=True, use_objstms=1)
        doc.close()
        after = dst.stat().st_size
    return dst, before, after
