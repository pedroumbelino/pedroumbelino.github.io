"""Fotos de documentos -> PDF: deteção do contorno da folha, correção de perspetiva e limpeza."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import cv2

from .util import unique_path


def _order(pts: np.ndarray) -> np.ndarray:
    pts = pts.reshape(4, 2).astype("float32")
    s = pts.sum(axis=1)
    d = np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)], pts[np.argmax(s)], pts[np.argmax(d)]], dtype="float32")


def find_document_quad(img: np.ndarray) -> np.ndarray | None:
    """Procura o maior quadrilátero (a folha) na foto. Devolve 4 pontos ou None."""
    h, w = img.shape[:2]
    scale = 1000.0 / max(h, w)
    small = cv2.resize(img, (int(w * scale), int(h * scale))) if scale < 1 else img.copy()
    if scale >= 1:
        scale = 1.0
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(gray, 50, 150)
    edges = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=2)
    cnts, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    area_min = 0.2 * small.shape[0] * small.shape[1]
    best = None
    best_area = 0
    for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:10]:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02 * peri, True)
        a = cv2.contourArea(approx)
        if len(approx) == 4 and a > area_min and a > best_area:
            best, best_area = approx, a
    if best is None:
        return None
    return _order(best / scale)


def warp(img: np.ndarray, quad: np.ndarray) -> np.ndarray:
    tl, tr, br, bl = quad
    wA = np.linalg.norm(br - bl)
    wB = np.linalg.norm(tr - tl)
    hA = np.linalg.norm(tr - br)
    hB = np.linalg.norm(tl - bl)
    W, H = int(max(wA, wB)), int(max(hA, hB))
    dst = np.array([[0, 0], [W - 1, 0], [W - 1, H - 1], [0, H - 1]], dtype="float32")
    M = cv2.getPerspectiveTransform(quad, dst)
    return cv2.warpPerspective(img, M, (W, H))


def enhance(img: np.ndarray, mode: str = "cor") -> np.ndarray:
    """mode: 'cor' (melhora contraste), 'cinza', 'pb' (preto e branco tipo scanner)."""
    if mode == "pb":
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        return cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 15)
    if mode == "cinza":
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        return clahe.apply(gray)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(l)
    out = cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2BGR)
    # branquear o fundo
    return cv2.convertScaleAbs(out, alpha=1.15, beta=10)


def _imread(path: str) -> np.ndarray:
    data = np.fromfile(path, dtype=np.uint8)  # suporta acentos no caminho (Windows)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Não consegui abrir a imagem {path}")
    return img


def process_photo(path: str, mode: str = "cor", auto_crop: bool = True) -> tuple[np.ndarray, bool]:
    img = _imread(path)
    cropped = False
    if auto_crop:
        q = find_document_quad(img)
        if q is not None:
            img = warp(img, q)
            cropped = True
    return enhance(img, mode), cropped


def photos_to_pdf(paths: list[str], dst: str, mode: str = "cor", auto_crop: bool = True,
                  a4: bool = True, progress=None) -> tuple[Path, int]:
    """Devolve (caminho, nº de fotos em que a folha foi detetada e recortada)."""
    import pymupdf
    doc = pymupdf.open()
    n_crop = 0
    for k, p in enumerate(paths):
        if progress:
            progress(k, len(paths), Path(p).name)
        img, cropped = process_photo(p, mode, auto_crop)
        n_crop += int(cropped)
        ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 88])
        h, w = img.shape[:2]
        if a4:
            r = pymupdf.paper_rect("a4")
            if w > h:
                r = pymupdf.Rect(0, 0, r.height, r.width)
        else:
            r = pymupdf.Rect(0, 0, w * 72 / 200, h * 72 / 200)
        page = doc.new_page(width=r.width, height=r.height)
        page.insert_image(page.rect, stream=buf.tobytes(), keep_proportion=True)
    out = unique_path(dst)
    doc.save(out, garbage=3, deflate=True)
    doc.close()
    if progress:
        progress(len(paths), len(paths), "Concluído")
    return out, n_crop
