"""Conversões de PDF para outros formatos e de outros formatos para PDF."""
from __future__ import annotations

import io
import os
import sys
import subprocess
from pathlib import Path
from typing import Callable, Iterable

import pymupdf

from .util import out_path, unique_path, find_tesseract, tessdata_dir, ocr_languages

Progress = Callable[[int, int, str], None] | None


def _p(cb: Progress, i: int, n: int, msg: str = ""):
    if cb:
        cb(i, n, msg)


# --------------------------------------------------------------------------- PDF -> Word
def pdf_to_word(src: str, dst: str | None = None, pages: list[int] | None = None,
                password: str | None = None, progress: Progress = None) -> Path:
    """Converte PDF em .docx editável, mantendo o layout tanto quanto possível."""
    from pdf2docx import Converter
    dst = Path(dst) if dst else out_path(src, ".docx")
    _p(progress, 0, 1, "A analisar o layout…")
    cv = Converter(src, password=password) if password else Converter(src)
    try:
        kw = {}
        if pages is not None:
            kw["pages"] = pages
        cv.convert(str(dst), multi_processing=False, **kw)
    finally:
        cv.close()
    _p(progress, 1, 1, "Concluído")
    return dst


# --------------------------------------------------------------------------- PDF -> Excel
def pdf_to_excel(src: str, dst: str | None = None, pages: list[int] | None = None,
                 progress: Progress = None, one_sheet_per_table: bool = True) -> Path:
    """Deteta tabelas em cada página e escreve-as em folhas de Excel.
    Páginas sem tabelas detetadas são exportadas como texto linha a linha."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    dst = Path(dst) if dst else out_path(src, ".xlsx")
    doc = pymupdf.open(src)
    wb = Workbook()
    wb.remove(wb.active)
    pages = pages if pages is not None else list(range(doc.page_count))
    thin = Side(style="thin", color="BFBFBF")
    head_fill = PatternFill("solid", fgColor="DDE5F0")
    count_tables = 0
    text_sheet = None
    for k, pno in enumerate(pages):
        _p(progress, k, len(pages), f"Página {pno + 1}")
        page = doc[pno]
        try:
            tabs = page.find_tables()
            tables = list(tabs.tables)
        except Exception:
            tables = []
        if not tables:
            # fallback: linhas de texto agrupadas por posição (colunas por blocos de palavras)
            if text_sheet is None:
                text_sheet = wb.create_sheet("Texto")
                text_sheet.append(["Página", "Texto"])
                for c in text_sheet[1]:
                    c.font = Font(bold=True)
            rows = _text_rows(page)
            for r in rows:
                text_sheet.append([pno + 1] + r)
            continue
        for t_i, tab in enumerate(tables):
            count_tables += 1
            data = tab.extract()
            name = f"P{pno + 1} Tabela {t_i + 1}"[:31]
            ws = wb.create_sheet(name)
            for r_i, row in enumerate(data):
                vals = [_to_number(c) for c in row]
                ws.append(vals)
                for c_i, cell in enumerate(ws[r_i + 1]):
                    cell.border = Border(top=thin, bottom=thin, left=thin, right=thin)
                    cell.alignment = Alignment(wrap_text=True, vertical="top")
                    if r_i == 0:
                        cell.font = Font(bold=True)
                        cell.fill = head_fill
            # larguras
            for col in range(1, ws.max_column + 1):
                mx = 8
                for row in ws.iter_rows(min_col=col, max_col=col):
                    v = row[0].value
                    if v is not None:
                        mx = max(mx, min(60, max(len(s) for s in str(v).split("\n")) + 2))
                ws.column_dimensions[get_column_letter(col)].width = mx
    if not wb.sheetnames:
        wb.create_sheet("Vazio")
    if text_sheet is not None:
        text_sheet.column_dimensions["A"].width = 8
        for col in range(2, text_sheet.max_column + 1):
            text_sheet.column_dimensions[get_column_letter(col)].width = 28
    wb.save(dst)
    doc.close()
    _p(progress, len(pages), len(pages), f"{count_tables} tabela(s) exportada(s)")
    return dst


def _to_number(v):
    """'1.234,56 €' -> 1234.56 ; mantém texto se não for número."""
    if v is None:
        return None
    s = str(v).strip()
    if not s:
        return ""
    t = s.replace("€", "").replace("%", "").replace("\u00a0", "").replace(" ", "").replace("’", "").replace("'", "")
    if not t or any(ch.isalpha() for ch in t):
        return s
    try:
        if "," in t and "." in t:
            if t.rfind(",") > t.rfind("."):
                t = t.replace(".", "").replace(",", ".")
            else:
                t = t.replace(",", "")
        elif "," in t:
            t = t.replace(",", ".")
        elif t.count(".") > 1:
            t = t.replace(".", "")
        n = float(t)
        if s.endswith("%"):
            return n / 100
        return int(n) if n.is_integer() and "." not in t else n
    except ValueError:
        return s


def _text_rows(page) -> list[list]:
    words = page.get_text("words")  # x0,y0,x1,y1,word,block,line,wordno
    lines: dict[tuple, list] = {}
    for w in words:
        key = (w[5], w[6])
        lines.setdefault(key, []).append(w)
    rows = []
    for key in sorted(lines, key=lambda k: (min(w[1] for w in lines[k]), min(w[0] for w in lines[k]))):
        ws = sorted(lines[key], key=lambda w: w[0])
        # separa em "células" quando há um espaço grande entre palavras
        cells, cur, last_x = [], [], None
        for w in ws:
            if last_x is not None and w[0] - last_x > 18:
                cells.append(" ".join(cur))
                cur = []
            cur.append(w[4])
            last_x = w[2]
        if cur:
            cells.append(" ".join(cur))
        rows.append([_to_number(c) for c in cells])
    return rows


# --------------------------------------------------------------------------- PDF -> PowerPoint
def pdf_to_pptx(src: str, dst: str | None = None, pages: list[int] | None = None,
                dpi: int = 200, progress: Progress = None) -> Path:
    """Cada página passa a um diapositivo (imagem de alta resolução + texto nas notas)."""
    from pptx import Presentation
    from pptx.util import Emu

    dst = Path(dst) if dst else out_path(src, ".pptx")
    doc = pymupdf.open(src)
    pages = pages if pages is not None else list(range(doc.page_count))
    prs = Presentation()
    first = doc[pages[0]] if pages else doc[0]
    w_pt, h_pt = first.rect.width, first.rect.height
    prs.slide_width = Emu(int(w_pt * 12700))
    prs.slide_height = Emu(int(h_pt * 12700))
    blank = prs.slide_layouts[6]
    for k, pno in enumerate(pages):
        _p(progress, k, len(pages), f"Página {pno + 1}")
        page = doc[pno]
        pix = page.get_pixmap(dpi=dpi)
        img = io.BytesIO(pix.tobytes("png"))
        slide = prs.slides.add_slide(blank)
        slide.shapes.add_picture(img, 0, 0, width=prs.slide_width, height=prs.slide_height)
        txt = page.get_text().strip()
        if txt:
            slide.notes_slide.notes_text_frame.text = txt
    prs.save(dst)
    doc.close()
    _p(progress, len(pages), len(pages), "Concluído")
    return dst


# --------------------------------------------------------------------------- PDF -> imagens / texto
def pdf_to_images(src: str, out_dir: str | None = None, fmt: str = "png", dpi: int = 200,
                  pages: list[int] | None = None, progress: Progress = None) -> list[Path]:
    doc = pymupdf.open(src)
    base = Path(src)
    od = Path(out_dir) if out_dir else base.parent / f"{base.stem} - imagens"
    od.mkdir(parents=True, exist_ok=True)
    pages = pages if pages is not None else list(range(doc.page_count))
    res = []
    for k, pno in enumerate(pages):
        _p(progress, k, len(pages), f"Página {pno + 1}")
        pix = doc[pno].get_pixmap(dpi=dpi, alpha=False)
        p = unique_path(od / f"{base.stem} - página {pno + 1:03d}.{fmt}")
        if fmt.lower() in ("jpg", "jpeg"):
            pix.save(str(p), jpg_quality=92)
        else:
            pix.save(str(p))
        res.append(p)
    doc.close()
    _p(progress, len(pages), len(pages), "Concluído")
    return res


def pdf_to_text(src: str, dst: str | None = None) -> Path:
    doc = pymupdf.open(src)
    dst = Path(dst) if dst else out_path(src, ".txt")
    with open(dst, "w", encoding="utf-8") as f:
        for i, page in enumerate(doc):
            f.write(f"===== Página {i + 1} =====\n")
            f.write(page.get_text("text", sort=True))
            f.write("\n")
    doc.close()
    return dst


def extract_images(src: str, out_dir: str | None = None, min_size: int = 32,
                   progress: Progress = None) -> list[Path]:
    """Guarda todas as imagens incorporadas no PDF (sem duplicados)."""
    doc = pymupdf.open(src)
    base = Path(src)
    od = Path(out_dir) if out_dir else base.parent / f"{base.stem} - imagens extraídas"
    od.mkdir(parents=True, exist_ok=True)
    seen = set()
    res = []
    for pno, page in enumerate(doc):
        _p(progress, pno, doc.page_count, f"Página {pno + 1}")
        for img in page.get_images(full=True):
            xref = img[0]
            if xref in seen:
                continue
            seen.add(xref)
            try:
                info = doc.extract_image(xref)
            except Exception:
                continue
            if not info or info.get("width", 0) < min_size or info.get("height", 0) < min_size:
                continue
            ext = info.get("ext", "png")
            data = info["image"]
            if info.get("smask"):
                # combinar com a máscara de transparência
                try:
                    pix = pymupdf.Pixmap(doc, xref)
                    mask = pymupdf.Pixmap(doc, info["smask"])
                    pix = pymupdf.Pixmap(pix, mask)
                    data, ext = pix.tobytes("png"), "png"
                except Exception:
                    pass
            p = unique_path(od / f"página {pno + 1:03d} - imagem {len(res) + 1:03d}.{ext}")
            p.write_bytes(data)
            res.append(p)
    doc.close()
    _p(progress, 1, 1, f"{len(res)} imagem(ns)")
    return res


# --------------------------------------------------------------------------- imagens -> PDF
def images_to_pdf(images: Iterable[str], dst: str, page_size: str = "auto",
                  margin_mm: float = 0, progress: Progress = None) -> Path:
    """Junta imagens num PDF. page_size: 'auto' (tamanho da imagem) ou 'A4'."""
    images = list(images)
    doc = pymupdf.open()
    for k, path in enumerate(images):
        _p(progress, k, len(images), Path(path).name)
        img = pymupdf.open(path)
        rect = img[0].rect
        img.close()
        if page_size.upper() == "A4":
            a4 = pymupdf.paper_rect("a4")
            if rect.width > rect.height:
                a4 = pymupdf.Rect(0, 0, a4.height, a4.width)
            page = doc.new_page(width=a4.width, height=a4.height)
            m = margin_mm * 72 / 25.4
            target = pymupdf.Rect(m, m, a4.width - m, a4.height - m)
        else:
            page = doc.new_page(width=rect.width, height=rect.height)
            target = page.rect
        page.insert_image(target, filename=path, keep_proportion=True)
    dst = unique_path(dst) if os.path.exists(dst) else Path(dst)
    doc.save(dst, garbage=3, deflate=True)
    doc.close()
    _p(progress, len(images), len(images), "Concluído")
    return dst


# --------------------------------------------------------------------------- Office -> PDF
OFFICE_EXT = {".doc", ".docx", ".rtf", ".odt", ".xls", ".xlsx", ".xlsm", ".ods", ".ppt", ".pptx", ".odp", ".txt"}


def office_to_pdf(src: str, dst: str | None = None) -> Path:
    """Usa o Microsoft Office instalado (COM). Se não houver Office, tenta o LibreOffice."""
    src = str(Path(src).resolve())
    dst = Path(dst) if dst else out_path(src, ".pdf")
    ext = Path(src).suffix.lower()
    if sys.platform == "win32":
        try:
            return _office_com(src, str(dst.resolve()), ext)
        except Exception as e:  # sem Office ou erro: tentar LibreOffice
            err = e
        else:
            err = None
    else:
        err = None
    soffice = _find_soffice()
    if not soffice:
        raise RuntimeError("Não encontrei o Microsoft Office nem o LibreOffice para converter este ficheiro."
                           + (f"\nDetalhe: {err}" if err else ""))
    outdir = str(dst.parent)
    subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", outdir, src],
                   check=True, capture_output=True, timeout=300)
    produced = Path(outdir) / (Path(src).stem + ".pdf")
    if produced != dst and produced.exists():
        produced.replace(dst)
    return dst


def _office_com(src: str, dst: str, ext: str) -> Path:
    import pythoncom  # type: ignore
    import win32com.client  # type: ignore
    pythoncom.CoInitialize()
    try:
        if ext in (".doc", ".docx", ".rtf", ".odt", ".txt"):
            app = win32com.client.DispatchEx("Word.Application")
            app.Visible = False
            app.DisplayAlerts = 0
            try:
                d = app.Documents.Open(src, ReadOnly=True, AddToRecentFiles=False)
                d.ExportAsFixedFormat(dst, 17)  # wdExportFormatPDF
                d.Close(False)
            finally:
                app.Quit()
        elif ext in (".xls", ".xlsx", ".xlsm", ".ods"):
            app = win32com.client.DispatchEx("Excel.Application")
            app.Visible = False
            app.DisplayAlerts = False
            try:
                wb = app.Workbooks.Open(src, ReadOnly=True)
                wb.ExportAsFixedFormat(0, dst)  # xlTypePDF
                wb.Close(False)
            finally:
                app.Quit()
        elif ext in (".ppt", ".pptx", ".odp"):
            app = win32com.client.DispatchEx("PowerPoint.Application")
            try:
                pres = app.Presentations.Open(src, ReadOnly=True, WithWindow=False)
                pres.SaveAs(dst, 32)  # ppSaveAsPDF
                pres.Close()
            finally:
                app.Quit()
        else:
            raise RuntimeError("Formato não suportado")
    finally:
        pythoncom.CoUninitialize()
    return Path(dst)


def _find_soffice() -> str | None:
    import shutil
    for c in ("soffice", "libreoffice"):
        p = shutil.which(c)
        if p:
            return p
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", "")):
        if base:
            p = os.path.join(base, "LibreOffice", "program", "soffice.exe")
            if os.path.isfile(p):
                return p
    return None


# --------------------------------------------------------------------------- OCR
def ocr_available() -> bool:
    """O PyMuPDF traz o motor Tesseract incluído; só precisa dos ficheiros de idioma (tessdata)."""
    return tessdata_dir() is not None


def _ensure_tess_env():
    td = tessdata_dir()
    if td:
        os.environ["TESSDATA_PREFIX"] = td
    exe = find_tesseract()
    if exe:
        d = os.path.dirname(exe)
        if d not in os.environ.get("PATH", ""):
            os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")


def page_needs_ocr(page) -> bool:
    return len(page.get_text().strip()) < 20 and bool(page.get_images())


def ocr_pdf(src: str, dst: str | None = None, dpi: int = 300, only_if_needed: bool = True,
            progress: Progress = None) -> Path:
    """Cria um PDF pesquisável: cada página digitalizada recebe uma camada de texto invisível."""
    if not ocr_available():
        raise RuntimeError("Faltam os ficheiros de idioma do OCR (pasta tessdata com por.traineddata).")
    _ensure_tess_env()
    lang = ocr_languages()
    doc = pymupdf.open(src)
    out = pymupdf.open()
    for i, page in enumerate(doc):
        _p(progress, i, doc.page_count, f"OCR página {i + 1} de {doc.page_count}")
        if only_if_needed and not page_needs_ocr(page):
            out.insert_pdf(doc, from_page=i, to_page=i)
            continue
        pix = page.get_pixmap(dpi=dpi)
        pdfbytes = pix.pdfocr_tobytes(language=lang, tessdata=os.environ.get("TESSDATA_PREFIX"))
        ocr_page_doc = pymupdf.open("pdf", pdfbytes)
        # página com o tamanho original: imagem original + texto OCR invisível por cima
        new = out.new_page(width=page.rect.width, height=page.rect.height)
        new.show_pdf_page(new.rect, doc, i)
        tmp = pymupdf.open()
        tmp.insert_pdf(ocr_page_doc)
        _overlay_invisible_text(new, tmp[0])
        tmp.close()
        ocr_page_doc.close()
    dst = Path(dst) if dst else out_path(src, ".pdf", "(OCR)")
    out.save(dst, garbage=3, deflate=True)
    out.close()
    doc.close()
    _p(progress, 1, 1, "Concluído")
    return dst


def _overlay_invisible_text(target_page, ocr_page):
    """Copia o texto do OCR como texto invisível (render mode 3), escalado para a página alvo."""
    sx = target_page.rect.width / ocr_page.rect.width
    sy = target_page.rect.height / ocr_page.rect.height
    tw = pymupdf.TextWriter(target_page.rect)
    font = pymupdf.Font("helv")
    for b in ocr_page.get_text("dict")["blocks"]:
        for l in b.get("lines", []):
            for s in l.get("spans", []):
                text = s["text"]
                if not text.strip():
                    continue
                x0, y0, x1, y1 = s["bbox"]
                size = max(1.0, (y1 - y0) * sy * 0.85)
                origin = pymupdf.Point(x0 * sx, (s["origin"][1]) * sy)
                width = font.text_length(text, fontsize=size)
                want = (x1 - x0) * sx
                if width > 0:
                    size = size * min(3.0, max(0.3, want / width))
                try:
                    tw.append(origin, text, font=font, fontsize=size)
                except Exception:
                    pass
    tw.write_text(target_page, render_mode=3)


def ocr_to_word(src: str, dst: str | None = None, progress: Progress = None) -> Path:
    """Digitalização -> Word: primeiro OCR pesquisável, depois conversão para .docx."""
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        tmp_pdf = Path(td) / "ocr.pdf"
        ocr_pdf(src, str(tmp_pdf), only_if_needed=True, progress=progress)
        # Para Word, reconstruímos o texto visível (pdf2docx ignora texto invisível)
        doc = pymupdf.open(tmp_pdf)
        vis = pymupdf.open()
        for page in doc:
            np_ = vis.new_page(width=page.rect.width, height=page.rect.height)
            d = page.get_text("dict")
            tw = pymupdf.TextWriter(np_.rect)
            font = pymupdf.Font("helv")
            for b in d["blocks"]:
                for l in b.get("lines", []):
                    for s in l.get("spans", []):
                        if s["text"].strip():
                            try:
                                tw.append(pymupdf.Point(s["origin"]), s["text"], font=font, fontsize=max(4, s["size"]))
                            except Exception:
                                pass
            tw.write_text(np_)
        vis_path = Path(td) / "vis.pdf"
        vis.save(vis_path)
        vis.close()
        doc.close()
        return pdf_to_word(str(vis_path), str(dst) if dst else str(out_path(src, ".docx", "(OCR)")), progress=progress)
