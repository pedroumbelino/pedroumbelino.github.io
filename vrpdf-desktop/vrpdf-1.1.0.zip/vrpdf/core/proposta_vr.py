"""Proposta de fornecedor (PDF) -> proposta Ventura Rodrigues em Word, no layout do modelo.

1. parse_supplier_pdf() lê a proposta do fornecedor e extrai assunto, referência, data, linhas e condições.
2. A interface mostra os dados para rever (margem, textos, número da proposta).
3. build_docx() preenche o modelo Word (assets/modelo_proposta_vr.docx) e grava o .docx.
"""
from __future__ import annotations

import copy
import datetime as dt
import re
import shutil
import tempfile
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

import pymupdf

from .extenso import euros, fmt_eur, parse_eur
from .util import resource_path, unique_path

MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro",
         "outubro", "novembro", "dezembro"]


@dataclass
class Linha:
    designacao: str = "Prestação de Serviços"
    descricao: str = ""
    quantidade: float = 1
    unitario: float = 0.0

    @property
    def total(self) -> float:
        return round(self.quantidade * self.unitario, 2)


@dataclass
class Proposta:
    cliente: str = ""
    cliente_curto: str = ""
    numero: str = ""
    titulo: list[str] = field(default_factory=list)  # linhas do título na capa
    subtitulo: str = ""
    introducao: str = ""
    nota_introducao: str = ""
    objectivo: str = ""
    nota_objectivo: str = ""
    linhas: list[Linha] = field(default_factory=list)
    pagamento: str = "O pagamento será efetuado na conclusão dos trabalhos, num prazo de 30 dias após a emissão da Fatura."
    pagamento_2: str = "Sendo previsto a Faturação com 100 % com a conclusão dos trabalhos."
    validade_dias: int = 30
    local: str = "Laranjeiro"
    data: dt.date = field(default_factory=dt.date.today)
    reserva_propriedade: bool = False
    margem_pct: float = 0.0
    origem: str = ""

    @property
    def total(self) -> float:
        return round(sum(l.total for l in self.linhas), 2)

    @property
    def validade_ate(self) -> dt.date:
        return self.data + dt.timedelta(days=self.validade_dias)

    def aplicar_margem(self, pct: float):
        f = 1 + pct / 100
        for l in self.linhas:
            l.unitario = round(l.unitario * f, 2)
        self.margem_pct = pct


def data_extenso(d: dt.date, maiuscula_mes=True) -> str:
    mes = MESES[d.month - 1]
    if maiuscula_mes:
        mes = mes.capitalize()
    return f"{d.day} de {mes} de {d.year}"


# ---------------------------------------------------------------- leitura do PDF do fornecedor
def _clean(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").replace("\n", " ")).strip()


def parse_supplier_pdf(path: str) -> Proposta:
    doc = pymupdf.open(path)
    text = "\n".join(p.get_text("text", sort=True) for p in doc)
    p = Proposta(origem=Path(path).name)

    m = re.search(r"Cliente\s*:\s*(.+)", text)
    if m:
        p.cliente_curto = _clean(m.group(1))
    m = re.search(r"(?:N/?\s*Ref\.?|Ref\.?)\s*(?:Proposta)?\s*n?[ºo°]?\s*([\w\-/\.]+)", text, re.I)
    if m:
        p.numero = "PVR " + m.group(1).replace("/", "-")
    m = re.search(r"Assunto\s*:\s*(.+?)(?:\n\s*\n|Exm|Caro|Estimad)", text, re.S | re.I)
    assunto = _clean(m.group(1)) if m else ""
    assunto = assunto.rstrip(".")
    if assunto.lower().startswith("proposta de "):
        assunto = assunto[12:]
    if assunto.lower().startswith("proposta para "):
        assunto = assunto[14:]
    assunto = assunto[:1].upper() + assunto[1:] if assunto else ""
    m = re.search(r"(\d{1,2})\s+de\s+(\w+)\s+de\s+(\d{4})", text)
    if m and m.group(2).lower() in MESES:
        try:
            p.data = dt.date(int(m.group(3)), MESES.index(m.group(2).lower()) + 1, int(m.group(1)))
        except ValueError:
            pass
    p.data = dt.date.today() if p.data < dt.date.today() - dt.timedelta(days=60) else p.data
    m = re.search(r"Validade[^:\n]*:\s*(\d+)\s*dias", text, re.I)
    if m:
        p.validade_dias = int(m.group(1))
    m = re.search(r"Condi[çc][õo]es de Pagamento\s*:\s*(.+)", text, re.I)
    if m:
        cond = _clean(m.group(1)).rstrip(".")
        if "conclus" in cond.lower():
            p.pagamento = "O pagamento será efetuado na conclusão dos trabalhos, num prazo de 30 dias após a emissão da Fatura."
        elif "adjudica" in cond.lower():
            p.pagamento = "O pagamento será efetuado com a adjudicação e num prazo de 30 dias após a emissão da Fatura."
        else:
            p.pagamento = f"Condições de pagamento: {cond}."
    p.reserva_propriedade = bool(re.search(r"Reserva de Propriedade", text, re.I))

    p.linhas = _parse_table(doc)
    if not p.linhas:
        m = re.search(r"Valor\s+Total\s*:?\s*([\d\.\s’',]+)\s*€", text, re.I)
        if m:
            p.linhas = [Linha("Prestação de Serviços", assunto or "Trabalhos conforme descrição", 1, parse_eur(m.group(1)) or 0)]
    doc.close()

    # textos por defeito
    p.titulo = _split_title(assunto)
    p.subtitulo = ""
    p.introducao = ("surge no seguimento do vosso contacto, ao qual desde já agradecemos, e diz respeito aos trabalhos de "
                    + (assunto[:1].lower() + assunto[1:] if assunto else "") + ".")
    p.objectivo = ("Promover os trabalhos de " + (assunto[:1].lower() + assunto[1:]) + "." if assunto
                   else "Promover os trabalhos descritos na presente proposta.")
    if "aditamento" in assunto.lower():
        p.nota_objectivo = "Nota .: Os trabalhos objeto da presente proposta constituem um aditamento à intervenção anterior."
    return p


def _split_title(assunto: str) -> list[str]:
    a = re.sub(r"\s*\((aditamento)\)", "", assunto, flags=re.I).strip()
    words = a.split()
    if len(a) <= 42:
        return [a] if a else []
    # parte em ~2 linhas equilibradas
    best, half = 1, len(a) / 2
    acc = 0
    for i, w in enumerate(words):
        acc += len(w) + 1
        if acc >= half:
            best = i + 1
            break
    return [" ".join(words[:best]), " ".join(words[best:])]


def _parse_table(doc) -> list[Linha]:
    linhas: list[Linha] = []
    for page in doc:
        try:
            tabs = page.find_tables().tables
        except Exception:
            tabs = []
        for t in tabs:
            rows = t.rows
            if not rows:
                continue
            # cabeçalho: colunas definidas pelas posições x das células com texto
            hdr_i, heads = None, []
            for i, row in enumerate(rows[:3]):
                hs = []
                for cb in row.cells:
                    if cb is None:
                        continue
                    txt = _clean(page.get_textbox(pymupdf.Rect(cb))).lower()
                    if txt:
                        hs.append((txt, cb[0]))
                if any("descri" in h or "design" in h for h, _ in hs):
                    hdr_i, heads = i, sorted(hs, key=lambda h: h[1])
                    break
            if hdr_i is None:
                continue
            x_end = t.bbox[2]
            cols = {}
            for k, (h, x0) in enumerate(heads):
                x1 = heads[k + 1][1] if k + 1 < len(heads) else x_end
                key = ("des" if "design" in h else "desc" if "descri" in h else
                       "q" if "quant" in h or h.startswith("qt") else "u" if "unit" in h else
                       "t" if "total" in h else None)
                if key and key not in cols:
                    cols[key] = (x0, x1)

            def text_in(key, y0, y1):
                if key not in cols:
                    return ""
                x0, x1 = cols[key]
                return _clean(page.get_textbox(pymupdf.Rect(x0 + 0.5, y0, x1 - 0.5, y1)))

            # agrupa linhas: uma nova linha começa quando há valores nas colunas numéricas
            groups = []
            for row in rows[hdr_i + 1:]:
                y0, y1 = row.bbox[1], row.bbox[3]
                if groups and y0 < groups[-1][1] - 1:
                    # linha sobreposta (célula fundida): pertence ao grupo anterior
                    groups[-1][1] = max(groups[-1][1], y1)
                    continue
                has_val = any(re.search(r"\d", text_in(k, y0, y1)) for k in ("q", "u", "t"))
                if has_val or not groups:
                    groups.append([y0, y1])
                else:
                    groups[-1][1] = y1
            for y0, y1 in groups:
                desc = text_in("desc", y0, y1) or text_in("des", y0, y1)
                des = text_in("des", y0, y1) if "desc" in cols else ""
                if not desc or desc.upper().startswith("TOTAL"):
                    continue
                q = parse_eur(text_in("q", y0, y1)) or 1
                u = parse_eur(text_in("u", y0, y1))
                tot = parse_eur(text_in("t", y0, y1))
                if u is None and tot is not None:
                    u = tot / q if q else tot
                if u is None:
                    continue
                linhas.append(Linha(des or "Prestação de Serviços", desc, q, round(u, 2)))
        if linhas:
            break
    return linhas


# ---------------------------------------------------------------- escrita do Word
def _paras(d):
    return [(m.start(), m.end(), m.group()) for m in re.finditer(r"<w:p[ >].*?</w:p>", d, re.S)]


def _txt(p):
    return "".join(re.findall(r"<w:t[^>]*>([^<]*)", p))


def _esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _settexts(p, texts):
    i = [0]

    def f(m):
        k = i[0]
        i[0] += 1
        if k < len(texts) and texts[k] is not None:
            return '<w:t xml:space="preserve">' + _esc(texts[k]) + "</w:t>"
        return m.group()

    return re.sub(r"<w:t(?: [^>]*)?>[^<]*</w:t>", f, p)


def _nt(p):
    return len(re.findall(r"<w:t(?: [^>]*)?>", p))


def _one(p, s):
    return _settexts(p, [s] + [""] * (_nt(p) - 1))


def _strip_ids(p):
    return re.sub(r' w14:paraId="[^"]*"| w14:textId="[^"]*"', "", p)


def _merge_runs(xml: str) -> str:
    """Junta runs adjacentes com a mesma formatação (para os textos do modelo ficarem contíguos)."""
    xml = re.sub(r"<w:proofErr [^>]*/>", "", xml)
    xml = re.sub(r' w:rsidR(?:Pr|Default)?="[^"]*"', "", xml)
    pat = re.compile(r'(<w:r>(<w:rPr>(?:(?!</w:rPr>).)*</w:rPr>)?<w:t(?: xml:space="preserve")?>([^<]*)</w:t></w:r>)'
                     r'<w:r>(<w:rPr>(?:(?!</w:rPr>).)*</w:rPr>)?<w:t(?: xml:space="preserve")?>([^<]*)</w:t></w:r>', re.S)

    def rep(m):
        if (m.group(2) or "") == (m.group(4) or ""):
            return f'<w:r>{m.group(2) or ""}<w:t xml:space="preserve">{m.group(3)}{m.group(5)}</w:t></w:r>'
        return m.group(0)

    prev = None
    while prev != xml:
        prev = xml
        xml = pat.sub(rep, xml)
    return xml


def build_docx(p: Proposta, dst: str, template: str | None = None) -> Path:
    tpl = Path(template) if template else resource_path("assets", "modelo_proposta_vr.docx")
    with tempfile.TemporaryDirectory() as td:
        with zipfile.ZipFile(tpl) as z:
            z.extractall(td)
        docxml = Path(td, "word", "document.xml")
        d = _merge_runs(docxml.read_text(encoding="utf-8"))

        def repl(start, fn, required=True):
            nonlocal d
            for s, e, para in _paras(d):
                if _txt(para).startswith(start):
                    d = d[:s] + fn(para) + d[e:]
                    return True
            if required:
                raise RuntimeError(f"O modelo Word não tem o texto esperado: '{start}'")
            return False

        cliente = (p.cliente or p.cliente_curto or "Cliente").strip()
        repl("AGÊNCIA PORTUGUESA AMBIENTE", lambda x: _one(x, cliente.upper()))
        repl("PROPOSTA PVR", lambda x: _one(x, f"PROPOSTA {p.numero}".strip()))
        tit = p.titulo or [""]
        repl("Reparação de Fugas", lambda x: _one(x, tit[0] + (" " + " ".join(tit[1:]) if len(tit) > 1 else "")))
        repl("SALA DE PESAGEM", lambda x: _one(x, p.subtitulo.upper()))
        repl("Agência Portuguesa Ambiente", lambda x: _one(x, cliente))
        repl("A presente proposta de", lambda x: _settexts(x, ["A presente proposta de ",
                                                               "VENTURA RODRIGUES, Consultadoria Engenharia Unipessoal LDA,",
                                                               " " + p.introducao] + [""] * 10))
        repl("Nota .: Tendo", lambda x: _one(x, p.nota_introducao))
        repl("Após visita", lambda x: _one(x, p.objectivo))
        repl("Nota .: Não tendo", lambda x: _one(x, p.nota_objectivo))
        total = p.total
        repl("Valor Total:", lambda x: _settexts(x, [None, f"  = {fmt_eur(total).replace(' €', '€')} + IVA  ( {euros(total)} + IVA )"] + [""] * 10))
        repl("O pagamento será", lambda x: _one(x, p.pagamento))
        repl("Sendo previsto", lambda x: _one(x, p.pagamento_2))
        repl("A presente proposta é valida", lambda x: _one(x, f"A presente proposta é válida por {p.validade_dias} dias, até {data_extenso(p.validade_ate)}."))
        repl("Laranjeiro,", lambda x: _one(x, f"{p.local}, {data_extenso(p.data)}"))

        # tabela
        i0 = d.find("DESIGNAÇÃO")
        ts = d.rfind("<w:tbl>", 0, i0)
        te = d.find("</w:tbl>", i0) + len("</w:tbl>")
        tbl = d[ts:te]
        rows = list(re.finditer(r"<w:tr[ >].*?</w:tr>", tbl, re.S))
        row_tpl = rows[1].group()
        total_row = rows[-1].group()
        new_rows = []
        for ln in p.linhas:
            q = ln.quantidade
            qs = str(int(q)) if float(q).is_integer() else f"{q:.2f}".replace(".", ",")
            new_rows.append(_settexts(_strip_ids(row_tpl), [ln.designacao, ln.descricao, qs,
                                                            fmt_eur(ln.unitario), fmt_eur(ln.total)]))
        total_row = re.sub(r"\d[\d’]*,\d{2} €\+IVA", fmt_eur(total) + "+IVA", total_row)
        tbl = tbl[:rows[1].start()] + "".join(new_rows) + total_row + tbl[rows[-1].end():]
        d = d[:ts] + tbl + d[te:]

        # reserva de propriedade (secção extra, antes da validade)
        # remove o parágrafo vazio a seguir às condições de pagamento (mantém a assinatura na mesma página)
        ps = _paras(d)
        hi = next(i for i, x in enumerate(ps) if _txt(x[2]) == "CONDIÇÕES DE PAGAMENTO")
        j = hi + 3
        if p.reserva_propriedade and j < len(ps) and not _txt(ps[j][2]).strip():
            s1, e1, _ = ps[j]
            d = d[:s1] + d[e1:]
        if p.reserva_propriedade:
            ps = _paras(d)
            hi = next(i for i, x in enumerate(ps) if _txt(x[2]) == "CONDIÇÕES DE PAGAMENTO")
            head, body = ps[hi][2], ps[hi + 1][2]
            h2 = _strip_ids(_one(head, "RESERVA DE PROPRIEDADE"))
            b2 = _strip_ids(_one(body, "A Ventura Rodrigues, ao abrigo do artigo 409.º, n.º 1, do Código Civil, reserva "
                                       "para si a propriedade do equipamento fornecido até ao integral pagamento do mesmo."))
            vi = next(i for i, x in enumerate(ps) if _txt(x[2]) == "VALIDADE DA PROPOSTA")
            s = ps[vi][0]
            d = d[:s] + h2 + b2 + d[s:]
        docxml.write_text(d, encoding="utf-8")

        # rodapé: assunto + cliente
        for f in Path(td, "word").glob("footer*.xml"):
            x = _merge_runs(f.read_text(encoding="utf-8"))
            if "Climatização da Sala de Pesagem" in x or "Reparação de Fugas" in x:
                footer_title = " ".join(tit).strip()
                x = re.sub(r"(<w:t[^>]*>)[^<]*Reparação[^<]*(</w:t>)", lambda m: m.group(1) + _esc(footer_title) + m.group(2), x, count=1)
                for frag in ("e Carga de Gás ", "na Unidade ", "Climatização da Sala de Pesagem"):
                    x = re.sub(r"(<w:t[^>]*>)" + re.escape(frag) + r"(</w:t>)", r"\1\2", x)
                x = re.sub(r"(<w:t[^>]*>)Agência Portuguesa Ambiente(</w:t>)", lambda m: m.group(1) + _esc(cliente) + m.group(2), x)
                f.write_text(x, encoding="utf-8")

        dst = unique_path(dst)
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
            for fpath in sorted(Path(td).rglob("*")):
                if fpath.is_file() and not fpath.is_symlink():
                    z.write(fpath, fpath.relative_to(td).as_posix())
    return Path(dst)
