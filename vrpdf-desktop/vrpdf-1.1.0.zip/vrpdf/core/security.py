"""Proteção com palavra-passe e limpeza de metadados."""
from __future__ import annotations

from pathlib import Path

import pymupdf


def save_encrypted(doc, dst: str, user_pw: str = "", owner_pw: str = "", allow_print=True,
                   allow_copy=False, allow_edit=False) -> Path:
    perm = pymupdf.PDF_PERM_ACCESSIBILITY
    if allow_print:
        perm |= pymupdf.PDF_PERM_PRINT | pymupdf.PDF_PERM_PRINT_HQ
    if allow_copy:
        perm |= pymupdf.PDF_PERM_COPY
    if allow_edit:
        perm |= pymupdf.PDF_PERM_MODIFY | pymupdf.PDF_PERM_ANNOTATE | pymupdf.PDF_PERM_FORM | pymupdf.PDF_PERM_ASSEMBLE
    owner = owner_pw or user_pw or "vrpdf-owner"
    doc.save(dst, encryption=pymupdf.PDF_ENCRYPT_AES_256, owner_pw=owner, user_pw=user_pw,
             permissions=perm, garbage=3, deflate=True)
    return Path(dst)


def remove_password(src: str, password: str, dst: str) -> Path:
    doc = pymupdf.open(src)
    if doc.needs_pass and not doc.authenticate(password):
        doc.close()
        raise ValueError("Palavra-passe incorreta.")
    doc.save(dst, encryption=pymupdf.PDF_ENCRYPT_NONE, garbage=3, deflate=True)
    doc.close()
    return Path(dst)


def clean_metadata(doc) -> None:
    """Remove autor, software, datas, XML de metadados, ficheiros anexos e JavaScript."""
    doc.set_metadata({})
    try:
        doc.del_xml_metadata()
    except Exception:
        pass
    try:
        doc.scrub(attached_files=True, clean_pages=False, embedded_files=True, hidden_text=False,
                  javascript=True, metadata=True, redactions=False, remove_links=False,
                  reset_fields=False, reset_responses=False, thumbnails=True, xml_metadata=True)
    except Exception:
        pass


def metadata(doc) -> dict:
    m = dict(doc.metadata or {})
    return {k: v for k, v in m.items() if v}
