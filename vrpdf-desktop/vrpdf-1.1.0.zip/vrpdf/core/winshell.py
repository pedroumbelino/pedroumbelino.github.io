"""Integração com o Windows: menu do botão direito e programa PDF por defeito (só para o utilizador atual, HKCU)."""
from __future__ import annotations

import os
import sys

PROGID = "VRPDF.Document"

CONTEXT_ACTIONS = [
    # (chave, texto do menu, argumento de linha de comando, tipos)
    ("vrpdf_word", "Converter para Word", "--word", ".pdf"),
    ("vrpdf_excel", "Converter para Excel", "--excel", ".pdf"),
    ("vrpdf_compress", "Comprimir PDF", "--comprimir", ".pdf"),
    ("vrpdf_ocr", "Tornar pesquisável (OCR)", "--ocr", ".pdf"),
    ("vrpdf_merge", "Juntar PDFs selecionados", "--juntar", ".pdf"),
    ("vrpdf_topdf", "Converter para PDF", "--pdf", "office_img"),
]
OFFICE_IMG = [".docx", ".doc", ".xlsx", ".xls", ".pptx", ".ppt", ".jpg", ".jpeg", ".png", ".tif", ".tiff"]


def exe_command() -> str:
    if getattr(sys, "frozen", False):
        return f'"{sys.executable}"'
    return f'"{sys.executable}" "{os.path.abspath(sys.argv[0])}"'


def _reg():
    import winreg  # type: ignore
    return winreg


def install_context_menu() -> None:
    winreg = _reg()
    exe = exe_command()
    icon = sys.executable if getattr(sys, "frozen", False) else ""
    for key, label, arg, kind in CONTEXT_ACTIONS:
        exts = [".pdf"] if kind == ".pdf" else OFFICE_IMG
        for ext in exts:
            base = rf"Software\Classes\SystemFileAssociations\{ext}\shell\{key}"
            k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, base)
            winreg.SetValueEx(k, "MUIVerb", 0, winreg.REG_SZ, f"VR PDF: {label}")
            if icon:
                winreg.SetValueEx(k, "Icon", 0, winreg.REG_SZ, icon)
            if arg == "--juntar":
                winreg.SetValueEx(k, "MultiSelectModel", 0, winreg.REG_SZ, "Player")
            c = winreg.CreateKey(k, "command")
            winreg.SetValueEx(c, "", 0, winreg.REG_SZ, f'{exe} {arg} "%1"')
            winreg.CloseKey(c)
            winreg.CloseKey(k)
    _notify()


def uninstall_context_menu() -> None:
    winreg = _reg()
    for key, _, _, kind in CONTEXT_ACTIONS:
        exts = [".pdf"] if kind == ".pdf" else OFFICE_IMG
        for ext in exts:
            base = rf"Software\Classes\SystemFileAssociations\{ext}\shell\{key}"
            for sub in (base + r"\command", base):
                try:
                    winreg.DeleteKey(winreg.HKEY_CURRENT_USER, sub)
                except OSError:
                    pass
    _notify()


def context_menu_installed() -> bool:
    if sys.platform != "win32":
        return False
    winreg = _reg()
    try:
        winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\SystemFileAssociations\.pdf\shell\vrpdf_word")
        return True
    except OSError:
        return False


def register_pdf_handler() -> None:
    """Regista o VR PDF como programa capaz de abrir PDFs. O Windows 10/11 pede ao utilizador a confirmação
    final em Definições > Aplicações predefinidas (não é possível forçar sem a confirmação dele)."""
    winreg = _reg()
    exe = exe_command()
    k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, rf"Software\Classes\{PROGID}")
    winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "Documento PDF (VR PDF)")
    c = winreg.CreateKey(k, r"shell\open\command")
    winreg.SetValueEx(c, "", 0, winreg.REG_SZ, f'{exe} "%1"')
    if getattr(sys, "frozen", False):
        i = winreg.CreateKey(k, "DefaultIcon")
        winreg.SetValueEx(i, "", 0, winreg.REG_SZ, f"{sys.executable},0")
    ow = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\.pdf\OpenWithProgids")
    winreg.SetValueEx(ow, PROGID, 0, winreg.REG_NONE, b"")
    cap = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\VRPDF\Capabilities")
    winreg.SetValueEx(cap, "ApplicationName", 0, winreg.REG_SZ, "VR PDF")
    winreg.SetValueEx(cap, "ApplicationDescription", 0, winreg.REG_SZ, "Editor de PDF da Ventura Rodrigues")
    fa = winreg.CreateKey(cap, "FileAssociations")
    winreg.SetValueEx(fa, ".pdf", 0, winreg.REG_SZ, PROGID)
    ra = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\RegisteredApplications")
    winreg.SetValueEx(ra, "VR PDF", 0, winreg.REG_SZ, r"Software\VRPDF\Capabilities")
    _notify()


def open_default_apps_settings() -> None:
    os.startfile("ms-settings:defaultapps")  # type: ignore[attr-defined]


def _notify():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)
    except Exception:
        pass
