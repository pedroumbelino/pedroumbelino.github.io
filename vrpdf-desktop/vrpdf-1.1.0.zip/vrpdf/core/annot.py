"""Anotações: realçar, sublinhar, riscar, notas, desenho, formas, nuvens de revisão e carimbos."""
from __future__ import annotations

import datetime as _dt
import io
import os

import pymupdf

from .edit import _hex_to_rgb, _win_fonts

AUTHOR = os.environ.get("USERNAME") or os.environ.get("USER") or "VR PDF"


def _info(annot, author=None):
    annot.set_info(title=author or AUTHOR)


def words_in_rect(page, rect) -> list[pymupdf.Rect]:
    """Retângulos das palavras dentro de uma área (para realçar por arrasto)."""
    r = pymupdf.Rect(rect)
    words = [pymupdf.Rect(w[:4]) for w in page.get_text("words") if pymupdf.Rect(w[:4]).intersects(r)]
    return words


def _merge_line_quads(rects: list[pymupdf.Rect]) -> list[pymupdf.Quad]:
    lines: list[pymupdf.Rect] = []
    for w in sorted(rects, key=lambda r: (round(r.y0 / 3), r.x0)):
        for i, l in enumerate(lines):
            if abs(l.y0 - w.y0) < w.height * 0.5 and w.x0 - l.x1 < w.height * 1.5:
                lines[i] = l | w
                break
        else:
            lines.append(pymupdf.Rect(w))
    return [l.quad for l in lines]


def text_markup(page, rect, kind: str = "highlight", color=None):
    """kind: highlight | underline | strike | squiggly. Devolve a anotação ou None se não houver texto."""
    rects = words_in_rect(page, rect)
    if not rects:
        return None
    quads = _merge_line_quads(rects)
    fn = {"highlight": page.add_highlight_annot, "underline": page.add_underline_annot,
          "strike": page.add_strikeout_annot, "squiggly": page.add_squiggly_annot}[kind]
    a = fn(quads)
    if color:
        a.set_colors(stroke=_hex_to_rgb(color))
    _info(a)
    a.update()
    return a


def note(page, point, text: str, color="#F2C200"):
    a = page.add_text_annot(pymupdf.Point(point), text, icon="Comment")
    a.set_colors(stroke=_hex_to_rgb(color))
    _info(a)
    a.update()
    return a


def free_text_comment(page, rect, text: str, color="#C8302B", size=10):
    a = page.add_freetext_annot(pymupdf.Rect(rect), text, fontsize=size, fontname="helv",
                                text_color=_hex_to_rgb(color), fill_color=(1, 1, 0.85), border_color=_hex_to_rgb(color))
    _info(a)
    a.update()
    return a


def ink(page, strokes: list[list[tuple[float, float]]], color="#C8302B", width=2.0):
    a = page.add_ink_annot(strokes)
    a.set_colors(stroke=_hex_to_rgb(color))
    a.set_border(width=width)
    _info(a)
    a.update()
    return a


def rectangle(page, rect, color="#C8302B", width=2.0, fill=None):
    a = page.add_rect_annot(pymupdf.Rect(rect))
    a.set_colors(stroke=_hex_to_rgb(color), fill=_hex_to_rgb(fill) if fill else None)
    a.set_border(width=width)
    _info(a)
    a.update()
    return a


def ellipse(page, rect, color="#C8302B", width=2.0):
    a = page.add_circle_annot(pymupdf.Rect(rect))
    a.set_colors(stroke=_hex_to_rgb(color))
    a.set_border(width=width)
    _info(a)
    a.update()
    return a


def arrow(page, p1, p2, color="#C8302B", width=2.0):
    a = page.add_line_annot(pymupdf.Point(p1), pymupdf.Point(p2))
    a.set_colors(stroke=_hex_to_rgb(color))
    a.set_border(width=width)
    a.set_line_ends(pymupdf.PDF_ANNOT_LE_NONE, pymupdf.PDF_ANNOT_LE_CLOSED_ARROW)
    a.set_colors(stroke=_hex_to_rgb(color), fill=_hex_to_rgb(color))
    _info(a)
    a.update()
    return a


def line(page, p1, p2, color="#C8302B", width=2.0):
    a = page.add_line_annot(pymupdf.Point(p1), pymupdf.Point(p2))
    a.set_colors(stroke=_hex_to_rgb(color))
    a.set_border(width=width)
    _info(a)
    a.update()
    return a


def cloud(page, rect, color="#C8302B", width=1.5):
    """Nuvem de revisão (como nos desenhos de projeto)."""
    r = pymupdf.Rect(rect)
    pts = [r.tl, r.tr, r.br, r.bl, r.tl]
    a = page.add_polygon_annot(pts)
    a.set_colors(stroke=_hex_to_rgb(color))
    try:
        a.set_border(width=width, clouds=2)
    except TypeError:
        a.set_border(width=width)
    _info(a)
    a.update()
    return a


# ---------------------------------------------------------------- carimbos
STAMPS = {
    "APROVADO": "#1F7A4D",
    "REVISTO": "#2F4FA8",
    "PARA EXECUÇÃO": "#1F7A4D",
    "PARA APROVAÇÃO": "#8A5A00",
    "NÃO APROVADO": "#C8302B",
    "CONFIDENCIAL": "#C8302B",
    "RASCUNHO": "#6B6B6B",
    "CÓPIA": "#6B6B6B",
}


def _pil_font(size: int, bold=True):
    from PIL import ImageFont
    for name in (("arialbd.ttf", "arial.ttf") if bold else ("arial.ttf",)):
        p = os.path.join(_win_fonts(), name)
        if os.path.isfile(p):
            return ImageFont.truetype(p, size)
    for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"):
        if os.path.isfile(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def stamp_png(text: str, color: str = "#1F7A4D", subtitle: str | None = None, scale: int = 4) -> bytes:
    """Gera um carimbo (moldura dupla, texto e data) em PNG transparente."""
    from PIL import Image, ImageDraw
    if subtitle is None:
        subtitle = f"{AUTHOR}  {_dt.date.today().strftime('%d/%m/%Y')}"
    f1 = _pil_font(26 * scale, True)
    f2 = _pil_font(11 * scale, False)
    tmp = Image.new("RGBA", (10, 10))
    d = ImageDraw.Draw(tmp)
    w1 = d.textlength(text, font=f1)
    w2 = d.textlength(subtitle, font=f2) if subtitle else 0
    pad = 14 * scale
    W = int(max(w1, w2) + 2 * pad)
    H = int(26 * scale * 1.25 + (11 * scale * 1.6 if subtitle else 0) + 2 * pad * 0.8)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    rgb = tuple(int(color.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
    col = rgb + (235,)
    d.rounded_rectangle([2 * scale, 2 * scale, W - 2 * scale, H - 2 * scale], radius=8 * scale, outline=col, width=3 * scale)
    d.rounded_rectangle([6 * scale, 6 * scale, W - 6 * scale, H - 6 * scale], radius=6 * scale, outline=col, width=1 * scale)
    y = pad * 0.8
    d.text(((W - w1) / 2, y), text, font=f1, fill=col)
    if subtitle:
        d.text(((W - w2) / 2, y + 26 * scale * 1.25), subtitle, font=f2, fill=col)
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


def stamp(page, point, text: str, color: str | None = None, subtitle: str | None = None, width_pt: float = 150):
    """Coloca um carimbo centrado no ponto. Devolve o retângulo usado."""
    from PIL import Image
    color = color or STAMPS.get(text.upper(), "#C8302B")
    data = stamp_png(text, color, subtitle)
    im = Image.open(io.BytesIO(data))
    h = width_pt * im.height / im.width
    p = pymupdf.Point(point)
    r = pymupdf.Rect(p.x - width_pt / 2, p.y - h / 2, p.x + width_pt / 2, p.y + h / 2)
    page.insert_image(r, stream=data, overlay=True)
    return r


def list_annotations(doc) -> list[dict]:
    res = []
    for page in doc:
        for a in page.annots() or []:
            info = a.info
            res.append({"page": page.number, "type": a.type[1], "author": info.get("title", ""),
                        "content": info.get("content", ""), "rect": a.rect, "xref": a.xref})
    return res


def delete_annotation(page, xref: int) -> bool:
    for a in page.annots() or []:
        if a.xref == xref:
            page.delete_annot(a)
            return True
    return False
