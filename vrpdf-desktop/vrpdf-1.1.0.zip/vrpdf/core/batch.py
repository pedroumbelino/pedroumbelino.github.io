"""Processamento em lote: a mesma operação sobre muitos ficheiros."""
from __future__ import annotations

from pathlib import Path
from typing import Callable

import pymupdf

from . import convert, organize, edit, security
from .util import out_path

# nome visível -> (extensões de entrada, função(src, out_dir, opts) -> lista de caminhos criados)
OPERATIONS: dict[str, tuple[set[str], Callable]] = {}


def op(name: str, exts=(".pdf",)):
    def deco(fn):
        OPERATIONS[name] = (set(exts), fn)
        return fn
    return deco


@op("Converter para Word")
def _word(src, od, o):
    return [convert.pdf_to_word(src, out_path(src, ".docx", out_dir=od))]


@op("Converter para Excel")
def _excel(src, od, o):
    return [convert.pdf_to_excel(src, out_path(src, ".xlsx", out_dir=od))]


@op("Converter para PowerPoint")
def _ppt(src, od, o):
    return [convert.pdf_to_pptx(src, out_path(src, ".pptx", out_dir=od))]


@op("Converter para imagens (PNG)")
def _png(src, od, o):
    target = Path(od) / f"{Path(src).stem} - imagens" if od else None
    return convert.pdf_to_images(src, str(target) if target else None, "png", int(o.get("dpi", 200)))


@op("Comprimir")
def _compress(src, od, o):
    p, _, _ = organize.compress(src, out_path(src, ".pdf", "(comprimido)", od), o.get("nivel", "média"))
    return [p]


@op("OCR (tornar pesquisável)")
def _ocr(src, od, o):
    return [convert.ocr_pdf(src, out_path(src, ".pdf", "(OCR)", od))]


@op("Numerar páginas")
def _number(src, od, o):
    doc = pymupdf.open(src)
    edit.header_footer(doc, footer_right=o.get("texto", "Página {n} de {total}"), filename=Path(src).name)
    p = out_path(src, ".pdf", "(numerado)", od)
    doc.save(p, garbage=3, deflate=True)
    doc.close()
    return [p]


@op("Marca d'água")
def _wm(src, od, o):
    doc = pymupdf.open(src)
    edit.watermark_text(doc, o.get("texto", "CÓPIA"))
    p = out_path(src, ".pdf", "(marca)", od)
    doc.save(p, garbage=3, deflate=True)
    doc.close()
    return [p]


@op("Carimbar todas as páginas")
def _stamp(src, od, o):
    from . import annot
    doc = pymupdf.open(src)
    for page in doc:
        r = page.rect
        annot.stamp(page, (r.width - 100, 60), o.get("texto", "APROVADO"), width_pt=140)
    p = out_path(src, ".pdf", "(carimbado)", od)
    doc.save(p, garbage=3, deflate=True)
    doc.close()
    return [p]


@op("Limpar metadados")
def _meta(src, od, o):
    doc = pymupdf.open(src)
    security.clean_metadata(doc)
    p = out_path(src, ".pdf", "(limpo)", od)
    doc.save(p, garbage=4, deflate=True)
    doc.close()
    return [p]


@op("Proteger com palavra-passe")
def _pw(src, od, o):
    doc = pymupdf.open(src)
    p = out_path(src, ".pdf", "(protegido)", od)
    security.save_encrypted(doc, str(p), o.get("password", ""))
    doc.close()
    return [p]


@op("Rodar 90°")
def _rot(src, od, o):
    doc = pymupdf.open(src)
    organize.rotate_pages(doc, list(range(doc.page_count)), int(o.get("angulo", 90)))
    p = out_path(src, ".pdf", "(rodado)", od)
    doc.save(p, garbage=3, deflate=True)
    doc.close()
    return [p]


@op("Office para PDF", exts=tuple(convert.OFFICE_EXT))
def _office(src, od, o):
    return [convert.office_to_pdf(src, out_path(src, ".pdf", out_dir=od))]


@op("Imagem para PDF", exts=(".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"))
def _img(src, od, o):
    return [convert.images_to_pdf([src], str(out_path(src, ".pdf", out_dir=od)), "A4" if o.get("a4", True) else "auto")]


def run(op_name: str, files: list[str], out_dir: str | None = None, options: dict | None = None,
        progress=None, cancelled=lambda: False) -> tuple[list[Path], list[tuple[str, str]]]:
    """Devolve (ficheiros criados, erros [(ficheiro, mensagem)])."""
    exts, fn = OPERATIONS[op_name]
    options = options or {}
    created, errors = [], []
    todo = [f for f in files if Path(f).suffix.lower() in exts]
    skipped = [f for f in files if f not in todo]
    for f in skipped:
        errors.append((f, "Tipo de ficheiro não suportado por esta operação"))
    for i, f in enumerate(todo):
        if cancelled():
            break
        if progress:
            progress(i, len(todo), Path(f).name)
        try:
            created += fn(f, out_dir, options)
        except Exception as e:
            errors.append((f, str(e)))
    if progress:
        progress(len(todo), len(todo), "Concluído")
    return created, errors
