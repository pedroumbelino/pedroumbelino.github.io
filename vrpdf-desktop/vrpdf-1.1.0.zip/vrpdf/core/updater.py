"""Atualizações pela internet: compara a versão instalada com a publicada no site e instala a nova.

No site (GitHub Pages) existem:
  vrpdf-desktop/versao.json   {"versao": "1.2.0", "ficheiro": "vrpdf-1.2.0.zip", "sha256": "...",
                               "notas": ["..."], "minimo_exe": "1.1.0"}
  vrpdf-desktop/vrpdf-1.2.0.zip   (só o código do programa: pasta vrpdf/ com os .py)
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import ssl
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

from .util import APP_VERSION

SITE = os.environ.get("VRPDF_SITE", "https://pedroumbelino.github.io/vrpdf-desktop/")
TIMEOUT = 20


def vt(v) -> tuple:
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return (0,)


def updates_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / ".local" / "share")
    d = Path(base) / "VR PDF" / "atualizacoes"
    d.mkdir(parents=True, exist_ok=True)
    return d


def exe_version() -> str:
    """Versão do .exe instalado (a que vem incluída), independentemente do código atualizado."""
    try:
        import __main__
        return getattr(__main__, "BUNDLED_VERSION", APP_VERSION)
    except Exception:
        return APP_VERSION


def _get(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": f"VR-PDF/{APP_VERSION}", "Cache-Control": "no-cache"})
    ctx = ssl.create_default_context()
    try:
        import certifi  # type: ignore
        ctx = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass
    with urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx) as r:
        return r.read()


def check() -> dict:
    """Devolve {'nova': bool, 'versao', 'notas', 'precisa_exe': bool, ...}. Lança exceção sem rede."""
    import time
    info = json.loads(_get(SITE + f"versao.json?t={int(time.time())}").decode("utf-8"))
    info["nova"] = vt(info.get("versao")) > vt(APP_VERSION)
    info["precisa_exe"] = vt(info.get("minimo_exe", "0")) > vt(exe_version())
    info["atual"] = APP_VERSION
    return info


def install(info: dict, progress=None) -> Path:
    """Descarrega, confirma o SHA-256, extrai para atualizacoes/app-<versão> e marca como atual."""
    if progress:
        progress(0, 3, "A descarregar…")
    data = _get(SITE + info["ficheiro"])
    if info.get("sha256") and hashlib.sha256(data).hexdigest() != info["sha256"].lower():
        raise RuntimeError("O ficheiro descarregado está corrompido (SHA-256 não confere). Tenta de novo.")
    if progress:
        progress(1, 3, "A instalar…")
    d = updates_dir()
    target = d / f"app-{info['versao']}"
    tmp = d / f"_tmp-{info['versao']}"
    shutil.rmtree(tmp, ignore_errors=True)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for m in z.infolist():
            name = m.filename.replace("\\", "/")
            if name.startswith("/") or ".." in name.split("/") or not name.startswith("vrpdf/"):
                continue  # só aceita a pasta vrpdf/
            z.extract(m, tmp)
    if not (tmp / "vrpdf" / "main.py").exists():
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("A atualização não tem o formato esperado.")
    shutil.rmtree(target, ignore_errors=True)
    tmp.rename(target)
    (d / "atual.json").write_text(json.dumps({"versao": info["versao"], "pasta": target.name}, indent=1), encoding="utf-8")
    # limpa versões antigas (mantém a atual e a anterior)
    olds = sorted([p for p in d.glob("app-*") if p != target], key=lambda p: vt(p.name[4:]))
    for p in olds[:-1]:
        shutil.rmtree(p, ignore_errors=True)
    if progress:
        progress(3, 3, "Concluído")
    return target


def last_failure() -> str | None:
    try:
        info = json.loads((updates_dir() / "atual.json").read_text(encoding="utf-8"))
        return info.get("erro") if info.get("falhou") else None
    except Exception:
        return None


def revert() -> None:
    """Volta à versão incluída no .exe."""
    p = updates_dir() / "atual.json"
    if p.exists():
        p.unlink()


def restart() -> None:
    """Arranca uma nova cópia (que não se liga à atual) — quem chama deve fechar a janela a seguir."""
    env = dict(os.environ, VRPDF_REINICIO="1")
    args = [sys.executable] if getattr(sys, "frozen", False) else [sys.executable] + sys.argv[:1]
    subprocess.Popen(args, close_fds=True, env=env)
