"""Valores por extenso em português europeu (ex.: 1050,00 -> 'Mil e cinquenta euros')."""
from __future__ import annotations

_U = ["zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez", "onze", "doze",
      "treze", "catorze", "quinze", "dezasseis", "dezassete", "dezoito", "dezanove"]
_D = ["", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"]
_C = ["", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos",
      "oitocentos", "novecentos"]


def _ate_mil(n: int) -> str:
    if n < 20:
        return _U[n]
    if n < 100:
        d, u = divmod(n, 10)
        return _D[d] + (f" e {_U[u]}" if u else "")
    if n == 100:
        return "cem"
    c, r = divmod(n, 100)
    return _C[c] + (f" e {_ate_mil(r)}" if r else "")


def numero(n: int) -> str:
    if n == 0:
        return "zero"
    partes = []
    grupos = [(10 ** 9, "mil milhões", "mil milhões"), (10 ** 6, "milhão", "milhões"), (1000, "mil", "mil")]
    resto = n
    for valor, sing, plur in grupos:
        q, resto = divmod(resto, valor)
        if q:
            if valor == 1000 and q == 1:
                partes.append("mil")
            else:
                partes.append(f"{numero(q)} {sing if q == 1 else plur}")
    if resto:
        partes.append(_ate_mil(resto))
    if len(partes) == 1:
        return partes[0]
    # "e" antes do último grupo quando este é < 100 ou centena redonda
    ultimo = partes[-1]
    if resto and (resto < 100 or resto % 100 == 0):
        return " ".join(partes[:-1]) + " e " + ultimo
    return " ".join(partes)


def euros(valor: float) -> str:
    cent = round(valor * 100)
    e, c = divmod(cent, 100)
    s = ""
    if e:
        s = numero(e) + (" euro" if e == 1 else " euros")
        if e % 1_000_000 == 0 and e >= 1_000_000:
            s = numero(e) + " de euros"
    if c:
        s += (" e " if s else "") + numero(c) + (" cêntimo" if c == 1 else " cêntimos")
    s = s or "zero euros"
    return s[0].upper() + s[1:]


def fmt_eur(v: float) -> str:
    """1050.0 -> '1’050,00 €' (formato usado nas propostas VR)."""
    s = f"{v:,.2f}"  # 1,050.00
    inteiro, dec = s.split(".")
    return inteiro.replace(",", "’") + "," + dec + " €"


def parse_eur(s: str) -> float | None:
    import re
    t = str(s).replace("€", "").replace(" ", " ").strip()
    t = re.sub(r"[\s’']", "", t)
    if not t:
        return None
    if "," in t and "." in t:
        if t.rfind(",") > t.rfind("."):
            t = t.replace(".", "").replace(",", ".")
        else:
            t = t.replace(",", "")
    elif "," in t:
        t = t.replace(",", ".")
    try:
        return float(t)
    except ValueError:
        return None
