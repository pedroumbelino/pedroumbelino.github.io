"""Arranque do VR PDF.

Utilização:
  VR PDF.exe [ficheiros...]             abre os ficheiros
  VR PDF.exe --word ficheiro.pdf         converte para Word (usado pelo menu do botão direito)
  VR PDF.exe --excel | --comprimir | --ocr | --pdf ficheiro
  VR PDF.exe --juntar a.pdf b.pdf ...    junta (vários cliques do Explorador são agregados)
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ACTIONS = {"--word", "--excel", "--comprimir", "--ocr", "--juntar", "--pdf"}
SERVER = "VRPDF-" + (os.environ.get("USERNAME") or os.environ.get("USER") or "user")


def _parse(argv):
    action = None
    files = []
    for a in argv:
        if a in ACTIONS:
            action = a
        elif not a.startswith("--"):
            files.append(str(Path(a).resolve()))
    return action, files


def main():
    import logging
    logging.getLogger("pyhanko").setLevel(logging.ERROR)
    logging.getLogger("pyhanko_certvalidator").setLevel(logging.ERROR)
    os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
    from PySide6.QtCore import Qt, QTimer
    from PySide6.QtGui import QIcon
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    from PySide6.QtWidgets import QApplication

    action, files = _parse(sys.argv[1:])

    app = QApplication(sys.argv)
    app.setApplicationName("VR PDF")
    app.setOrganizationName("Ventura Rodrigues")
    app.setQuitOnLastWindowClosed(True)

    # instância única: se já houver uma janela aberta, envia-lhe os ficheiros
    sock = QLocalSocket()
    if not os.environ.pop("VRPDF_REINICIO", None):
        sock.connectToServer(SERVER)
    if sock.state() == QLocalSocket.ConnectingState or sock.state() == QLocalSocket.ConnectedState:
        connected = sock.waitForConnected(300)
    else:
        connected = False
    if connected:
        sock.write(json.dumps({"action": action, "files": files}).encode("utf-8"))
        sock.flush()
        sock.waitForBytesWritten(1000)
        sock.disconnectFromServer()
        return 0

    from .ui import theme, dialogs
    from .core.util import resource_path
    theme.apply(app, dialogs.settings().value("dark", False, type=bool))
    ico = resource_path("assets", "vrpdf.ico")
    if ico.exists():
        app.setWindowIcon(QIcon(str(ico)))

    from .ui.mainwindow import MainWindow
    win = MainWindow()

    pending = {"juntar": [], "timer": None}

    def handle(action, files):
        if action is None:
            if files:
                win.open_files(files)
            win.showNormal()
            win.raise_()
            win.activateWindow()
            return
        if action == "--juntar":
            # o Explorador lança um processo por ficheiro: agrega durante 1,5 s
            pending["juntar"] += [f for f in files if f not in pending["juntar"]]
            if pending["timer"] is None:
                t = QTimer()
                t.setSingleShot(True)
                t.timeout.connect(lambda: (win.show(), win.merge(sorted(pending["juntar"])),
                                           pending.update(juntar=[], timer=None)))
                pending["timer"] = t
            pending["timer"].start(1500)
            return
        run_cli_action(win, action, files)

    server = QLocalServer()
    QLocalServer.removeServer(SERVER)
    server.listen(SERVER)

    def on_conn():
        c = server.nextPendingConnection()

        def read():
            try:
                msg = json.loads(bytes(c.readAll()).decode("utf-8") or "{}")
                handle(msg.get("action"), msg.get("files", []))
            except Exception:
                pass

        c.readyRead.connect(read)

    server.newConnection.connect(on_conn)

    selftest = os.environ.get("VRPDF_SELFTEST")
    if selftest:
        QTimer.singleShot(4000, lambda: _selftest(win, selftest, files))

    if action:
        win.show()
        QTimer.singleShot(100, lambda: handle(action, files))
    else:
        win.show()
        if files:
            QTimer.singleShot(50, lambda: win.open_files(files))
    return app.exec()


def _selftest(win, out_dir, files):
    """Autoteste da versão compilada: VRPDF_SELFTEST=<pasta> "VR PDF.exe" ficheiro.pdf"""
    import traceback
    from PySide6.QtWidgets import QApplication
    from .core import convert, organize, util
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    report = []

    def check(name, fn):
        try:
            report.append(f"OK   {name}: {fn()}")
        except Exception:
            report.append(f"FAIL {name}:\n{traceback.format_exc()}")

    win.grab().save(str(out / "janela.png"))
    report.append(f"versão {util.APP_VERSION}, tessdata={util.tessdata_dir()}, idiomas={util.ocr_languages()}")
    if files:
        f = files[0]
        check("PDF para Word", lambda: convert.pdf_to_word(f, str(out / "teste.docx")))
        check("PDF para Excel", lambda: convert.pdf_to_excel(f, str(out / "teste.xlsx")))
        check("Comprimir", lambda: organize.compress(f, str(out / "teste_comp.pdf"))[1:])
        check("OCR", lambda: convert.ocr_pdf(f, str(out / "teste_ocr.pdf"), only_if_needed=False))
        check("Proposta VR", lambda: __import__("vrpdf.core.proposta_vr", fromlist=["x"]).build_docx(
            __import__("vrpdf.core.proposta_vr", fromlist=["x"]).parse_supplier_pdf(f), str(out / "proposta.docx")))
    (out / "relatorio.txt").write_text("\n".join(report), encoding="utf-8")
    QApplication.instance().quit()


def run_cli_action(win, action, files):
    from .core import convert, organize
    from .ui.worker import run_task, result_box, open_path
    from .ui import dialogs
    win.show()
    for f in files:
        name = Path(f).name
        if action == "--word":
            run_task(win, f"A converter {name} para Word", convert.pdf_to_word, f, on_done=lambda r: open_path(r))
        elif action == "--excel":
            run_task(win, f"A converter {name} para Excel", convert.pdf_to_excel, f, on_done=lambda r: open_path(r))
        elif action == "--comprimir":
            dlg = dialogs.CompressDialog(win, Path(f).stat().st_size)
            if dlg.exec():
                run_task(win, f"A comprimir {name}", organize.compress, f, None, dlg.value(), progress=False,
                         on_done=win._compress_done)
        elif action == "--ocr":
            if not convert.ocr_available():
                win.ocr_current()
                return
            run_task(win, f"OCR de {name}", convert.ocr_pdf, f, on_done=lambda r: win.open_pdf(str(r)))
        elif action == "--pdf":
            win.open_files([f])


if __name__ == "__main__":
    sys.exit(main())
