"""Aspeto visual: modo claro/escuro, folha de estilos e ícones."""
from __future__ import annotations

from PySide6.QtGui import QColor, QPalette, QIcon
from PySide6.QtWidgets import QApplication

ACCENT = "#C8302B"  # vermelho Ventura Rodrigues

LIGHT = dict(bg="#F3F4F7", surface="#FFFFFF", surface2="#ECEEF2", fg="#1B2230", muted="#5E6878",
             line="#D9DDE4", accent=ACCENT, accent_fg="#FFFFFF", canvas="#C9CDD4", sel="#F6D9D7")
DARK = dict(bg="#161A21", surface="#1F242D", surface2="#272D38", fg="#E6E9EF", muted="#9AA3B2",
            line="#323A47", accent="#FF6B5E", accent_fg="#16191F", canvas="#0F1217", sel="#4A2724")

_current = {"dark": False}


def is_dark() -> bool:
    return _current["dark"]


def colors() -> dict:
    return DARK if _current["dark"] else LIGHT


def icon(name: str, color: str | None = None) -> QIcon:
    import qtawesome as qta
    c = color or colors()["fg"]
    try:
        return qta.icon("mdi6." + name, color=c, color_disabled=colors()["muted"])
    except Exception:
        return QIcon()


def apply(app: QApplication, dark: bool) -> None:
    _current["dark"] = dark
    c = colors()
    app.setStyle("Fusion")
    pal = QPalette()
    pal.setColor(QPalette.Window, QColor(c["bg"]))
    pal.setColor(QPalette.WindowText, QColor(c["fg"]))
    pal.setColor(QPalette.Base, QColor(c["surface"]))
    pal.setColor(QPalette.AlternateBase, QColor(c["surface2"]))
    pal.setColor(QPalette.Text, QColor(c["fg"]))
    pal.setColor(QPalette.Button, QColor(c["surface"]))
    pal.setColor(QPalette.ButtonText, QColor(c["fg"]))
    pal.setColor(QPalette.Highlight, QColor(c["accent"]))
    pal.setColor(QPalette.HighlightedText, QColor(c["accent_fg"]))
    pal.setColor(QPalette.ToolTipBase, QColor(c["surface"]))
    pal.setColor(QPalette.ToolTipText, QColor(c["fg"]))
    pal.setColor(QPalette.PlaceholderText, QColor(c["muted"]))
    pal.setColor(QPalette.Link, QColor(c["accent"]))
    for role in (QPalette.WindowText, QPalette.Text, QPalette.ButtonText):
        pal.setColor(QPalette.Disabled, role, QColor(c["muted"]))
    app.setPalette(pal)
    app.setStyleSheet(stylesheet())


def stylesheet() -> str:
    c = colors()
    return f"""
    QWidget {{ font-family: 'Segoe UI', 'Inter', sans-serif; font-size: 10pt; }}
    QMainWindow, QDialog {{ background: {c['bg']}; }}
    #Ribbon {{ background: {c['surface']}; border-bottom: 1px solid {c['line']}; }}
    #RibbonTabs QTabBar::tab {{ background: transparent; color: {c['muted']}; padding: 7px 14px; border: none;
        font-weight: 600; }}
    #RibbonTabs QTabBar::tab:selected {{ color: {c['fg']}; border-bottom: 3px solid {c['accent']}; }}
    #RibbonTabs QTabBar::tab:hover {{ color: {c['fg']}; }}
    #RibbonTabs::pane {{ border: none; }}
    #RibbonPage {{ background: {c['surface']}; }}
    QToolButton#Big {{ border: 1px solid transparent; border-radius: 6px; padding: 4px 6px; color: {c['fg']};
        min-width: 64px; }}
    QToolButton#Big:hover {{ background: {c['surface2']}; border-color: {c['line']}; }}
    QToolButton#Big:checked {{ background: {c['sel']}; border-color: {c['accent']}; }}
    QToolButton#Big:pressed {{ background: {c['sel']}; }}
    #GroupLabel {{ color: {c['muted']}; font-size: 8pt; }}
    #GroupSep {{ background: {c['line']}; }}
    QTabWidget#Docs::pane {{ border: none; }}
    QTabWidget#Docs QTabBar::tab {{ background: {c['surface2']}; color: {c['muted']}; padding: 6px 12px;
        border: 1px solid {c['line']}; border-bottom: none; border-top-left-radius: 6px; border-top-right-radius: 6px;
        margin-right: 2px; }}
    QTabWidget#Docs QTabBar::tab:selected {{ background: {c['surface']}; color: {c['fg']}; }}
    #Canvas {{ background: {c['canvas']}; border: none; }}
    #Side {{ background: {c['surface']}; border-right: 1px solid {c['line']}; }}
    QListWidget {{ background: {c['surface']}; border: none; outline: none; }}
    QListWidget::item:selected {{ background: {c['sel']}; color: {c['fg']}; border-radius: 4px; }}
    QStatusBar {{ background: {c['surface']}; border-top: 1px solid {c['line']}; color: {c['muted']}; }}
    QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QTextEdit, QPlainTextEdit {{ background: {c['surface']};
        border: 1px solid {c['line']}; border-radius: 5px; padding: 4px 6px; color: {c['fg']}; }}
    QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus {{ border-color: {c['accent']}; }}
    QPushButton {{ background: {c['surface']}; border: 1px solid {c['line']}; border-radius: 6px; padding: 6px 14px;
        color: {c['fg']}; }}
    QPushButton:hover {{ border-color: {c['muted']}; }}
    QPushButton#Primary {{ background: {c['accent']}; color: {c['accent_fg']}; border-color: {c['accent']};
        font-weight: 600; }}
    QPushButton#Primary:disabled {{ background: {c['line']}; color: {c['muted']}; border-color: {c['line']}; }}
    #Start {{ background: {c['bg']}; }}
    #StartTitle {{ font-size: 22pt; font-weight: 700; color: {c['fg']}; }}
    #StartSub {{ color: {c['muted']}; font-size: 11pt; }}
    #Tile {{ background: {c['surface']}; border: 1px solid {c['line']}; border-radius: 10px; text-align: left;
        padding: 12px; }}
    #Tile:hover {{ border-color: {c['accent']}; }}
    #Drop {{ border: 2px dashed {c['line']}; border-radius: 12px; background: {c['surface']}; }}
    #Muted {{ color: {c['muted']}; }}
    #ToolProps {{ background: {c['surface2']}; border-bottom: 1px solid {c['line']}; }}
    #SearchBar {{ background: {c['surface']}; border: 1px solid {c['line']}; border-radius: 8px; }}
    QProgressBar {{ border: 1px solid {c['line']}; border-radius: 5px; background: {c['surface2']}; text-align: center;
        color: {c['fg']}; height: 16px; }}
    QProgressBar::chunk {{ background: {c['accent']}; border-radius: 4px; }}
    QMenu {{ background: {c['surface']}; border: 1px solid {c['line']}; color: {c['fg']}; }}
    QMenu::item:selected {{ background: {c['sel']}; color: {c['fg']}; }}
    QGroupBox {{ border: 1px solid {c['line']}; border-radius: 8px; margin-top: 12px; padding-top: 8px; color: {c['fg']}; }}
    QGroupBox::title {{ subcontrol-origin: margin; left: 10px; padding: 0 4px; color: {c['muted']}; }}
    QTableWidget {{ background: {c['surface']}; gridline-color: {c['line']}; border: 1px solid {c['line']}; }}
    QHeaderView::section {{ background: {c['surface2']}; color: {c['fg']}; border: none; padding: 4px;
        border-right: 1px solid {c['line']}; }}
    QScrollBar:vertical {{ background: transparent; width: 11px; }}
    QScrollBar::handle:vertical {{ background: {c['line']}; border-radius: 5px; min-height: 30px; }}
    QScrollBar:horizontal {{ background: transparent; height: 11px; }}
    QScrollBar::handle:horizontal {{ background: {c['line']}; border-radius: 5px; min-width: 30px; }}
    QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
    """
