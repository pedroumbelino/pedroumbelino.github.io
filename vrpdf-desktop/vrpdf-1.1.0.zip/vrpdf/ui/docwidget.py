"""Um documento aberto: vista de páginas, painel lateral (páginas, comentários, campos, marcadores),
pesquisa, anular/refazer e todas as operações de edição sobre o documento."""
from __future__ import annotations

from pathlib import Path

import pymupdf
from PySide6.QtCore import Qt, Signal, QSize, QTimer
from PySide6.QtGui import QImage, QPixmap, QIcon, QAction, QKeySequence, QShortcut, QGuiApplication
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QSplitter, QListWidget, QListWidgetItem,
                               QTabWidget, QLineEdit, QPushButton, QLabel, QToolButton, QMenu, QMessageBox,
                               QInputDialog, QFileDialog, QTreeWidget, QTreeWidgetItem, QFormLayout,
                               QScrollArea, QComboBox, QCheckBox, QAbstractItemView, QFrame)

from ..core import edit, annot, organize, forms, security
from . import theme
from . import pageview as pv

UNDO_LIMIT = 40


class Thumbs(QListWidget):
    reordered = Signal(list)

    def __init__(self):
        super().__init__()
        self.setViewMode(QListWidget.IconMode)
        self.setFlow(QListWidget.LeftToRight)
        self.setWrapping(True)
        self.setResizeMode(QListWidget.Adjust)
        self.setMovement(QListWidget.Snap)
        self.setIconSize(QSize(110, 150))
        self.setSpacing(6)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setDragDropMode(QAbstractItemView.InternalMove)
        self.setDefaultDropAction(Qt.MoveAction)
        self.setGridSize(QSize(132, 178))

    def dropEvent(self, e):
        super().dropEvent(e)
        order = [self.item(i).data(Qt.UserRole) for i in range(self.count())]
        if order != sorted(order):
            self.reordered.emit(order)


class DocWidget(QWidget):
    changed = Signal()          # conteúdo alterado (título com •)
    status = Signal(str)        # mensagem para a barra de estado
    pageInfo = Signal(int, int)  # página atual, total

    def __init__(self, path: str | None, data: bytes | None = None, password: str | None = None, parent=None):
        super().__init__(parent)
        self.path = Path(path) if path else None
        raw = data if data is not None else Path(path).read_bytes()
        self.doc = pymupdf.open(stream=raw, filetype="pdf")
        self.password = None
        if self.doc.needs_pass:
            if not password or not self.doc.authenticate(password):
                raise PermissionError("password")
            self.password = password
        self.dirty = False
        self.undo_stack: list[bytes] = []
        self.redo_stack: list[bytes] = []
        self.hits: list[tuple[int, pymupdf.Rect]] = []
        self.hit_i = -1
        self.selected_annot = None  # (page, xref)
        self.pending_image = None   # imagem escolhida para mover
        self._build()
        self.view.set_document(self.doc)
        self.refresh_side()
        QTimer.singleShot(0, self.view.apply_fit)

    # ------------------------------------------------------------------ interface
    def _build(self):
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        split = QSplitter(Qt.Horizontal)
        lay.addWidget(split)

        self.side = QTabWidget()
        self.side.setObjectName("Side")
        self.side.setMinimumWidth(170)
        self.thumbs = Thumbs()
        self.thumbs.itemClicked.connect(lambda it: self.view.go_to_page(it.data(Qt.UserRole)))
        self.thumbs.reordered.connect(self.reorder_pages)
        self.thumbs.setContextMenuPolicy(Qt.CustomContextMenu)
        self.thumbs.customContextMenuRequested.connect(self._thumb_menu)
        self.side.addTab(self.thumbs, theme.icon("view-grid"), "")
        self.side.setTabToolTip(0, "Páginas")
        self.comments = QListWidget()
        self.comments.itemClicked.connect(self._goto_comment)
        self.side.addTab(self.comments, theme.icon("note-text"), "")
        self.side.setTabToolTip(1, "Comentários")
        self.fields_panel = QScrollArea()
        self.fields_panel.setWidgetResizable(True)
        self.side.addTab(self.fields_panel, theme.icon("form-textbox"), "")
        self.side.setTabToolTip(2, "Campos do formulário")
        self.toc = QTreeWidget()
        self.toc.setHeaderHidden(True)
        self.toc.itemClicked.connect(lambda it: self.view.go_to_page(it.data(0, Qt.UserRole)))
        self.side.addTab(self.toc, theme.icon("file-tree"), "")
        self.side.setTabToolTip(3, "Marcadores")
        split.addWidget(self.side)

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(0)
        # barra de pesquisa
        self.search_bar = QFrame()
        self.search_bar.setObjectName("SearchBar")
        sl = QHBoxLayout(self.search_bar)
        sl.setContentsMargins(8, 4, 8, 4)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Pesquisar no documento…")
        self.search_edit.returnPressed.connect(self.search_next)
        self.search_edit.textChanged.connect(lambda: setattr(self, "hits", []))
        self.search_case = QCheckBox("Maiúsculas")
        self.search_count = QLabel("")
        self.search_count.setObjectName("Muted")
        b_prev = QToolButton()
        b_prev.setIcon(theme.icon("chevron-up"))
        b_prev.clicked.connect(self.search_prev)
        b_next = QToolButton()
        b_next.setIcon(theme.icon("chevron-down"))
        b_next.clicked.connect(self.search_next)
        b_close = QToolButton()
        b_close.setIcon(theme.icon("close"))
        b_close.clicked.connect(self.hide_search)
        self._search_buttons = [(b_prev, "chevron-up"), (b_next, "chevron-down"), (b_close, "close")]
        for w in (QLabel(""), self.search_edit, self.search_case, self.search_count, b_prev, b_next, b_close):
            sl.addWidget(w)
        self.search_bar.hide()
        rl.addWidget(self.search_bar)
        self.view = pv.PageView()
        self.view.action.connect(self.on_action)
        self.view.contextRequested.connect(self.on_context)
        self.view.pageChanged.connect(self._page_changed)
        rl.addWidget(self.view)
        split.addWidget(right)
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        split.setSizes([220, 900])

    def recolor(self):
        for i, ic in enumerate(("view-grid", "note-text", "form-textbox", "file-tree")):
            self.side.setTabIcon(i, theme.icon(ic))
        for b, ic in self._search_buttons:
            b.setIcon(theme.icon(ic))

    def title(self) -> str:
        name = self.path.name if self.path else "Sem nome.pdf"
        return ("• " if self.dirty else "") + name

    # ------------------------------------------------------------------ painel lateral
    def refresh_side(self, thumbs=True):
        if thumbs:
            self._build_thumbs()
        self._build_comments()
        self._build_fields()
        self._build_toc()
        self.pageInfo.emit(self.view.current_page(), self.doc.page_count)

    def _build_thumbs(self):
        self.thumbs.clear()
        self._thumb_todo = list(range(self.doc.page_count))
        for i in range(self.doc.page_count):
            it = QListWidgetItem(str(i + 1))
            it.setData(Qt.UserRole, i)
            it.setTextAlignment(Qt.AlignHCenter)
            self.thumbs.addItem(it)
        QTimer.singleShot(0, self._render_thumbs_step)

    def _render_thumbs_step(self):
        # renderiza aos poucos para a janela não bloquear em PDFs grandes
        for _ in range(6):
            if not getattr(self, "_thumb_todo", None):
                return
            i = self._thumb_todo.pop(0)
            if i >= self.thumbs.count() or i >= self.doc.page_count:
                continue
            self._set_thumb(i)
        QTimer.singleShot(5, self._render_thumbs_step)

    def _set_thumb(self, i):
        page = self.doc[i]
        z = 150 / max(page.rect.width, page.rect.height)
        pix = page.get_pixmap(matrix=pymupdf.Matrix(z * 1.5, z * 1.5), alpha=False)
        img = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()
        self.thumbs.item(i).setIcon(QIcon(QPixmap.fromImage(img)))

    def update_thumbs(self, pages):
        for p in pages:
            if p < self.thumbs.count():
                self._set_thumb(p)

    def _build_comments(self):
        self.comments.clear()
        for a in annot.list_annotations(self.doc):
            if a["type"] in ("Widget", "Link", "Popup"):
                continue
            label = {"Highlight": "Realce", "Underline": "Sublinhado", "StrikeOut": "Riscado", "Text": "Nota",
                     "FreeText": "Comentário", "Ink": "Desenho", "Square": "Retângulo", "Circle": "Elipse",
                     "Line": "Seta/linha", "Polygon": "Nuvem", "Stamp": "Carimbo", "Squiggly": "Ondulado"}.get(a["type"], a["type"])
            txt = f"Pág. {a['page'] + 1}  {label}"
            if a["content"]:
                txt += f"\n{a['content'][:80]}"
            if a["author"]:
                txt += f"\n{a['author']}"
            it = QListWidgetItem(txt)
            it.setData(Qt.UserRole, (a["page"], a["xref"], a["rect"]))
            self.comments.addItem(it)
        if not self.comments.count():
            it = QListWidgetItem("Sem comentários.\nUsa o separador Rever para realçar, comentar ou desenhar.")
            it.setFlags(Qt.NoItemFlags)
            self.comments.addItem(it)

    def _goto_comment(self, it):
        d = it.data(Qt.UserRole)
        if d:
            n, xref, rect = d
            self.view.go_to_page(n, rect)
            self.view.flash_rect(n, rect)
            self.selected_annot = (n, xref)

    def _build_fields(self):
        w = QWidget()
        form = QFormLayout(w)
        self.field_editors = []
        fl = forms.list_fields(self.doc)
        if not fl:
            lab = QLabel("Este PDF não tem campos de formulário.\n\nPara criar campos, usa "
                         "Formulários > Criar campo e desenha um retângulo na página.")
            lab.setWordWrap(True)
            lab.setObjectName("Muted")
            form.addRow(lab)
        for f in fl:
            t = f["type"]
            if t in ("CheckBox", "RadioButton"):
                ed = QCheckBox()
                ed.setChecked(f["value"] not in ("Off", "", None, False))
            elif t in ("ComboBox", "ListBox"):
                ed = QComboBox()
                ed.addItems(f["options"])
                ed.setEditable(t == "ComboBox")
                ed.setCurrentText(str(f["value"] or ""))
            elif t == "Signature":
                continue
            else:
                ed = QLineEdit(str(f["value"] or ""))
            self.field_editors.append((f, ed))
            form.addRow(f"{f['name']} (p.{f['page'] + 1})", ed)
        if fl:
            b = QPushButton("Aplicar valores")
            b.setObjectName("Primary")
            b.clicked.connect(self.apply_fields)
            form.addRow(b)
            b2 = QPushButton("Fixar campos (deixam de ser editáveis)")
            b2.clicked.connect(self.flatten_fields)
            form.addRow(b2)
        self.fields_panel.setWidget(w)

    def apply_fields(self):
        self.snapshot()
        for f, ed in self.field_editors:
            if isinstance(ed, QCheckBox):
                v = ed.isChecked()
            elif isinstance(ed, QComboBox):
                v = ed.currentText()
            else:
                v = ed.text()
            forms.set_field(self.doc, f["page"], f["xref"], v)
        self.after_change(None, "Campos preenchidos")

    def flatten_fields(self):
        self.snapshot()
        forms.flatten(self.doc)
        self.after_change(None, "Campos fixados")

    def _build_toc(self):
        self.toc.clear()
        stack = [self.toc.invisibleRootItem()]
        for lvl, title, page, *_ in self.doc.get_toc():
            while len(stack) > lvl:
                stack.pop()
            it = QTreeWidgetItem([title])
            it.setData(0, Qt.UserRole, max(0, page - 1))
            stack[-1].addChild(it)
            stack.append(it)
        if not self.doc.get_toc():
            it = QTreeWidgetItem(["Sem marcadores"])
            it.setDisabled(True)
            self.toc.addTopLevelItem(it)
        self.toc.expandToDepth(0)

    def _page_changed(self, n):
        self.pageInfo.emit(n, self.doc.page_count)
        if n < self.thumbs.count():
            self.thumbs.blockSignals(True)
            self.thumbs.setCurrentRow(n)
            self.thumbs.blockSignals(False)

    # ------------------------------------------------------------------ anular / refazer
    def snapshot(self):
        self.undo_stack.append(self.doc.tobytes(garbage=0))
        if len(self.undo_stack) > UNDO_LIMIT:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def _restore(self, data: bytes):
        self.doc = pymupdf.open(stream=data, filetype="pdf")
        self.view.set_document(self.doc, keep_position=True)
        self.refresh_side()

    def undo(self):
        if not self.undo_stack:
            self.status.emit("Nada para anular")
            return
        self.redo_stack.append(self.doc.tobytes(garbage=0))
        self._restore(self.undo_stack.pop())
        self.dirty = True
        self.changed.emit()
        self.status.emit("Anulado")

    def redo(self):
        if not self.redo_stack:
            self.status.emit("Nada para refazer")
            return
        self.undo_stack.append(self.doc.tobytes(garbage=0))
        self._restore(self.redo_stack.pop())
        self.dirty = True
        self.changed.emit()

    def after_change(self, pages, msg=""):
        """pages=None quando muda a estrutura (nº de páginas, ordem, tamanhos)."""
        self.dirty = True
        if pages is None:
            self.view.invalidate(None)
            self.refresh_side(True)
        else:
            self.view.invalidate(pages)
            self.update_thumbs(pages)
            self._build_comments()
        self.changed.emit()
        if msg:
            self.status.emit(msg)

    # ------------------------------------------------------------------ guardar
    def save(self, path: str | None = None) -> bool:
        target = Path(path) if path else self.path
        if target is None:
            return False
        kw = dict(garbage=3, deflate=True)
        if self.password:
            kw["encryption"] = pymupdf.PDF_ENCRYPT_KEEP
        tmp = target.with_name(target.stem + ".vrpdf-tmp.pdf")
        try:
            self.doc.save(tmp, **kw)
            tmp.replace(target)
        except PermissionError:
            tmp.unlink(missing_ok=True)
            QMessageBox.warning(self, "Não foi possível guardar",
                                f"O ficheiro {target.name} está aberto noutro programa ou é só de leitura.\n"
                                "Fecha-o noutro programa ou usa Guardar como.")
            return False
        self.path = target
        self.dirty = False
        self.changed.emit()
        self.status.emit(f"Guardado: {target.name}")
        return True

    # ------------------------------------------------------------------ pesquisa
    def show_search(self):
        self.search_bar.show()
        self.search_edit.setFocus()
        self.search_edit.selectAll()
        if self.view.selected_text and "\n" not in self.view.selected_text:
            self.search_edit.setText(self.view.selected_text)

    def hide_search(self):
        self.search_bar.hide()
        self.view.show_search([])

    def _run_search(self):
        q = self.search_edit.text()
        self.hits = []
        if not q:
            self.view.show_search([])
            self.search_count.setText("")
            return
        for page in self.doc:
            for r in page.search_for(q):
                if self.search_case.isChecked():
                    txt = page.get_textbox(r + (-1, -1, 1, 1))
                    if q not in txt:
                        continue
                self.hits.append((page.number, r))
        self.hit_i = -1

    def search_next(self):
        if not self.hits:
            self._run_search()
        if not self.hits:
            self.search_count.setText("Sem resultados")
            return
        self.hit_i = (self.hit_i + 1) % len(self.hits)
        self.view.show_search(self.hits, self.hit_i)
        self.search_count.setText(f"{self.hit_i + 1} de {len(self.hits)}")

    def search_prev(self):
        if not self.hits:
            self._run_search()
        if not self.hits:
            return
        self.hit_i = (self.hit_i - 1) % len(self.hits)
        self.view.show_search(self.hits, self.hit_i)
        self.search_count.setText(f"{self.hit_i + 1} de {len(self.hits)}")

    # ------------------------------------------------------------------ ações das ferramentas
    def opts(self) -> dict:
        return self.view.tool_options

    def on_action(self, tool: str, n: int, data):
        page = self.doc[n]
        o = self.opts()
        try:
            if tool == "click":
                self._select_annot_at(n, data["point"])
                return
            if tool == "double_click":
                self._double_click(n, data["point"])
                return
            if tool == "delete_key":
                self.delete_selected_annot()
                return
            if tool == "edit_text_at":
                ln = edit.line_at(page, data)
                if ln is None:
                    self.status.emit("Clica sobre uma linha de texto para a editar. Em digitalizações, usa primeiro o OCR.")
                    return
                self.view.open_line_editor(n, ln)
                return
            if tool == "pick_image":
                img = edit.image_at(page, data["point"])
                if img:
                    self.pending_image = (n, img)
                    self.view.flash_rect(n, img["rect"])
                    self.status.emit("Imagem escolhida. Agora desenha o retângulo da nova posição e tamanho.")
                else:
                    self.status.emit("Não há nenhuma imagem nesse ponto.")
                return

            self.snapshot()
            msg = ""
            if tool == "replace_line":
                edit.replace_line(page, data["line"], data["text"])
                msg = "Texto alterado"
            elif tool == pv.ADD_TEXT:
                edit.add_textbox(page, data["rect"], data["text"], family=o.get("family", "Arial"),
                                 size=float(o.get("size", 11)), color=o.get("color", "#000000"),
                                 bold=o.get("bold", False), italic=o.get("italic", False), align=o.get("align", 0))
                msg = "Texto acrescentado"
            elif tool == pv.IMAGE:
                path = o.get("image_path")
                if not path:
                    path, _ = QFileDialog.getOpenFileName(self, "Escolher imagem", "", "Imagens (*.png *.jpg *.jpeg *.bmp *.gif *.tif *.tiff *.webp)")
                    if not path:
                        self.undo_stack.pop()
                        return
                edit.insert_image(page, data["rect"], path)
                msg = "Imagem inserida"
            elif tool == pv.MOVE_IMAGE:
                if not self.pending_image:
                    img = edit.image_at(page, data["rect"].tl) or edit.image_at(page, data["rect"].br)
                    if img:
                        self.undo_stack.pop()
                        self.pending_image = (n, img)
                        self.view.flash_rect(n, img["rect"])
                        self.status.emit("Imagem escolhida. Desenha agora a nova posição.")
                        return
                    self.undo_stack.pop()
                    self.status.emit("Clica primeiro numa imagem para a escolher.")
                    return
                pn, img = self.pending_image
                self.pending_image = None
                if pn == n:
                    edit.move_image(page, img, data["rect"])
                else:
                    src = self.doc[pn]
                    pix = pymupdf.Pixmap(self.doc, img["xref"])
                    edit.remove_image_area(src, img["rect"])
                    page.insert_image(data["rect"], stream=pix.tobytes("png"))
                    self.after_change([pn])
                msg = "Imagem movida"
            elif tool == pv.WHITEOUT:
                edit.whiteout(page, data["rect"], o.get("fill", "#FFFFFF"))
                msg = "Área tapada"
            elif tool == pv.REDACT:
                edit.redact_area(page, data["rect"])
                msg = "Rasurado definitivamente (o conteúdo por baixo foi removido)"
            elif tool in (pv.HIGHLIGHT, pv.UNDERLINE, pv.STRIKE):
                kind = {pv.HIGHLIGHT: "highlight", pv.UNDERLINE: "underline", pv.STRIKE: "strike"}[tool]
                a = annot.text_markup(page, data["rect"], kind, o.get("markup_color") if tool == pv.HIGHLIGHT else o.get("color"))
                if a is None:
                    self.undo_stack.pop()
                    self.status.emit("Não há texto nessa área. Em digitalizações, faz primeiro o OCR.")
                    return
                msg = "Anotação acrescentada"
            elif tool == pv.NOTE:
                text, ok = QInputDialog.getMultiLineText(self, "Nota", "Texto da nota:")
                if not ok or not text.strip():
                    self.undo_stack.pop()
                    return
                annot.note(page, data["point"], text)
                msg = "Nota acrescentada"
            elif tool == pv.DRAW:
                annot.ink(page, [data["points"]], o.get("color", "#C8302B"), float(o.get("width", 2)))
            elif tool == pv.RECT:
                annot.rectangle(page, data["rect"], o.get("color", "#C8302B"), float(o.get("width", 2)))
            elif tool == pv.ELLIPSE:
                annot.ellipse(page, data["rect"], o.get("color", "#C8302B"), float(o.get("width", 2)))
            elif tool == pv.ARROW:
                annot.arrow(page, data["p1"], data["p2"], o.get("color", "#C8302B"), float(o.get("width", 2)))
            elif tool == pv.LINE:
                annot.line(page, data["p1"], data["p2"], o.get("color", "#C8302B"), float(o.get("width", 2)))
            elif tool == pv.CLOUD:
                annot.cloud(page, data["rect"], o.get("color", "#C8302B"), float(o.get("width", 1.5)))
                msg = "Nuvem de revisão acrescentada"
            elif tool == pv.STAMP:
                annot.stamp(page, data["point"], o.get("stamp", "APROVADO"), o.get("stamp_color"),
                            o.get("stamp_sub"), float(o.get("stamp_width", 150)))
                msg = "Carimbo colocado"
            elif tool == pv.SIGNATURE:
                sig = o.get("signature")
                if not sig:
                    self.undo_stack.pop()
                    self.status.emit("Cria ou escolhe primeiro uma assinatura (Formulários e assinatura > Assinatura).")
                    return
                from ..core import sign
                sign.place_signature(page, data["rect"], sig)
                msg = "Assinatura colocada"
            elif tool == pv.FIELD:
                self.undo_stack.pop()
                self._create_field(n, data["rect"])
                return
            else:
                self.undo_stack.pop()
                return
            self.after_change([n], msg)
        except Exception as e:
            if self.undo_stack:
                self._restore(self.undo_stack.pop())
            QMessageBox.warning(self, "Não foi possível", f"Não foi possível aplicar esta alteração.\n\n{e}")

    def _create_field(self, n, rect):
        from .dialogs import FieldDialog
        dlg = FieldDialog(self, len(forms.list_fields(self.doc)) + 1)
        if not dlg.exec():
            return
        kind, name, options = dlg.values()
        self.snapshot()
        forms.add_field(self.doc[n], rect, kind, name, options)
        self.after_change([n], f"Campo '{name}' criado")
        self._build_fields()
        self.side.setCurrentIndex(2)

    def _annot_at(self, n, point):
        page = self.doc[n]
        best = None
        for a in page.annots() or []:
            if a.type[1] in ("Widget", "Link", "Popup"):
                continue
            if (a.rect + (-3, -3, 3, 3)).contains(point):
                if best is None or a.rect.get_area() < best.rect.get_area():
                    best = a
        return best

    def _select_annot_at(self, n, point):
        a = self._annot_at(n, point)
        if a:
            self.selected_annot = (n, a.xref)
            self.view.flash_rect(n, a.rect)
            self.status.emit("Anotação selecionada: Delete para apagar, duplo clique para editar o texto.")
        else:
            self.selected_annot = None

    def _double_click(self, n, point):
        a = self._annot_at(n, point)
        if a:
            text, ok = QInputDialog.getMultiLineText(self, "Comentário", "Texto da anotação:", a.info.get("content", ""))
            if ok:
                self.snapshot()
                a.set_info(content=text)
                a.update()
                self.after_change([n], "Comentário atualizado")
            return
        ln = edit.line_at(self.doc[n], point)
        if ln:
            self.view.open_line_editor(n, ln)

    def delete_selected_annot(self):
        if not self.selected_annot:
            return
        n, xref = self.selected_annot
        self.snapshot()
        if annot.delete_annotation(self.doc[n], xref):
            self.selected_annot = None
            self.after_change([n], "Anotação apagada")
        else:
            self.undo_stack.pop()

    def on_context(self, n, point, gpos):
        page = self.doc[n]
        m = QMenu(self)
        a = self._annot_at(n, point)
        img = edit.image_at(page, point)
        ln = edit.line_at(page, point)
        if a:
            self.selected_annot = (n, a.xref)
            m.addAction(theme.icon("pencil"), "Editar texto da anotação", lambda: self._double_click(n, point))
            m.addAction(theme.icon("delete"), "Apagar anotação", self.delete_selected_annot)
            m.addSeparator()
        if ln:
            m.addAction(theme.icon("format-text"), "Editar este texto", lambda: self.view.open_line_editor(n, ln))
        if img:
            m.addAction(theme.icon("image-move"), "Mover ou redimensionar imagem",
                        lambda: self._start_move_image(n, img))
            m.addAction(theme.icon("file-replace"), "Substituir imagem…", lambda: self._replace_image(n, img))
            m.addAction(theme.icon("delete"), "Apagar imagem", lambda: self._delete_image(n, img))
        if self.view.selected_text:
            m.addSeparator()
            m.addAction(theme.icon("content-copy"), "Copiar texto selecionado",
                        lambda: QGuiApplication.clipboard().setText(self.view.selected_text))
        m.addSeparator()
        m.addAction(theme.icon("note-text"), "Acrescentar nota aqui", lambda: self.on_action(pv.NOTE, n, {"point": point}))
        m.addAction(theme.icon("rotate-right"), "Rodar esta página", lambda: self.rotate([n], 90))
        m.addAction(theme.icon("delete"), "Apagar esta página", lambda: self.delete_pages([n]))
        m.exec(gpos)

    def _start_move_image(self, n, img):
        self.pending_image = (n, img)
        self.view.set_tool(pv.MOVE_IMAGE)
        self.status.emit("Desenha o retângulo com a nova posição e tamanho da imagem.")

    def _replace_image(self, n, img):
        path, _ = QFileDialog.getOpenFileName(self, "Nova imagem", "", "Imagens (*.png *.jpg *.jpeg *.bmp *.gif *.tif *.tiff *.webp)")
        if not path:
            return
        self.snapshot()
        edit.replace_image(self.doc[n], img, path)
        self.after_change([n], "Imagem substituída")

    def _delete_image(self, n, img):
        self.snapshot()
        edit.remove_image_area(self.doc[n], img["rect"])
        self.after_change([n], "Imagem apagada")

    # ------------------------------------------------------------------ páginas
    def selected_pages(self) -> list[int]:
        sel = sorted(it.data(Qt.UserRole) for it in self.thumbs.selectedItems())
        return sel or [self.view.current_page()]

    def _thumb_menu(self, pos):
        pages = self.selected_pages()
        m = QMenu(self)
        lab = f"{len(pages)} página(s)" if len(pages) > 1 else f"Página {pages[0] + 1}"
        t = m.addAction(lab)
        t.setEnabled(False)
        m.addAction(theme.icon("rotate-right"), "Rodar à direita", lambda: self.rotate(pages, 90))
        m.addAction(theme.icon("rotate-left"), "Rodar à esquerda", lambda: self.rotate(pages, -90))
        m.addAction(theme.icon("content-copy"), "Duplicar", lambda: self.duplicate(pages))
        m.addAction(theme.icon("file-export"), "Extrair para novo PDF…", lambda: self.extract(pages))
        m.addSeparator()
        m.addAction(theme.icon("file-plus"), "Inserir página em branco a seguir", lambda: self.insert_blank(pages[-1] + 1))
        m.addAction(theme.icon("file-import"), "Inserir páginas de outro PDF a seguir…", lambda: self.insert_file(pages[-1] + 1))
        m.addSeparator()
        m.addAction(theme.icon("delete"), "Apagar", lambda: self.delete_pages(pages))
        m.exec(self.thumbs.mapToGlobal(pos))

    def rotate(self, pages, angle):
        self.snapshot()
        organize.rotate_pages(self.doc, pages, angle)
        self.after_change(None, "Páginas rodadas")

    def delete_pages(self, pages):
        if len(pages) >= self.doc.page_count:
            QMessageBox.information(self, "Apagar páginas", "Não é possível apagar todas as páginas do documento.")
            return
        self.snapshot()
        organize.delete_pages(self.doc, pages)
        self.after_change(None, f"{len(pages)} página(s) apagada(s)")

    def duplicate(self, pages):
        self.snapshot()
        organize.duplicate_pages(self.doc, pages)
        self.after_change(None, "Páginas duplicadas")

    def insert_blank(self, at):
        self.snapshot()
        organize.insert_blank(self.doc, at)
        self.after_change(None, "Página em branco inserida")

    def insert_file(self, at):
        path, _ = QFileDialog.getOpenFileName(self, "Inserir páginas de", "", "PDF (*.pdf)")
        if not path:
            return
        self.snapshot()
        organize.insert_from_file(self.doc, path, at)
        self.after_change(None, "Páginas inseridas")

    def extract(self, pages):
        base = self.path.stem if self.path else "extraído"
        dst, _ = QFileDialog.getSaveFileName(self, "Guardar páginas extraídas",
                                             str((self.path.parent if self.path else Path.home()) / f"{base} (páginas).pdf"), "PDF (*.pdf)")
        if not dst:
            return
        out = pymupdf.open()
        for p in pages:
            out.insert_pdf(self.doc, from_page=p, to_page=p)
        out.save(dst, garbage=3, deflate=True)
        out.close()
        from .worker import result_box
        result_box(self, "Páginas extraídas", f"{len(pages)} página(s) guardadas.", [dst])

    def reorder_pages(self, order):
        self.snapshot()
        organize.reorder(self.doc, order)
        self.after_change(None, "Páginas reordenadas")

    # ------------------------------------------------------------------ operações do documento inteiro
    def apply_doc_op(self, fn, msg, structural=True):
        self.snapshot()
        try:
            res = fn(self.doc)
        except Exception as e:
            self._restore(self.undo_stack.pop())
            QMessageBox.warning(self, "Não foi possível", str(e))
            return None
        self.after_change(None if structural else list(range(self.doc.page_count)), msg)
        return res
