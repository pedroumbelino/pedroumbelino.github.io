"""Tarefas demoradas em segundo plano, com janela de progresso."""
from __future__ import annotations

import os
import subprocess
import sys
import traceback
from pathlib import Path

from PySide6.QtCore import QObject, QThread, Signal, Qt
from PySide6.QtWidgets import (QDialog, QLabel, QProgressBar, QVBoxLayout, QHBoxLayout, QPushButton,
                               QMessageBox, QWidget)


class _Worker(QObject):
    progress = Signal(int, int, str)
    done = Signal(object)
    failed = Signal(str, str)

    def __init__(self, fn, args, kwargs, wants_progress):
        super().__init__()
        self.fn, self.args, self.kwargs, self.wants_progress = fn, args, kwargs, wants_progress
        self.cancel = False

    def run(self):
        try:
            if self.wants_progress:
                self.kwargs["progress"] = lambda i, n, m="": self.progress.emit(i, n, m)
            res = self.fn(*self.args, **self.kwargs)
            self.done.emit(res)
        except Exception as e:
            self.failed.emit(str(e) or e.__class__.__name__, traceback.format_exc())


class ProgressDialog(QDialog):
    def __init__(self, parent, title: str):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumWidth(420)
        lay = QVBoxLayout(self)
        self.label = QLabel("A preparar…")
        self.bar = QProgressBar()
        self.bar.setRange(0, 0)
        lay.addWidget(QLabel(f"<b>{title}</b>"))
        lay.addWidget(self.label)
        lay.addWidget(self.bar)
        self.setWindowFlag(Qt.WindowContextHelpButtonHint, False)

    def update_progress(self, i, n, msg):
        if n:
            self.bar.setRange(0, n)
            self.bar.setValue(i)
        if msg:
            self.label.setText(msg)


_running = []


def run_task(parent: QWidget, title: str, fn, *args, on_done=None, progress=True, **kwargs):
    """Corre fn(*args, **kwargs) numa thread. on_done(result) é chamado na thread da interface."""
    dlg = ProgressDialog(parent, title)
    thread = QThread()
    worker = _Worker(fn, args, kwargs, progress)
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    worker.progress.connect(dlg.update_progress)

    def finish():
        thread.quit()
        thread.wait()
        dlg.accept()
        if (thread, worker) in _running:
            _running.remove((thread, worker))

    def ok(res):
        finish()
        if on_done:
            on_done(res)

    def bad(msg, tb):
        finish()
        box = QMessageBox(parent)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle("Não foi possível concluir")
        box.setText(f"{title}: não foi possível concluir.\n\n{msg}")
        box.setDetailedText(tb)
        box.exec()

    worker.done.connect(ok)
    worker.failed.connect(bad)
    _running.append((thread, worker))
    thread.start()
    dlg.exec()


def open_path(path: str | Path):
    p = str(path)
    if sys.platform == "win32":
        os.startfile(p)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", p])
    else:
        subprocess.Popen(["xdg-open", p])


def show_folder(path: str | Path):
    p = Path(path)
    if sys.platform == "win32":
        if p.is_file():
            subprocess.Popen(["explorer", "/select,", str(p)])
        else:
            os.startfile(str(p))  # type: ignore[attr-defined]
    else:
        open_path(p.parent if p.is_file() else p)


def result_box(parent, title: str, text: str, files: list | None = None):
    """Mensagem de conclusão com botões para abrir o ficheiro ou a pasta."""
    files = [Path(f) for f in (files or []) if f]
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Information)
    box.setWindowTitle(title)
    box.setText(text)
    b_open = b_folder = None
    if files:
        if len(files) == 1:
            b_open = box.addButton("Abrir ficheiro", QMessageBox.AcceptRole)
        b_folder = box.addButton("Mostrar na pasta", QMessageBox.ActionRole)
    box.addButton("Fechar", QMessageBox.RejectRole)
    box.exec()
    clicked = box.clickedButton()
    if b_open is not None and clicked is b_open:
        open_path(files[0])
    elif b_folder is not None and clicked is b_folder:
        show_folder(files[0])
