"""Vista contínua das páginas, com zoom, seleção de texto, pesquisa e ferramentas de edição/anotação."""
from __future__ import annotations

from collections import OrderedDict

import pymupdf
from PySide6.QtCore import Qt, QRectF, QPointF, Signal, QTimer, QEvent
from PySide6.QtGui import (QImage, QPixmap, QPen, QColor, QBrush, QPainterPath, QPainter, QKeySequence,
                           QGuiApplication, QCursor)
from PySide6.QtWidgets import (QGraphicsView, QGraphicsScene, QGraphicsRectItem, QGraphicsPixmapItem,
                               QGraphicsPathItem, QGraphicsDropShadowEffect, QLineEdit, QPlainTextEdit,
                               QGraphicsProxyWidget, QMenu, QApplication, QGraphicsLineItem)

from . import theme

GAP = 18          # espaço entre páginas (px)
PT2PX = 96 / 72   # 100% = tamanho real no ecrã

# ferramentas
SELECT, HAND, EDIT_TEXT, ADD_TEXT, IMAGE, MOVE_IMAGE, WHITEOUT, REDACT, HIGHLIGHT, UNDERLINE, STRIKE, NOTE, \
    DRAW, RECT, ELLIPSE, ARROW, LINE, CLOUD, STAMP, SIGNATURE, FIELD = (
        "select", "hand", "edit_text", "add_text", "image", "move_image", "whiteout", "redact", "highlight",
        "underline", "strike", "note", "draw", "rect", "ellipse", "arrow", "line", "cloud", "stamp", "signature",
        "field")

DRAG_RECT_TOOLS = {ADD_TEXT, IMAGE, WHITEOUT, REDACT, HIGHLIGHT, UNDERLINE, STRIKE, RECT, ELLIPSE, CLOUD,
                   FIELD, SIGNATURE, SELECT, MOVE_IMAGE}
CLICK_TOOLS = {NOTE, STAMP, EDIT_TEXT}

CURSORS = {SELECT: Qt.IBeamCursor, HAND: Qt.OpenHandCursor, EDIT_TEXT: Qt.IBeamCursor, ADD_TEXT: Qt.CrossCursor,
           IMAGE: Qt.CrossCursor, MOVE_IMAGE: Qt.SizeAllCursor, WHITEOUT: Qt.CrossCursor, REDACT: Qt.CrossCursor,
           HIGHLIGHT: Qt.IBeamCursor, UNDERLINE: Qt.IBeamCursor, STRIKE: Qt.IBeamCursor, NOTE: Qt.PointingHandCursor,
           DRAW: Qt.CrossCursor, RECT: Qt.CrossCursor, ELLIPSE: Qt.CrossCursor, ARROW: Qt.CrossCursor,
           LINE: Qt.CrossCursor, CLOUD: Qt.CrossCursor, STAMP: Qt.PointingHandCursor,
           SIGNATURE: Qt.CrossCursor, FIELD: Qt.CrossCursor}


class PageView(QGraphicsView):
    pageChanged = Signal(int)
    zoomChanged = Signal(float)
    selectionText = Signal(str)
    # (tool, page_no, payload) -> o DocWidget aplica a operação
    action = Signal(str, int, object)
    contextRequested = Signal(int, object, object)  # page_no, page_point, global_pos

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Canvas")
        self.scene_ = QGraphicsScene(self)
        self.setScene(self.scene_)
        self.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
        self.setDragMode(QGraphicsView.NoDrag)
        self.setViewportUpdateMode(QGraphicsView.SmartViewportUpdate)
        self.setTransformationAnchor(QGraphicsView.NoAnchor)
        self.doc: pymupdf.Document | None = None
        self.zoom = 1.0
        self.fit_mode = "width"  # width | page | None
        self.tool = SELECT
        self.page_items: list[QGraphicsRectItem] = []
        self.pix_items: dict[int, QGraphicsPixmapItem] = {}
        self.page_rects: list[QRectF] = []
        self.cache: OrderedDict[tuple, QPixmap] = OrderedDict()
        self.overlays: list = []
        self.search_items: list = []
        self.sel_items: list = []
        self.selected_text = ""
        self._drag_start = None
        self._drag_page = None
        self._rubber = None
        self._ink_path = None
        self._ink_points: list = []
        self._editor_proxy = None
        self._pan_last = None
        self._current_page = 0
        self.tool_options: dict = {}
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.timeout.connect(self.render_visible)
        self.verticalScrollBar().valueChanged.connect(self._scrolled)
        self.horizontalScrollBar().valueChanged.connect(lambda *_: self._render_timer.start(30))
        self.setMouseTracking(True)

    # ------------------------------------------------------------------ documento e layout
    def set_document(self, doc: pymupdf.Document, keep_position=False):
        pos = self.verticalScrollBar().value() if keep_position else 0
        self.doc = doc
        self.cache.clear()
        self.relayout()
        if keep_position:
            self.verticalScrollBar().setValue(pos)
        self._render_timer.start(0)

    def s(self) -> float:
        return self.zoom * PT2PX

    def relayout(self):
        self._close_editor()
        self.scene_.clear()
        self.page_items.clear()
        self.pix_items.clear()
        self.page_rects.clear()
        self.overlays.clear()
        self.search_items.clear()
        self.sel_items.clear()
        if not self.doc:
            return
        s = self.s()
        maxw = max((p.rect.width for p in self.doc), default=600) * s
        y = GAP
        c = theme.colors()
        for i, page in enumerate(self.doc):
            w, h = page.rect.width * s, page.rect.height * s
            x = GAP + (maxw - w) / 2
            r = QRectF(x, y, w, h)
            item = QGraphicsRectItem(r)
            item.setBrush(QBrush(QColor("#FFFFFF")))
            item.setPen(QPen(QColor(0, 0, 0, 40), 1))
            item.setZValue(0)
            self.scene_.addItem(item)
            self.page_items.append(item)
            self.page_rects.append(r)
            y += h + GAP
        self.scene_.setSceneRect(QRectF(0, 0, maxw + 2 * GAP, y))
        self._render_timer.start(0)

    def apply_fit(self):
        if not self.doc or not self.doc.page_count or not self.fit_mode:
            return
        page = self.doc[self.current_page()]
        vw = self.viewport().width() - 2 * GAP - 4
        vh = self.viewport().height() - 2 * GAP
        if self.fit_mode == "width":
            z = vw / (max(p.rect.width for p in self.doc) * PT2PX)
        else:
            z = min(vw / (page.rect.width * PT2PX), vh / (page.rect.height * PT2PX))
        self.set_zoom(max(0.1, min(z, 8.0)), keep_fit=True)

    def set_zoom(self, z: float, keep_fit=False, anchor_scene: QPointF | None = None):
        z = max(0.1, min(8.0, z))
        if not keep_fit:
            self.fit_mode = None
        if abs(z - self.zoom) < 1e-4 and self.page_items:
            return
        cur = self.current_page()
        # posição relativa dentro da página atual, para manter o sítio ao fazer zoom
        rel = 0.0
        if self.page_rects and cur < len(self.page_rects):
            r = self.page_rects[cur]
            top = self.mapToScene(0, 0).y()
            rel = (top - r.top()) / max(1.0, r.height())
        self.zoom = z
        self.cache.clear()
        self.relayout()
        if self.page_rects and cur < len(self.page_rects):
            r = self.page_rects[cur]
            self.verticalScrollBar().setValue(int(r.top() + rel * r.height()))
        self.render_visible()
        self.zoomChanged.emit(self.zoom)

    def zoom_in(self):
        self.set_zoom(self.zoom * 1.2)

    def zoom_out(self):
        self.set_zoom(self.zoom / 1.2)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self.fit_mode:
            QTimer.singleShot(0, self.apply_fit)
        self._render_timer.start(40)

    def _scrolled(self, *_):
        self._render_timer.start(25)
        p = self.current_page()
        if p != self._current_page:
            self._current_page = p
            self.pageChanged.emit(p)

    def current_page(self) -> int:
        if not self.page_rects:
            return 0
        center = self.mapToScene(self.viewport().rect().center()).y()
        top = self.mapToScene(0, 0).y()
        probe = top + min(self.viewport().height() * 0.35, 200)
        for i, r in enumerate(self.page_rects):
            if r.bottom() + GAP / 2 >= probe:
                return i
        return len(self.page_rects) - 1

    def go_to_page(self, n: int, rect_pt: pymupdf.Rect | None = None):
        if not self.page_rects:
            return
        n = max(0, min(n, len(self.page_rects) - 1))
        r = self.page_rects[n]
        if rect_pt is not None:
            sr = self.page_to_scene(n, rect_pt)
            self.centerOn(sr.center())
        else:
            self.verticalScrollBar().setValue(int(r.top() - GAP / 2))
        self._render_timer.start(0)

    # ------------------------------------------------------------------ renderização
    def render_visible(self):
        if not self.doc:
            return
        vis = self.mapToScene(self.viewport().rect()).boundingRect()
        vis.adjust(0, -vis.height() * 0.5, 0, vis.height() * 0.5)
        dpr = self.devicePixelRatioF()
        s = self.s()
        for i, r in enumerate(self.page_rects):
            if not r.intersects(vis):
                continue
            key = (i, round(s * dpr, 4))
            pm = self.cache.get(key)
            if pm is None:
                try:
                    page = self.doc[i]
                    pix = page.get_pixmap(matrix=pymupdf.Matrix(s * dpr, s * dpr), alpha=False, annots=True)
                    img = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888).copy()
                    pm = QPixmap.fromImage(img)
                    pm.setDevicePixelRatio(dpr)
                except Exception:
                    continue
                self.cache[key] = pm
                while len(self.cache) > 14:
                    self.cache.popitem(last=False)
            else:
                self.cache.move_to_end(key)
            it = self.pix_items.get(i)
            if it is None:
                it = QGraphicsPixmapItem()
                it.setZValue(1)
                it.setTransformationMode(Qt.SmoothTransformation)
                self.scene_.addItem(it)
                self.pix_items[i] = it
            if it.pixmap().cacheKey() != pm.cacheKey():
                it.setPixmap(pm)
            it.setPos(r.topLeft())

    def invalidate(self, pages: list[int] | None = None):
        """Volta a desenhar páginas alteradas (todas se pages=None). Mantém a posição."""
        if not self.doc:
            return
        if pages is None or len(self.page_rects) != self.doc.page_count or any(
                abs(self.page_rects[p].width() - self.doc[p].rect.width * self.s()) > 0.5 for p in pages
                if p < len(self.page_rects)):
            pos = self.verticalScrollBar().value()
            self.cache.clear()
            self.relayout()
            self.verticalScrollBar().setValue(pos)
        else:
            for k in [k for k in self.cache if k[0] in pages]:
                del self.cache[k]
            self.clear_selection()
        self.render_visible()

    # ------------------------------------------------------------------ coordenadas
    def scene_to_page(self, pt: QPointF) -> tuple[int | None, pymupdf.Point | None]:
        for i, r in enumerate(self.page_rects):
            if r.adjusted(-GAP / 2, -GAP / 2, GAP / 2, GAP / 2).contains(pt):
                s = self.s()
                x = (pt.x() - r.left()) / s
                y = (pt.y() - r.top()) / s
                page = self.doc[i]
                p = pymupdf.Point(x, y) * page.derotation_matrix
                return i, p
        return None, None

    def page_to_scene(self, n: int, rect: pymupdf.Rect) -> QRectF:
        page = self.doc[n]
        rr = pymupdf.Rect(rect) * page.rotation_matrix
        s = self.s()
        r = self.page_rects[n]
        return QRectF(r.left() + rr.x0 * s, r.top() + rr.y0 * s, rr.width * s, rr.height * s)

    def _clamp_to_page(self, n: int, pt: QPointF) -> QPointF:
        r = self.page_rects[n]
        return QPointF(min(max(pt.x(), r.left()), r.right()), min(max(pt.y(), r.top()), r.bottom()))

    def _scene_rect_to_page(self, n: int, a: QPointF, b: QPointF) -> pymupdf.Rect:
        r = self.page_rects[n]
        s = self.s()
        page = self.doc[n]
        p1 = pymupdf.Point((a.x() - r.left()) / s, (a.y() - r.top()) / s) * page.derotation_matrix
        p2 = pymupdf.Point((b.x() - r.left()) / s, (b.y() - r.top()) / s) * page.derotation_matrix
        return pymupdf.Rect(p1, p2).normalize()

    # ------------------------------------------------------------------ ferramentas
    def set_tool(self, tool: str, **options):
        self._close_editor()
        self.tool = tool
        self.tool_options.update(options)
        self.viewport().setCursor(CURSORS.get(tool, Qt.ArrowCursor))
        if tool != SELECT:
            self.clear_selection()

    def wheelEvent(self, e):
        if e.modifiers() & Qt.ControlModifier:
            f = 1.15 if e.angleDelta().y() > 0 else 1 / 1.15
            self.set_zoom(self.zoom * f)
            e.accept()
            return
        super().wheelEvent(e)

    def mousePressEvent(self, e):
        sp = self.mapToScene(e.position().toPoint())
        if e.button() == Qt.MiddleButton or (e.button() == Qt.LeftButton and self.tool == HAND):
            self._pan_last = e.position()
            self.viewport().setCursor(Qt.ClosedHandCursor)
            return
        if e.button() == Qt.RightButton:
            n, p = self.scene_to_page(sp)
            if n is not None:
                self.contextRequested.emit(n, p, e.globalPosition().toPoint())
            return
        if e.button() != Qt.LeftButton:
            return super().mousePressEvent(e)
        if self._editor_proxy is not None:
            # clique fora do editor confirma
            if not self._editor_proxy.sceneBoundingRect().contains(sp):
                self._commit_editor()
            return super().mousePressEvent(e)
        n, p = self.scene_to_page(sp)
        if n is None:
            self.clear_selection()
            return
        if self.tool in CLICK_TOOLS:
            if self.tool == EDIT_TEXT:
                self.action.emit("edit_text_at", n, p)
            else:
                self.action.emit(self.tool, n, {"point": p})
            return
        self._drag_page = n
        self._drag_start = self._clamp_to_page(n, sp)
        c = QColor(theme.colors()["accent"])
        if self.tool in (DRAW,):
            self._ink_points = [p]
            path = QPainterPath(self._drag_start)
            self._ink_path = QGraphicsPathItem(path)
            col = QColor(self.tool_options.get("color", "#C8302B"))
            self._ink_path.setPen(QPen(col, max(1.0, self.tool_options.get("width", 2) * self.s()), Qt.SolidLine,
                                       Qt.RoundCap, Qt.RoundJoin))
            self._ink_path.setZValue(10)
            self.scene_.addItem(self._ink_path)
        elif self.tool in (ARROW, LINE):
            self._rubber = QGraphicsLineItem(self._drag_start.x(), self._drag_start.y(), self._drag_start.x(),
                                             self._drag_start.y())
            self._rubber.setPen(QPen(QColor(self.tool_options.get("color", "#C8302B")), 2))
            self._rubber.setZValue(10)
            self.scene_.addItem(self._rubber)
        else:
            self._rubber = QGraphicsRectItem(QRectF(self._drag_start, self._drag_start))
            pen = QPen(c, 1.5, Qt.DashLine)
            self._rubber.setPen(pen)
            fill = QColor(c)
            fill.setAlpha(35 if self.tool != WHITEOUT else 0)
            if self.tool == WHITEOUT:
                self._rubber.setBrush(QBrush(QColor(self.tool_options.get("fill", "#FFFFFF"))))
            elif self.tool == REDACT:
                self._rubber.setBrush(QBrush(QColor(0, 0, 0, 160)))
            else:
                self._rubber.setBrush(QBrush(fill))
            self._rubber.setZValue(10)
            self.scene_.addItem(self._rubber)
            if self.tool == SELECT:
                self.clear_selection()

    def mouseMoveEvent(self, e):
        if self._pan_last is not None:
            d = e.position() - self._pan_last
            self._pan_last = e.position()
            self.horizontalScrollBar().setValue(int(self.horizontalScrollBar().value() - d.x()))
            self.verticalScrollBar().setValue(int(self.verticalScrollBar().value() - d.y()))
            return
        if self._drag_start is None:
            return super().mouseMoveEvent(e)
        sp = self._clamp_to_page(self._drag_page, self.mapToScene(e.position().toPoint()))
        if self._ink_path is not None:
            path = self._ink_path.path()
            path.lineTo(sp)
            self._ink_path.setPath(path)
            _, p = self.scene_to_page(sp)
            if p is not None:
                self._ink_points.append(p)
        elif isinstance(self._rubber, QGraphicsLineItem):
            self._rubber.setLine(self._drag_start.x(), self._drag_start.y(), sp.x(), sp.y())
        elif self._rubber is not None:
            self._rubber.setRect(QRectF(self._drag_start, sp).normalized())
            if self.tool == SELECT:
                self._live_select(self._drag_page, self._drag_start, sp)

    def mouseReleaseEvent(self, e):
        if self._pan_last is not None:
            self._pan_last = None
            self.viewport().setCursor(CURSORS.get(self.tool, Qt.ArrowCursor))
            return
        if self._drag_start is None:
            return super().mouseReleaseEvent(e)
        n = self._drag_page
        a = self._drag_start
        b = self._clamp_to_page(n, self.mapToScene(e.position().toPoint()))
        self._drag_start = None
        tool = self.tool
        small = abs(a.x() - b.x()) < 4 and abs(a.y() - b.y()) < 4
        if self._ink_path is not None:
            self.scene_.removeItem(self._ink_path)
            self._ink_path = None
            if len(self._ink_points) > 1:
                self.action.emit(DRAW, n, {"points": [(p.x, p.y) for p in self._ink_points]})
            self._ink_points = []
            return
        if self._rubber is not None:
            self.scene_.removeItem(self._rubber)
            self._rubber = None
        if tool in (ARROW, LINE):
            if not small:
                _, p1 = self.scene_to_page(a)
                _, p2 = self.scene_to_page(b)
                self.action.emit(tool, n, {"p1": p1, "p2": p2})
            return
        rect = self._scene_rect_to_page(n, a, b)
        if tool == SELECT:
            if small:
                self.clear_selection()
                _, p = self.scene_to_page(a)
                self.action.emit("click", n, {"point": p})
            return
        if small:
            if tool in (ADD_TEXT, FIELD, IMAGE, SIGNATURE):
                # clique simples: caixa com tamanho padrão
                _, p = self.scene_to_page(a)
                w, h = {ADD_TEXT: (220, 40), FIELD: (160, 22), IMAGE: (160, 120), SIGNATURE: (160, 60)}[tool]
                rect = pymupdf.Rect(p.x, p.y, p.x + w, p.y + h)
            elif tool == MOVE_IMAGE:
                _, p = self.scene_to_page(a)
                self.action.emit("pick_image", n, {"point": p})
                return
            else:
                return
        if tool == ADD_TEXT:
            self.open_text_editor(n, rect)
            return
        self.action.emit(tool, n, {"rect": rect})

    def mouseDoubleClickEvent(self, e):
        sp = self.mapToScene(e.position().toPoint())
        n, p = self.scene_to_page(sp)
        if n is not None and self.tool in (SELECT, HAND):
            self.action.emit("double_click", n, {"point": p})
            return
        super().mouseDoubleClickEvent(e)

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Copy) and self.selected_text:
            QGuiApplication.clipboard().setText(self.selected_text)
            return
        if e.key() == Qt.Key_Escape:
            self._close_editor()
            self.clear_selection()
            return
        if e.key() in (Qt.Key_Delete,):
            self.action.emit("delete_key", self.current_page(), None)
            return
        if e.key() in (Qt.Key_PageDown,) and not (e.modifiers() & Qt.ControlModifier):
            pass
        super().keyPressEvent(e)

    # ------------------------------------------------------------------ seleção de texto
    def _live_select(self, n, a, b):
        rect = self._scene_rect_to_page(n, a, b)
        page = self.doc[n]
        words = [w for w in page.get_text("words", sort=True) if pymupdf.Rect(w[:4]).intersects(rect)]
        for it in self.sel_items:
            self.scene_.removeItem(it)
        self.sel_items.clear()
        c = QColor(theme.ACCENT)
        c.setAlpha(70)
        for w in words:
            it = QGraphicsRectItem(self.page_to_scene(n, pymupdf.Rect(w[:4])))
            it.setBrush(QBrush(c))
            it.setPen(QPen(Qt.NoPen))
            it.setZValue(5)
            self.scene_.addItem(it)
            self.sel_items.append(it)
        # junta por linhas
        lines, last = [], None
        for w in words:
            key = (w[5], w[6])
            if key != last:
                lines.append([])
                last = key
            lines[-1].append(w[4])
        self.selected_text = "\n".join(" ".join(l) for l in lines)
        self.selectionText.emit(self.selected_text)

    def clear_selection(self):
        for it in self.sel_items:
            if it.scene() is self.scene_:
                self.scene_.removeItem(it)
        self.sel_items.clear()
        self.selected_text = ""

    # ------------------------------------------------------------------ pesquisa
    def show_search(self, hits: list[tuple[int, pymupdf.Rect]], current: int = -1):
        for it in self.search_items:
            if it.scene() is self.scene_:
                self.scene_.removeItem(it)
        self.search_items.clear()
        for k, (n, r) in enumerate(hits):
            it = QGraphicsRectItem(self.page_to_scene(n, r))
            col = QColor(255, 140, 0, 150) if k == current else QColor(255, 220, 0, 110)
            it.setBrush(QBrush(col))
            it.setPen(QPen(QColor(200, 90, 0), 1) if k == current else QPen(Qt.NoPen))
            it.setZValue(6)
            self.scene_.addItem(it)
            self.search_items.append(it)
        if 0 <= current < len(hits):
            n, r = hits[current]
            self.go_to_page(n, r)

    def flash_rect(self, n: int, rect: pymupdf.Rect):
        it = QGraphicsRectItem(self.page_to_scene(n, rect))
        it.setPen(QPen(QColor(theme.ACCENT), 2))
        it.setZValue(7)
        self.scene_.addItem(it)
        QTimer.singleShot(1200, lambda: it.scene() and self.scene_.removeItem(it))

    # ------------------------------------------------------------------ editores no próprio documento
    def open_line_editor(self, n: int, line):
        """Editor de uma linha de texto existente (ferramenta Editar texto)."""
        self._close_editor()
        sr = self.page_to_scene(n, line.rect)
        ed = QLineEdit(line.text.rstrip())
        f = ed.font()
        f.setPixelSize(max(9, int(line.size * self.s() * 0.95)))
        ed.setFont(f)
        ed.setFixedSize(int(max(sr.width() + 60, 140)), int(sr.height() + 10))
        ed.setStyleSheet(f"QLineEdit {{ background: #FFFFFF; color: #111; border: 2px solid {theme.ACCENT}; "
                         f"border-radius: 3px; padding: 0 3px; }}")
        proxy = self.scene_.addWidget(ed)
        proxy.setPos(sr.left() - 4, sr.top() - 5)
        proxy.setZValue(20)
        self._editor_proxy = proxy
        self._editor_ctx = ("line", n, line)
        ed.returnPressed.connect(self._commit_editor)
        ed.setFocus()
        ed.selectAll()

    def open_text_editor(self, n: int, rect: pymupdf.Rect, text: str = ""):
        self._close_editor()
        sr = self.page_to_scene(n, rect)
        ed = QPlainTextEdit(text)
        size = float(self.tool_options.get("size", 11))
        f = ed.font()
        f.setFamily(self.tool_options.get("family", "Arial"))
        f.setPixelSize(max(9, int(size * self.s())))
        f.setBold(bool(self.tool_options.get("bold")))
        f.setItalic(bool(self.tool_options.get("italic")))
        ed.setFont(f)
        ed.setPlaceholderText("Escreve aqui. Clica fora da caixa para aplicar, Esc para cancelar.")
        ed.setFixedSize(int(max(sr.width(), 160)), int(max(sr.height(), 40)))
        ed.setStyleSheet(f"QPlainTextEdit {{ background: rgba(255,255,255,235); color: "
                         f"{self.tool_options.get('color', '#000000')}; border: 2px dashed {theme.ACCENT}; }}")
        proxy = self.scene_.addWidget(ed)
        proxy.setPos(sr.topLeft())
        proxy.setZValue(20)
        self._editor_proxy = proxy
        self._editor_ctx = ("box", n, rect)
        ed.setFocus()

    def _commit_editor(self):
        if self._editor_proxy is None:
            return
        w = self._editor_proxy.widget()
        kind, n, obj = self._editor_ctx
        if kind == "line":
            text = w.text()
            self._close_editor()
            if text != obj.text.rstrip():
                self.action.emit("replace_line", n, {"line": obj, "text": text})
        else:
            text = w.toPlainText()
            # caixa com a altura real do editor
            sr = self._editor_proxy.sceneBoundingRect()
            rect = obj
            self._close_editor()
            if text.strip():
                self.action.emit(ADD_TEXT, n, {"rect": rect, "text": text})

    def _close_editor(self):
        if self._editor_proxy is not None:
            p = self._editor_proxy
            self._editor_proxy = None
            if p.scene() is self.scene_:
                self.scene_.removeItem(p)
            p.deleteLater()
            self.setFocus()
