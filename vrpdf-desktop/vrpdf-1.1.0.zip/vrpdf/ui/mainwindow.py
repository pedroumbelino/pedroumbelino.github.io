"""Janela principal: friso de ferramentas, separadores de documentos, página inicial."""
from __future__ import annotations

import os
from pathlib import Path

import pymupdf
from PySide6.QtCore import Qt, QSize, QTimer, Signal
from PySide6.QtGui import QAction, QKeySequence, QShortcut, QIcon
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget, QToolButton, QLabel,
                               QFrame, QFileDialog, QMessageBox, QInputDialog, QPushButton, QListWidget,
                               QListWidgetItem, QComboBox, QSpinBox, QDoubleSpinBox, QCheckBox, QGridLayout,
                               QSizePolicy, QApplication, QStatusBar, QLineEdit, QButtonGroup, QMenu)

from ..core import convert, organize, edit, annot, compare, security, sign, batch, rename, proposta_vr, scan
from ..core.util import parse_page_ranges, out_path, APP_NAME, APP_VERSION
from . import theme, dialogs
from . import pageview as pv
from .docwidget import DocWidget
from .worker import run_task, result_box, open_path, show_folder

OPENABLE = {".pdf"}
IMAGES = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp", ".gif"}


class Ribbon(QFrame):
    """Separadores com grupos de botões grandes (ícone por cima do texto)."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setObjectName("Ribbon")
        self.setFixedHeight(116)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        self.tabs = QTabWidget()
        self.tabs.setObjectName("RibbonTabs")
        self.tabs.setDocumentMode(True)
        lay.addWidget(self.tabs)
        self.buttons: dict[str, QToolButton] = {}

    def page(self, title: str):
        w = QWidget()
        w.setObjectName("RibbonPage")
        l = QHBoxLayout(w)
        l.setContentsMargins(8, 4, 8, 2)
        l.setSpacing(2)
        l.addStretch()
        self.tabs.addTab(w, title)
        return w

    def group(self, page: QWidget, label: str, items: list[tuple]):
        """items: (chave, texto, ícone, função, dica, checkable)"""
        lay = page.layout()
        box = QWidget()
        bl = QVBoxLayout(box)
        bl.setContentsMargins(2, 0, 2, 0)
        bl.setSpacing(0)
        row = QHBoxLayout()
        row.setSpacing(1)
        for it in items:
            key, text, ic, fn, tip = it[:5]
            checkable = it[5] if len(it) > 5 else False
            b = QToolButton()
            b.setObjectName("Big")
            b.setText(text)
            b.setIcon(theme.icon(ic))
            b.setIconSize(QSize(24, 24))
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setToolTip(tip)
            b.setCheckable(checkable)
            b.setAutoRaise(True)
            b.clicked.connect(fn)
            b.setProperty("icon_name", ic)
            row.addWidget(b)
            self.buttons[key] = b
        bl.addLayout(row)
        lab = QLabel(label)
        lab.setObjectName("GroupLabel")
        lab.setAlignment(Qt.AlignCenter)
        bl.addWidget(lab)
        lay.insertWidget(lay.count() - 1, box)
        sep = QFrame()
        sep.setObjectName("GroupSep")
        sep.setFixedWidth(1)
        lay.insertWidget(lay.count() - 1, sep)

    def recolor(self):
        for b in self.buttons.values():
            b.setIcon(theme.icon(b.property("icon_name")))


class ToolProps(QFrame):
    """Barra de opções da ferramenta ativa (cor, espessura, tipo de letra…)."""

    def __init__(self, on_change):
        super().__init__()
        self.setObjectName("ToolProps")
        self.on_change = on_change
        l = QHBoxLayout(self)
        l.setContentsMargins(10, 4, 10, 4)
        self.title = QLabel()
        self.title.setStyleSheet("font-weight: 600;")
        l.addWidget(self.title)
        l.addSpacing(10)
        self.w = {}

        def add(key, label, widget):
            lab = QLabel(label)
            l.addWidget(lab)
            l.addWidget(widget)
            self.w[key] = (lab, widget)

        self.color = dialogs.ColorButton("#C8302B")
        self.color.clicked.connect(lambda: QTimer.singleShot(0, self.emit))
        add("color", "Cor", self.color)
        self.hcolor = QComboBox()
        for name, c in (("Amarelo", "#FFE14D"), ("Verde", "#7CE38B"), ("Azul", "#7CC4FF"), ("Rosa", "#FF9AD5"), ("Laranja", "#FFB347")):
            self.hcolor.addItem(name, c)
        self.hcolor.currentIndexChanged.connect(self.emit)
        add("hcolor", "Cor do realce", self.hcolor)
        self.width = QDoubleSpinBox()
        self.width.setRange(0.5, 12)
        self.width.setValue(2)
        self.width.valueChanged.connect(self.emit)
        add("width", "Espessura", self.width)
        self.family = QComboBox()
        self.family.addItems(edit.font_names())
        self.family.currentTextChanged.connect(self.emit)
        add("family", "Letra", self.family)
        self.size = QDoubleSpinBox()
        self.size.setRange(4, 120)
        self.size.setValue(11)
        self.size.valueChanged.connect(self.emit)
        add("size", "Tamanho", self.size)
        self.bold = QCheckBox("Negrito")
        self.bold.toggled.connect(self.emit)
        l.addWidget(self.bold)
        self.w["bold"] = (None, self.bold)
        self.italic = QCheckBox("Itálico")
        self.italic.toggled.connect(self.emit)
        l.addWidget(self.italic)
        self.w["italic"] = (None, self.italic)
        self.fill = dialogs.ColorButton("#FFFFFF")
        self.fill.clicked.connect(lambda: QTimer.singleShot(0, self.emit))
        add("fill", "Cor de fundo", self.fill)
        self.hint = QLabel()
        self.hint.setObjectName("Muted")
        l.addSpacing(12)
        l.addWidget(self.hint, 1)
        self.done = QPushButton("Terminar")
        self.done.clicked.connect(lambda: self.on_change(None))
        l.addWidget(self.done)

    def show_for(self, tool: str, title: str, hint: str):
        visible = {
            pv.ADD_TEXT: {"color", "family", "size", "bold", "italic"},
            pv.DRAW: {"color", "width"}, pv.RECT: {"color", "width"}, pv.ELLIPSE: {"color", "width"},
            pv.ARROW: {"color", "width"}, pv.LINE: {"color", "width"}, pv.CLOUD: {"color", "width"},
            pv.HIGHLIGHT: {"hcolor"}, pv.UNDERLINE: {"color"}, pv.STRIKE: {"color"},
            pv.WHITEOUT: {"fill"},
        }.get(tool, set())
        for k, (lab, w) in self.w.items():
            v = k in visible
            w.setVisible(v)
            if lab:
                lab.setVisible(v)
        self.title.setText(title)
        self.hint.setText(hint)
        self.setVisible(tool not in (pv.SELECT, pv.HAND))

    def values(self) -> dict:
        return dict(color=self.color.color, markup_color=self.hcolor.currentData(), width=self.width.value(),
                    family=self.family.currentText(), size=self.size.value(), bold=self.bold.isChecked(),
                    italic=self.italic.isChecked(), fill=self.fill.color)

    def emit(self, *_):
        self.on_change("props")


TOOL_INFO = {
    pv.SELECT: ("Selecionar", "Arrasta para selecionar texto (Ctrl+C copia). Clica numa anotação para a selecionar."),
    pv.HAND: ("Mão", "Arrasta para mover a página."),
    pv.EDIT_TEXT: ("Editar texto", "Clica numa linha de texto, altera-a e carrega em Enter."),
    pv.ADD_TEXT: ("Adicionar texto", "Clica ou desenha uma caixa e escreve. Clica fora para aplicar."),
    pv.IMAGE: ("Inserir imagem", "Desenha o retângulo onde a imagem deve ficar."),
    pv.MOVE_IMAGE: ("Mover imagem", "Clica na imagem e depois desenha a nova posição e tamanho."),
    pv.WHITEOUT: ("Tapar", "Desenha um retângulo para cobrir o conteúdo com uma cor."),
    pv.REDACT: ("Rasurar", "Desenha sobre o que queres apagar definitivamente."),
    pv.HIGHLIGHT: ("Realçar", "Arrasta sobre o texto a realçar."),
    pv.UNDERLINE: ("Sublinhar", "Arrasta sobre o texto a sublinhar."),
    pv.STRIKE: ("Riscar", "Arrasta sobre o texto a riscar."),
    pv.NOTE: ("Nota", "Clica onde queres a nota."),
    pv.DRAW: ("Desenho livre", "Desenha com o rato."),
    pv.RECT: ("Retângulo", "Arrasta para desenhar."),
    pv.ELLIPSE: ("Elipse", "Arrasta para desenhar."),
    pv.ARROW: ("Seta", "Arrasta do início para a ponta da seta."),
    pv.LINE: ("Linha", "Arrasta para desenhar."),
    pv.CLOUD: ("Nuvem de revisão", "Desenha a área a assinalar."),
    pv.STAMP: ("Carimbo", "Clica onde queres o carimbo."),
    pv.SIGNATURE: ("Assinatura", "Desenha o retângulo onde a assinatura deve ficar."),
    pv.FIELD: ("Criar campo", "Desenha o retângulo do campo."),
}


class StartPage(QWidget):
    def __init__(self, win: "MainWindow"):
        super().__init__()
        self.setObjectName("Start")
        self.win = win
        outer = QVBoxLayout(self)
        outer.setContentsMargins(40, 30, 40, 30)
        title = QLabel(f"{APP_NAME}")
        title.setObjectName("StartTitle")
        sub = QLabel("Abre um PDF ou arrasta ficheiros para esta janela. Tudo funciona sem internet.")
        sub.setObjectName("StartSub")
        outer.addWidget(title)
        outer.addWidget(sub)
        outer.addSpacing(16)
        row = QHBoxLayout()
        drop = QFrame()
        drop.setObjectName("Drop")
        dl = QVBoxLayout(drop)
        dl.setAlignment(Qt.AlignCenter)
        ic = QLabel()
        ic.setPixmap(theme.icon("file-pdf-box", theme.colors()["accent"]).pixmap(64, 64))
        ic.setAlignment(Qt.AlignCenter)
        dl.addWidget(ic)
        t = QLabel("Larga aqui PDFs, Word, Excel ou fotos")
        t.setAlignment(Qt.AlignCenter)
        t.setStyleSheet("font-size: 12pt; font-weight: 600;")
        dl.addWidget(t)
        b = QPushButton(theme.icon("folder-open", "#FFFFFF"), "  Abrir PDF…")
        b.setObjectName("Primary")
        b.clicked.connect(win.open_dialog)
        b.setFixedWidth(200)
        dl.addWidget(b, 0, Qt.AlignCenter)
        drop.setMinimumHeight(220)
        row.addWidget(drop, 3)
        rec = QVBoxLayout()
        rl = QLabel("Recentes")
        rl.setStyleSheet("font-weight: 600;")
        rec.addWidget(rl)
        self.recent = QListWidget()
        self.recent.itemActivated.connect(lambda it: win.open_files([it.data(Qt.UserRole)]))
        self.recent.itemClicked.connect(lambda it: win.open_files([it.data(Qt.UserRole)]))
        rec.addWidget(self.recent)
        row.addLayout(rec, 2)
        outer.addLayout(row)
        outer.addSpacing(18)
        tl = QLabel("Tarefas rápidas")
        tl.setStyleSheet("font-weight: 600;")
        outer.addWidget(tl)
        grid = QGridLayout()
        grid.setSpacing(10)
        tiles = [
            ("file-word", "PDF para Word", "Converter mantendo o layout", win.quick_word),
            ("file-excel", "PDF para Excel", "Tabelas para folhas de cálculo", win.quick_excel),
            ("file-document-multiple", "Juntar PDFs", "Vários ficheiros num só", win.merge),
            ("zip-box", "Comprimir", "Reduzir para enviar por email", win.quick_compress),
            ("camera-document", "Fotos para PDF", "Digitalizar com o telemóvel", win.photos_to_pdf),
            ("file-sign", "Proposta VR", "Fornecedor para layout VR em Word", win.proposta_vr),
            ("layers-triple", "Processamento em lote", "Muitos ficheiros de uma vez", win.batch),
            ("rename-box", "Renomear pelo conteúdo", "Data, tipo, número, entidade", win.rename_files),
        ]
        for i, (ic, t1, t2, fn) in enumerate(tiles):
            bt = QToolButton()
            bt.setObjectName("Tile")
            bt.setIcon(theme.icon(ic, theme.colors()["accent"]))
            bt.setIconSize(QSize(28, 28))
            bt.setText(f"{t1}\n{t2}")
            bt.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            bt.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            bt.setMinimumHeight(64)
            bt.clicked.connect(fn)
            grid.addWidget(bt, i // 4, i % 4)
        outer.addLayout(grid)
        outer.addStretch()
        foot = QLabel(f"Ventura Rodrigues · versão {APP_VERSION}")
        foot.setObjectName("Muted")
        outer.addWidget(foot)

    def refresh(self, files: list[str]):
        self.recent.clear()
        for f in files:
            if Path(f).exists():
                it = QListWidgetItem(theme.icon("file-pdf-box"), Path(f).name)
                it.setToolTip(f)
                it.setData(Qt.UserRole, f)
                self.recent.addItem(it)
        if not self.recent.count():
            it = QListWidgetItem("Ainda sem ficheiros recentes")
            it.setFlags(Qt.NoItemFlags)
            self.recent.addItem(it)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1360, 860)
        self.setAcceptDrops(True)
        st = dialogs.settings()
        if st.value("author"):
            annot.AUTHOR = st.value("author")
        central = QWidget()
        cl = QVBoxLayout(central)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(0)
        self.ribbon = Ribbon(self)
        cl.addWidget(self.ribbon)
        self.props = ToolProps(self._props_changed)
        self.props.hide()
        cl.addWidget(self.props)
        self.docs = QTabWidget()
        self.docs.setObjectName("Docs")
        self.docs.setTabsClosable(True)
        self.docs.setMovable(True)
        self.docs.setDocumentMode(True)
        self.docs.tabCloseRequested.connect(self.close_tab)
        self.docs.currentChanged.connect(self._tab_changed)
        self.start = StartPage(self)
        cl.addWidget(self.docs)
        cl.addWidget(self.start)
        self.setCentralWidget(central)
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.page_lab = QLabel("")
        self.zoom_box = QComboBox()
        self.zoom_box.setEditable(True)
        self.zoom_box.addItems(["Largura", "Página inteira", "50 %", "75 %", "100 %", "125 %", "150 %", "200 %", "300 %"])
        self.zoom_box.setFixedWidth(130)
        self.zoom_box.activated.connect(self._zoom_box)
        self.zoom_box.lineEdit().returnPressed.connect(lambda: self._zoom_box(-1))
        self.page_jump = QSpinBox()
        self.page_jump.setRange(1, 1)
        self.page_jump.setPrefix("Pág. ")
        self.page_jump.editingFinished.connect(lambda: self.cur() and self.cur().view.go_to_page(self.page_jump.value() - 1))
        self.status.addPermanentWidget(self.page_jump)
        self.status.addPermanentWidget(self.page_lab)
        self.status.addPermanentWidget(self.zoom_box)
        self._build_ribbon()
        self._shortcuts()
        self._tab_changed()
        QTimer.singleShot(2500, self._auto_check_updates)

    # ------------------------------------------------------------------ friso
    def _build_ribbon(self):
        r = self.ribbon
        p = r.page("Início")
        r.group(p, "Ficheiro", [
            ("open", "Abrir", "folder-open", self.open_dialog, "Abrir PDF (Ctrl+O)"),
            ("save", "Guardar", "content-save", self.save, "Guardar (Ctrl+S)"),
            ("saveas", "Guardar como", "content-save-edit", self.save_as, "Guardar como (Ctrl+Shift+S)"),
            ("print", "Imprimir", "printer", self.print_doc, "Imprimir (Ctrl+P)"),
        ])
        r.group(p, "Alterações", [
            ("undo", "Anular", "undo", lambda: self.cur() and self.cur().undo(), "Anular (Ctrl+Z)"),
            ("redo", "Refazer", "redo", lambda: self.cur() and self.cur().redo(), "Refazer (Ctrl+Y)"),
        ])
        r.group(p, "Ferramenta", [
            ("t_select", "Selecionar", "cursor-text", lambda: self.set_tool(pv.SELECT), "Selecionar texto e anotações", True),
            ("t_hand", "Mão", "hand-back-right", lambda: self.set_tool(pv.HAND), "Mover a página", True),
        ])
        r.group(p, "Ver", [
            ("zoomout", "Reduzir", "magnify-minus", lambda: self.cur() and self.cur().view.zoom_out(), "Ctrl + roda do rato"),
            ("zoomin", "Ampliar", "magnify-plus", lambda: self.cur() and self.cur().view.zoom_in(), "Ctrl + roda do rato"),
            ("fitw", "Largura", "arrow-expand-horizontal", lambda: self._fit("width"), "Ajustar à largura"),
            ("fitp", "Página", "fullscreen", lambda: self._fit("page"), "Página inteira"),
            ("search", "Pesquisar", "text-search", lambda: self.cur() and self.cur().show_search(), "Pesquisar (Ctrl+F)"),
        ])
        r.group(p, "Aspeto", [
            ("dark", "Modo escuro", "weather-night", self.toggle_dark, "Alternar modo claro/escuro"),
        ])

        p = r.page("Converter")
        r.group(p, "De PDF para", [
            ("to_word", "Word", "file-word", lambda: self.convert_current("word"), "PDF para Word (.docx)"),
            ("to_excel", "Excel", "file-excel", lambda: self.convert_current("excel"), "PDF para Excel (.xlsx)"),
            ("to_ppt", "PowerPoint", "file-powerpoint", lambda: self.convert_current("pptx"), "PDF para PowerPoint"),
            ("to_img", "Imagens", "file-image", lambda: self.convert_current("images"), "Páginas para PNG/JPG"),
            ("to_txt", "Texto", "text-box-outline", lambda: self.convert_current("text"), "PDF para texto"),
            ("ext_img", "Extrair imagens", "image-multiple", self.extract_images, "Guardar as imagens do PDF"),
        ])
        r.group(p, "Para PDF", [
            ("office", "Office", "microsoft-office", self.office_to_pdf, "Word, Excel ou PowerPoint para PDF"),
            ("imgs", "Imagens", "image-plus", self.images_to_pdf, "Juntar imagens num PDF"),
            ("photos", "Fotos de documentos", "camera-document", self.photos_to_pdf, "Fotos do telemóvel para PDF, com recorte e correção"),
        ])
        r.group(p, "OCR", [
            ("ocr", "Tornar pesquisável", "text-recognition", self.ocr_current, "Reconhecer o texto de digitalizações"),
            ("ocr_word", "Digitalização para Word", "file-word-box", self.ocr_word, "OCR e conversão para Word"),
        ])

        p = r.page("Editar")
        r.group(p, "Texto", [
            ("t_edit", "Editar texto", "format-text", lambda: self.set_tool(pv.EDIT_TEXT), "Alterar texto existente", True),
            ("t_addtext", "Adicionar texto", "text-box-plus", lambda: self.set_tool(pv.ADD_TEXT), "Nova caixa de texto", True),
            ("findrepl", "Localizar e substituir", "find-replace", self.find_replace, "Substituir um texto em todo o documento"),
        ])
        r.group(p, "Imagens", [
            ("t_image", "Inserir imagem", "image-plus", self.pick_image_tool, "Inserir imagem ou logótipo", True),
            ("t_moveimg", "Mover imagem", "image-move", lambda: self.set_tool(pv.MOVE_IMAGE), "Mover ou redimensionar uma imagem", True),
        ])
        r.group(p, "Tapar e rasurar", [
            ("t_white", "Tapar", "eraser", lambda: self.set_tool(pv.WHITEOUT), "Cobrir com branco ou cor", True),
            ("t_redact", "Rasurar área", "marker", lambda: self.set_tool(pv.REDACT), "Apagar definitivamente o conteúdo", True),
            ("redact_search", "Rasurar por texto", "shield-lock-outline", self.redact_search, "Rasurar nomes, NIF, IBAN, emails…"),
        ])
        r.group(p, "Página", [
            ("hf", "Cabeçalho e rodapé", "page-layout-header-footer", self.header_footer, "Numeração, data, referência"),
            ("wm", "Marca d'água", "water", self.watermark, "Texto ou imagem em todas as páginas"),
        ])

        p = r.page("Páginas")
        r.group(p, "Ficheiros", [
            ("merge", "Juntar", "file-document-multiple", self.merge, "Juntar vários PDFs"),
            ("split", "Dividir", "scissors-cutting", self.split, "Dividir este PDF"),
            ("compress", "Comprimir", "zip-box", self.compress, "Reduzir o tamanho do ficheiro"),
        ])
        r.group(p, "Páginas selecionadas", [
            ("rot_r", "Rodar", "rotate-right", lambda: self._pages_op("rotate", 90), "Rodar 90° à direita"),
            ("rot_l", "Rodar esq.", "rotate-left", lambda: self._pages_op("rotate", -90), "Rodar 90° à esquerda"),
            ("dup", "Duplicar", "content-copy", lambda: self._pages_op("dup"), "Duplicar páginas"),
            ("del", "Apagar", "delete", lambda: self._pages_op("del"), "Apagar páginas"),
            ("extract", "Extrair", "file-export", lambda: self._pages_op("extract"), "Guardar páginas num novo PDF"),
        ])
        r.group(p, "Inserir", [
            ("blank", "Em branco", "file-plus", lambda: self._pages_op("blank"), "Página em branco a seguir"),
            ("insfile", "De outro PDF", "file-import", lambda: self._pages_op("insfile"), "Inserir páginas de outro PDF"),
        ])

        p = r.page("Rever")
        r.group(p, "Texto", [
            ("t_hl", "Realçar", "format-color-highlight", lambda: self.set_tool(pv.HIGHLIGHT), "Realçar texto", True),
            ("t_ul", "Sublinhar", "format-underline", lambda: self.set_tool(pv.UNDERLINE), "Sublinhar texto", True),
            ("t_st", "Riscar", "format-strikethrough", lambda: self.set_tool(pv.STRIKE), "Riscar texto", True),
            ("t_note", "Nota", "note-text", lambda: self.set_tool(pv.NOTE), "Nota tipo post-it", True),
        ])
        r.group(p, "Desenho", [
            ("t_draw", "Desenho livre", "draw", lambda: self.set_tool(pv.DRAW), "Desenhar à mão", True),
            ("t_rect", "Retângulo", "rectangle-outline", lambda: self.set_tool(pv.RECT), "Retângulo", True),
            ("t_ell", "Elipse", "ellipse-outline", lambda: self.set_tool(pv.ELLIPSE), "Elipse", True),
            ("t_arrow", "Seta", "arrow-top-right", lambda: self.set_tool(pv.ARROW), "Seta", True),
            ("t_line", "Linha", "vector-line", lambda: self.set_tool(pv.LINE), "Linha", True),
            ("t_cloud", "Nuvem", "cloud-outline", lambda: self.set_tool(pv.CLOUD), "Nuvem de revisão", True),
        ])
        r.group(p, "Aprovação", [
            ("t_stamp", "Carimbo", "stamper", self.pick_stamp, "Aprovado, Revisto, Para Execução…", True),
            ("compare", "Comparar versões", "file-compare", self.compare, "Diferenças entre duas versões"),
        ])

        p = r.page("Formulários e assinatura")
        r.group(p, "Formulários", [
            ("fill", "Preencher", "form-textbox", self.fill_form, "Preencher os campos do PDF"),
            ("t_field", "Criar campo", "form-textbox-password", lambda: self.set_tool(pv.FIELD), "Criar campo de formulário", True),
        ])
        r.group(p, "Assinar", [
            ("t_sig", "Assinatura", "signature-freehand", self.pick_signature, "Assinatura manuscrita (desenhada ou imagem)", True),
            ("dsign", "Assinatura digital", "card-account-details", self.digital_sign, "Cartão de Cidadão, Chave Móvel Digital ou certificado"),
            ("verify", "Verificar", "certificate", self.verify_signatures, "Verificar as assinaturas digitais"),
        ])

        p = r.page("Ferramentas")
        r.group(p, "Automação", [
            ("batch", "Lote", "layers-triple", self.batch, "A mesma operação em muitos ficheiros"),
            ("rename", "Renomear", "rename-box", self.rename_files, "Renomear PDFs pelo conteúdo"),
            ("proposta", "Proposta VR", "file-sign", self.proposta_vr, "Proposta de fornecedor para o layout Ventura Rodrigues"),
        ])
        r.group(p, "Segurança", [
            ("protect", "Proteger", "lock", self.protect, "Palavra-passe e permissões"),
            ("unprotect", "Remover palavra-passe", "lock-open-variant", self.unprotect, "Guardar sem palavra-passe"),
            ("meta", "Limpar metadados", "broom", self.clean_meta, "Remover autor, software e histórico"),
        ])
        r.group(p, "Programa", [
            ("update", "Atualizar", "update", self.check_updates, "Procurar e instalar a versão mais recente"),
            ("settings", "Definições", "cog", self.open_settings, "Modo escuro, botão direito, programa predefinido"),
        ])
        self.tool_buttons = {k: b for k, b in r.buttons.items() if k.startswith("t_")}
        self.tool_key = {pv.SELECT: "t_select", pv.HAND: "t_hand", pv.EDIT_TEXT: "t_edit", pv.ADD_TEXT: "t_addtext",
                         pv.IMAGE: "t_image", pv.MOVE_IMAGE: "t_moveimg", pv.WHITEOUT: "t_white",
                         pv.REDACT: "t_redact", pv.HIGHLIGHT: "t_hl", pv.UNDERLINE: "t_ul", pv.STRIKE: "t_st",
                         pv.NOTE: "t_note", pv.DRAW: "t_draw", pv.RECT: "t_rect", pv.ELLIPSE: "t_ell",
                         pv.ARROW: "t_arrow", pv.LINE: "t_line", pv.CLOUD: "t_cloud", pv.STAMP: "t_stamp",
                         pv.SIGNATURE: "t_sig", pv.FIELD: "t_field"}
        self.needs_doc = [k for k in r.buttons if k not in
                          ("open", "dark", "merge", "office", "imgs", "photos", "batch", "rename", "proposta",
                           "settings", "compare", "unprotect", "update")]

    def _shortcuts(self):
        for seq, fn in ((QKeySequence.Open, self.open_dialog), (QKeySequence.Save, self.save),
                        (QKeySequence("Ctrl+Shift+S"), self.save_as),
                        (QKeySequence.Print, self.print_doc),
                        (QKeySequence.Undo, lambda: self.cur() and self.cur().undo()),
                        (QKeySequence("Ctrl+Y"), lambda: self.cur() and self.cur().redo()),
                        (QKeySequence.Find, lambda: self.cur() and self.cur().show_search()),
                        (QKeySequence("Ctrl+W"), lambda: self.docs.count() and self.close_tab(self.docs.currentIndex())),
                        (QKeySequence("Ctrl++"), lambda: self.cur() and self.cur().view.zoom_in()),
                        (QKeySequence("Ctrl+="), lambda: self.cur() and self.cur().view.zoom_in()),
                        (QKeySequence("Ctrl+-"), lambda: self.cur() and self.cur().view.zoom_out()),
                        (QKeySequence("Ctrl+0"), lambda: self._fit("width")),
                        (QKeySequence(Qt.Key_Escape), lambda: self.set_tool(pv.SELECT)),
                        (QKeySequence("F11"), self._toggle_full)):
            s = QShortcut(seq, self)
            s.activated.connect(fn)

    def _toggle_full(self):
        self.showNormal() if self.isFullScreen() else self.showFullScreen()

    # ------------------------------------------------------------------ documentos
    def cur(self) -> DocWidget | None:
        w = self.docs.currentWidget()
        return w if isinstance(w, DocWidget) else None

    def require(self) -> DocWidget | None:
        d = self.cur()
        if d is None:
            QMessageBox.information(self, APP_NAME, "Abre primeiro um PDF.")
        return d

    def _tab_changed(self, *_):
        has = self.docs.count() > 0
        self.docs.setVisible(has)
        self.start.setVisible(not has)
        if not has:
            self.start.refresh(self.recent_files())
            self.props.hide()
        for k in self.needs_doc:
            self.ribbon.buttons[k].setEnabled(has)
        d = self.cur()
        if d:
            self.setWindowTitle(f"{d.title()} - {APP_NAME}")
            self._update_page(d.view.current_page(), d.doc.page_count)
            self._update_zoom(d.view.zoom)
            self._sync_tool_buttons(d.view.tool)
        else:
            self.setWindowTitle(APP_NAME)
            self.page_lab.setText("")

    def _update_page(self, n, total):
        self.page_jump.setRange(1, max(1, total))
        self.page_jump.setValue(n + 1)
        self.page_lab.setText(f"de {total}")

    def _update_zoom(self, z):
        self.zoom_box.setEditText(f"{round(z * 100)} %")

    def _zoom_box(self, idx):
        d = self.cur()
        if not d:
            return
        t = self.zoom_box.currentText()
        if t.startswith("Largura"):
            self._fit("width")
        elif t.startswith("Página"):
            self._fit("page")
        else:
            try:
                d.view.set_zoom(float(t.replace("%", "").strip().replace(",", ".")) / 100)
            except ValueError:
                pass

    def _fit(self, mode):
        d = self.cur()
        if d:
            d.view.fit_mode = mode
            d.view.apply_fit()

    def open_dialog(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Abrir", dialogs.settings().value("last_dir", str(Path.home())),
                                                "PDF (*.pdf);;Todos os ficheiros suportados (*.pdf *.docx *.doc *.xlsx *.xls *.pptx *.ppt *.png *.jpg *.jpeg *.tif *.tiff)")
        if files:
            dialogs.settings().setValue("last_dir", str(Path(files[0]).parent))
            self.open_files(files)

    def open_files(self, files: list[str]):
        images = []
        for f in files:
            p = Path(f)
            ext = p.suffix.lower()
            if ext in OPENABLE:
                self.open_pdf(str(p))
            elif ext in IMAGES:
                images.append(str(p))
            elif ext in convert.OFFICE_EXT:
                run_task(self, f"A converter {p.name} para PDF", convert.office_to_pdf, str(p), progress=False,
                         on_done=lambda res: self.open_pdf(str(res)))
        if images:
            self.photos_to_pdf(images, scanner=False)

    def open_pdf(self, path: str):
        p = Path(path)
        for i in range(self.docs.count()):
            w = self.docs.widget(i)
            if isinstance(w, DocWidget) and w.path and w.path.resolve() == p.resolve():
                self.docs.setCurrentIndex(i)
                return w
        pw = None
        while True:
            try:
                d = DocWidget(str(p), password=pw)
                break
            except PermissionError:
                pw, ok = QInputDialog.getText(self, "Palavra-passe", f"{p.name} está protegido. Palavra-passe:",
                                              QLineEdit.Password)
                if not ok:
                    return None
            except Exception as e:
                QMessageBox.warning(self, "Não foi possível abrir", f"{p.name}\n\n{e}")
                return None
        self._wire(d)
        i = self.docs.addTab(d, theme.icon("file-pdf-box"), d.title())
        self.docs.setTabToolTip(i, str(p))
        self.docs.setCurrentIndex(i)
        self.add_recent(str(p))
        d.view.set_tool(pv.SELECT)
        self._apply_tool_opts(d)
        return d

    def _wire(self, d: DocWidget):
        d.changed.connect(lambda dd=d: self._doc_changed(dd))
        d.status.connect(lambda m: self.status.showMessage(m, 6000))
        d.pageInfo.connect(lambda n, t, dd=d: self.cur() is dd and self._update_page(n, t))
        d.view.zoomChanged.connect(lambda z, dd=d: self.cur() is dd and self._update_zoom(z))

    def _doc_changed(self, d):
        i = self.docs.indexOf(d)
        if i >= 0:
            self.docs.setTabText(i, d.title())
            if d.path:
                self.docs.setTabToolTip(i, str(d.path))
        if d is self.cur():
            self.setWindowTitle(f"{d.title()} - {APP_NAME}")

    def close_tab(self, i) -> bool:
        d = self.docs.widget(i)
        if isinstance(d, DocWidget) and d.dirty:
            r = QMessageBox.question(self, "Alterações por guardar",
                                     f"Guardar as alterações em {d.path.name if d.path else 'Sem nome'}?",
                                     QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            if r == QMessageBox.Cancel:
                return False
            if r == QMessageBox.Save and not self._save_doc(d):
                return False
        self.docs.removeTab(i)
        d.deleteLater()
        return True

    def closeEvent(self, e):
        while self.docs.count():
            if not self.close_tab(0):
                e.ignore()
                return
        e.accept()

    def _save_doc(self, d: DocWidget, as_new=False) -> bool:
        if as_new or d.path is None:
            start = str(d.path) if d.path else str(Path.home() / "Documento.pdf")
            f, _ = QFileDialog.getSaveFileName(self, "Guardar como", start, "PDF (*.pdf)")
            if not f:
                return False
            ok = d.save(f)
            if ok:
                self.add_recent(f)
            return ok
        return d.save()

    def save(self):
        d = self.cur()
        if d:
            self._save_doc(d)

    def save_as(self):
        d = self.cur()
        if d:
            self._save_doc(d, True)

    def print_doc(self):
        d = self.require()
        if not d:
            return
        from PySide6.QtPrintSupport import QPrinter, QPrintDialog
        from PySide6.QtGui import QPainter, QImage
        printer = QPrinter(QPrinter.HighResolution)
        printer.setDocName(d.path.name if d.path else "Documento")
        printer.setFromTo(1, d.doc.page_count)
        dlg = QPrintDialog(printer, self)
        dlg.setOption(QPrintDialog.PrintPageRange, True)
        dlg.setOption(QPrintDialog.PrintCurrentPage, True)
        dlg.setMinMax(1, d.doc.page_count)
        if not dlg.exec():
            return
        if printer.printRange() == QPrinter.PageRange:
            pages = list(range(printer.fromPage() - 1, printer.toPage()))
        elif printer.printRange() == QPrinter.CurrentPage:
            pages = [d.view.current_page()]
        else:
            pages = list(range(d.doc.page_count))
        dpi = min(300, printer.resolution())
        painter = QPainter()
        if not painter.begin(printer):
            QMessageBox.warning(self, "Imprimir", "Não foi possível iniciar a impressão.")
            return
        try:
            for k, pno in enumerate(pages):
                if k:
                    printer.newPage()
                page = d.doc[pno]
                pix = page.get_pixmap(dpi=dpi, alpha=False, annots=True)
                img = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGB888)
                area = painter.viewport()
                size = img.size()
                size.scale(area.size(), Qt.KeepAspectRatio)
                x = area.x() + (area.width() - size.width()) // 2
                y = area.y() + (area.height() - size.height()) // 2
                painter.setViewport(x, y, size.width(), size.height())
                painter.setWindow(img.rect())
                painter.drawImage(0, 0, img)
                painter.setViewport(area)
                painter.setWindow(area)
                self.status.showMessage(f"A imprimir página {k + 1} de {len(pages)}…")
                QApplication.processEvents()
        finally:
            painter.end()
        self.status.showMessage("Enviado para a impressora", 6000)

    def recent_files(self) -> list[str]:
        v = dialogs.settings().value("recent", [])
        return [v] if isinstance(v, str) else list(v or [])

    def add_recent(self, path):
        r = [p for p in self.recent_files() if p != path]
        r.insert(0, path)
        dialogs.settings().setValue("recent", r[:15])

    # ------------------------------------------------------------------ arrastar e largar
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        files = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        pdfs = [f for f in files if f.lower().endswith(".pdf")]
        d = self.cur()
        if d and len(pdfs) == len(files) and pdfs and e.position().y() > 120:
            m = QMenu(self)
            a_open = m.addAction("Abrir em separadores")
            a_ins = m.addAction("Inserir no fim deste documento")
            a_merge = m.addAction("Juntar num novo PDF…")
            ch = m.exec(self.mapToGlobal(e.position().toPoint()))
            if ch is a_ins:
                d.snapshot()
                for f in pdfs:
                    organize.insert_from_file(d.doc, f, d.doc.page_count)
                d.after_change(None, f"{len(pdfs)} ficheiro(s) inserido(s)")
                return
            if ch is a_merge:
                self.merge(pdfs)
                return
            if ch is not a_open:
                return
        self.open_files(files)

    # ------------------------------------------------------------------ ferramentas de rato
    def set_tool(self, tool: str | None):
        d = self.cur()
        if tool is None:
            tool = pv.SELECT
        if not d:
            self._sync_tool_buttons(pv.SELECT)
            return
        d.view.set_tool(tool)
        self._apply_tool_opts(d)
        title, hint = TOOL_INFO.get(tool, ("", ""))
        self.props.show_for(tool, title, hint)
        self._sync_tool_buttons(tool)
        self.status.showMessage(hint, 8000)

    def _sync_tool_buttons(self, tool):
        key = self.tool_key.get(tool)
        for k, b in self.tool_buttons.items():
            b.setChecked(k == key)

    def _props_changed(self, what):
        if what is None:
            self.set_tool(pv.SELECT)
            return
        d = self.cur()
        if d:
            self._apply_tool_opts(d)

    def _apply_tool_opts(self, d):
        d.view.tool_options.update(self.props.values())

    def pick_image_tool(self):
        d = self.require()
        if not d:
            return
        f, _ = QFileDialog.getOpenFileName(self, "Escolher imagem", "", dialogs.IMG_FILTER)
        if not f:
            self._sync_tool_buttons(d.view.tool)
            return
        self.set_tool(pv.IMAGE)
        d.view.tool_options["image_path"] = f

    def pick_stamp(self):
        d = self.require()
        if not d:
            return
        dlg = dialogs.StampDialog(self)
        if not dlg.exec():
            self._sync_tool_buttons(d.view.tool)
            return
        self.set_tool(pv.STAMP)
        d.view.tool_options.update(stamp=dlg.text.currentText(), stamp_color=dlg.color.color,
                                   stamp_sub=dlg.sub.text() or None, stamp_width=dlg.width.value())

    def pick_signature(self):
        d = self.require()
        if not d:
            return
        dlg = dialogs.SignatureDialog(self)
        if not dlg.exec():
            self._sync_tool_buttons(d.view.tool)
            return
        self.set_tool(pv.SIGNATURE)
        d.view.tool_options["signature"] = dlg.chosen

    # ------------------------------------------------------------------ conversões
    def _doc_source(self, d: DocWidget) -> tuple[str, bool]:
        """Caminho de um ficheiro com o estado atual do documento (grava temporário se houver alterações)."""
        if d.path and not d.dirty and not d.password:
            return str(d.path), False
        import tempfile
        tmp = Path(tempfile.gettempdir()) / f"vrpdf_{os.getpid()}_{id(d)}.pdf"
        d.doc.save(tmp, garbage=1)
        return str(tmp), True

    def convert_current(self, kind):
        d = self.require()
        if not d:
            return
        src, _ = self._doc_source(d)
        base = str(d.path) if d.path else src
        dlg = dialogs.ConvertDialog(self, kind, base, d.doc.page_count)
        if not dlg.exec():
            return
        pages = parse_page_ranges(dlg.pages.text(), d.doc.page_count) if dlg.pages.text().strip() else None
        out = dlg.out.text()
        open_after = dlg.open_after.isChecked()

        def done(res):
            files = res if isinstance(res, list) else [res]
            if open_after and files:
                open_path(files[0] if kind != "images" else Path(files[0]).parent)
            else:
                result_box(self, "Conversão concluída", f"{len(files)} ficheiro(s) criado(s).", files)

        if kind == "word":
            run_task(self, "A converter para Word", convert.pdf_to_word, src, out, pages, on_done=done)
        elif kind == "excel":
            run_task(self, "A converter para Excel", convert.pdf_to_excel, src, out, pages, on_done=done)
        elif kind == "pptx":
            run_task(self, "A converter para PowerPoint", convert.pdf_to_pptx, src, out, pages, on_done=done)
        elif kind == "images":
            run_task(self, "A exportar imagens", convert.pdf_to_images, src, out, dlg.fmt.currentText().lower(),
                     dlg.dpi.value(), pages, on_done=done)
        elif kind == "text":
            run_task(self, "A exportar texto", convert.pdf_to_text, src, out, progress=False, on_done=done)

    def quick_word(self):
        self._quick_file(lambda f: run_task(self, "A converter para Word", convert.pdf_to_word, f,
                                            on_done=lambda r: open_path(r)))

    def quick_excel(self):
        self._quick_file(lambda f: run_task(self, "A converter para Excel", convert.pdf_to_excel, f,
                                            on_done=lambda r: open_path(r)))

    def quick_compress(self):
        def go(f):
            dlg = dialogs.CompressDialog(self, Path(f).stat().st_size)
            if dlg.exec():
                run_task(self, "A comprimir", organize.compress, f, None, dlg.value(), progress=False,
                         on_done=self._compress_done)
        self._quick_file(go)

    def _quick_file(self, fn):
        f, _ = QFileDialog.getOpenFileName(self, "Escolher PDF", dialogs.settings().value("last_dir", ""), "PDF (*.pdf)")
        if f:
            fn(f)

    def extract_images(self):
        d = self.require()
        if not d:
            return
        src, _ = self._doc_source(d)
        out = None
        if d.path:
            out = str(d.path.parent / f"{d.path.stem} - imagens extraídas")
        run_task(self, "A extrair imagens", convert.extract_images, src, out,
                 on_done=lambda r: result_box(self, "Imagens extraídas", f"{len(r)} imagem(ns) guardada(s).", r))

    def office_to_pdf(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Documentos Office", "",
                                                "Office (*.docx *.doc *.rtf *.odt *.xlsx *.xls *.xlsm *.ods *.pptx *.ppt *.odp *.txt)")
        if not files:
            return

        def work(progress=None):
            out = []
            for i, f in enumerate(files):
                if progress:
                    progress(i, len(files), Path(f).name)
                out.append(convert.office_to_pdf(f))
            return out

        run_task(self, "A converter para PDF", work,
                 on_done=lambda r: (self.open_pdf(str(r[0])) if len(r) == 1 else
                                    result_box(self, "Conversão concluída", f"{len(r)} PDF criados.", r)))

    def images_to_pdf(self):
        self.photos_to_pdf(None, scanner=False)

    def photos_to_pdf(self, initial=None, scanner=True):
        if initial is None:
            initial = []
        dlg = dialogs.PhotosDialog(self, scanner, initial if isinstance(initial, list) else [])
        if not dlg.exec():
            return
        files = dlg.files.files()
        if not files:
            return
        out = dlg.out.text()
        if scanner:
            mode = ["cor", "cinza", "pb"][dlg.mode.currentIndex()]

            def done(res):
                path, n = res
                self.open_pdf(str(path))
                if dlg.crop.isChecked() and n < len(files):
                    self.status.showMessage(f"Folha detetada em {n} de {len(files)} fotos. As restantes ficaram inteiras.", 10000)

            run_task(self, "A criar PDF a partir das fotos", scan.photos_to_pdf, files, out, mode,
                     dlg.crop.isChecked(), dlg.a4.isChecked(), on_done=done)
        else:
            run_task(self, "A criar PDF", convert.images_to_pdf, files, out, "A4" if dlg.a4.isChecked() else "auto",
                     10 if dlg.a4.isChecked() else 0, on_done=lambda r: self.open_pdf(str(r)))

    def ocr_current(self):
        d = self.require()
        if not d:
            return
        if not convert.ocr_available():
            QMessageBox.information(self, "OCR", "O OCR precisa do Tesseract com o idioma português.\n\n"
                                    "Instala o «Tesseract OCR» (UB Mannheim) e escolhe o idioma Portuguese, "
                                    "ou volta a correr o COMPILAR.bat que o instala automaticamente.")
            return
        src, _ = self._doc_source(d)
        dst = str(out_path(d.path or src, ".pdf", "(OCR)"))
        run_task(self, "A reconhecer o texto (OCR)", convert.ocr_pdf, src, dst, on_done=lambda r: self.open_pdf(str(r)))

    def ocr_word(self):
        d = self.require()
        if not d:
            return
        if not convert.ocr_available():
            self.ocr_current()
            return
        src, _ = self._doc_source(d)
        dst = str(out_path(d.path or src, ".docx", "(OCR)"))
        run_task(self, "Digitalização para Word", convert.ocr_to_word, src, dst, on_done=lambda r: open_path(r))

    # ------------------------------------------------------------------ edição
    def find_replace(self):
        d = self.require()
        if not d:
            return
        dlg = dialogs.FindReplaceDialog(self)
        if d.view.selected_text and "\n" not in d.view.selected_text:
            dlg.find.setText(d.view.selected_text)
        if not dlg.exec() or not dlg.find.text():
            return
        n = d.apply_doc_op(lambda doc: edit.find_and_replace(doc, dlg.find.text(), dlg.repl.text()),
                           "Texto substituído", structural=False)
        if n is not None:
            self.status.showMessage(f"{n} ocorrência(s) substituída(s)", 8000)
            if n == 0:
                QMessageBox.information(self, "Localizar e substituir", "Não encontrei esse texto.")

    def redact_search(self):
        d = self.require()
        if not d:
            return
        dlg = dialogs.RedactSearchDialog(self)
        if not dlg.exec():
            return

        def op(doc):
            n = 0
            if dlg.text.text().strip():
                n += edit.redact_text(doc, dlg.text.text().strip())
            for k, c in dlg.pats.items():
                if c.isChecked():
                    n += edit.redact_pattern(doc, edit.REDACT_PATTERNS[k])
            return n

        n = d.apply_doc_op(op, "Rasurado", structural=False)
        if n is not None:
            QMessageBox.information(self, "Rasurar", f"{n} ocorrência(s) rasurada(s). Guarda o ficheiro para as tornar definitivas.")

    def header_footer(self):
        d = self.require()
        if not d:
            return
        dlg = dialogs.HeaderFooterDialog(self, d.doc.page_count)
        if not dlg.exec():
            return
        pages = parse_page_ranges(dlg.pages.text(), d.doc.page_count) if dlg.pages.text().strip() else None
        kw = {k: v.text() for k, v in dlg.f.items()}
        d.apply_doc_op(lambda doc: edit.header_footer(doc, **kw, size=dlg.size.value(), color=dlg.color.color,
                                                      margin_mm=dlg.margin.value(), family=dlg.font.currentText(),
                                                      pages=pages, start_number=dlg.start.value(),
                                                      filename=d.path.name if d.path else ""),
                       "Cabeçalho e rodapé aplicados", structural=False)

    def watermark(self):
        d = self.require()
        if not d:
            return
        dlg = dialogs.WatermarkDialog(self)
        if not dlg.exec():
            return
        pages = parse_page_ranges(dlg.pages.text(), d.doc.page_count) if dlg.pages.text().strip() else None
        op = dlg.opacity.value() / 100
        if dlg.tabs.currentIndex() == 1:
            if not dlg.img.text():
                return
            d.apply_doc_op(lambda doc: edit.watermark_image(doc, dlg.img.text(), op, dlg.scale.value() / 100, pages),
                           "Marca d'água aplicada", structural=False)
        else:
            d.apply_doc_op(lambda doc: edit.watermark_text(doc, dlg.text.currentText(), dlg.size.value(),
                                                           dlg.color.color, op, dlg.angle.value(), pages=pages),
                           "Marca d'água aplicada", structural=False)

    # ------------------------------------------------------------------ páginas
    def _pages_op(self, op, arg=None):
        d = self.require()
        if not d:
            return
        pages = d.selected_pages()
        if op == "rotate":
            d.rotate(pages, arg)
        elif op == "dup":
            d.duplicate(pages)
        elif op == "del":
            d.delete_pages(pages)
        elif op == "extract":
            d.extract(pages)
        elif op == "blank":
            d.insert_blank(pages[-1] + 1)
        elif op == "insfile":
            d.insert_file(pages[-1] + 1)

    def merge(self, initial=None):
        if not isinstance(initial, list):
            initial = []
            d = self.cur()
            if d and d.path and not d.dirty:
                initial = [str(d.path)]
        dlg = dialogs.MergeDialog(self, initial)
        if not dlg.exec():
            return
        files = dlg.files.files()
        if len(files) < 2:
            QMessageBox.information(self, "Juntar", "Escolhe pelo menos dois ficheiros.")
            return
        run_task(self, "A juntar PDFs", organize.merge, files, dlg.out.text(), dlg.bookmarks.isChecked(),
                 on_done=lambda r: self.open_pdf(str(r)))

    def split(self):
        d = self.require()
        if not d:
            return
        dlg = dialogs.SplitDialog(self, d.doc.page_count)
        if not dlg.exec():
            return
        mode, val = dlg.values()
        src, tmp = self._doc_source(d)
        out_dir = str(d.path.parent) if d.path else None

        def work():
            res = organize.split(src, mode, val, out_dir)
            if tmp and d.path:
                # nomes com base no ficheiro original
                fixed = []
                for p in res:
                    new = p.with_name(p.name.replace(Path(src).stem, d.path.stem))
                    p.rename(new)
                    fixed.append(new)
                return fixed
            return res

        run_task(self, "A dividir", work, progress=False,
                 on_done=lambda r: result_box(self, "Dividido", f"{len(r)} ficheiro(s) criado(s).", r))

    def compress(self):
        d = self.require()
        if not d:
            return
        src, _ = self._doc_source(d)
        dlg = dialogs.CompressDialog(self, Path(src).stat().st_size)
        if not dlg.exec():
            return
        dst = str(out_path(d.path or src, ".pdf", "(comprimido)"))
        run_task(self, "A comprimir", organize.compress, src, dst, dlg.value(), progress=False,
                 on_done=self._compress_done)

    def _compress_done(self, res):
        p, before, after = res
        pct = 100 * (1 - after / before) if before else 0
        result_box(self, "Comprimido", f"{before / 1048576:.2f} MB para {after / 1048576:.2f} MB "
                                       f"({pct:.0f} % mais pequeno).", [p])

    # ------------------------------------------------------------------ rever
    def compare(self):
        d = self.cur()
        dlg = dialogs.CompareDialog(self, str(d.path) if d and d.path else None)
        if not dlg.exec() or not dlg.old.text() or not dlg.new.text():
            return

        def done(res):
            path, st = res
            self.open_pdf(str(path))
            self.status.showMessage(f"{st['paginas_alteradas']} página(s) com diferenças: {st['removidas']} palavras "
                                    f"saíram, {st['acrescentadas']} entraram.", 15000)

        run_task(self, "A comparar", compare.compare, dlg.old.text(), dlg.new.text(), progress=False, on_done=done)

    # ------------------------------------------------------------------ formulários e assinatura
    def fill_form(self):
        d = self.require()
        if d:
            d.side.setCurrentIndex(2)

    def digital_sign(self):
        d = self.require()
        if not d:
            return
        dlg = dialogs.DigitalSignDialog(self, d.doc.page_count, d.view.current_page())
        if not dlg.exec():
            return
        src, _ = self._doc_source(d)
        if dlg.r_cmd.isChecked():
            if d.dirty:
                QMessageBox.information(self, "Chave Móvel Digital", "Guarda primeiro o documento.")
                return
            if not sign.open_in_autenticacao_gov(src):
                QMessageBox.information(self, "Chave Móvel Digital",
                                        "Não encontrei a aplicação Autenticação.gov. Instala-a em www.autenticacao.gov.pt; "
                                        "a assinatura com Chave Móvel Digital é feita dentro dessa aplicação.")
            return
        base = d.path or Path(src)
        dst, _ = QFileDialog.getSaveFileName(self, "Guardar documento assinado",
                                             str(base.with_name(base.stem + " (assinado).pdf")), "PDF (*.pdf)")
        if not dst:
            return
        n = dlg.page.value() - 1
        rect = dlg.rect_for(d.doc[n].rect)
        reason, loc = dlg.reason.currentText(), dlg.location.text()
        if dlg.r_pfx.isChecked():
            run_task(self, "A assinar", sign.sign_with_pfx, src, dst, dlg.pfx.text(), dlg.pfx_pw.text(), n, rect,
                     reason, loc, progress=False, on_done=lambda r: self.open_pdf(str(r)))
        else:
            run_task(self, "A assinar com o Cartão de Cidadão", sign.sign_with_cc, src, dst, n, rect, reason, loc,
                     progress=False, on_done=lambda r: self.open_pdf(str(r)))

    def verify_signatures(self):
        d = self.require()
        if not d:
            return
        src, _ = self._doc_source(d)
        try:
            res = sign.verify_signatures(src)
        except Exception as e:
            QMessageBox.warning(self, "Verificar assinaturas", str(e))
            return
        if not res:
            QMessageBox.information(self, "Verificar assinaturas", "Este documento não tem assinaturas digitais.")
            return
        lines = []
        for r in res:
            if "erro" in r:
                lines.append(f"• {r['campo']}: não foi possível verificar ({r['erro'][:120]})")
            else:
                estado = "documento intacto desde a assinatura" if r["intacto"] else "DOCUMENTO ALTERADO depois de assinado"
                lines.append(f"• {r['assinante']}\n   {estado}; data: {r['data']}")
        QMessageBox.information(self, "Assinaturas digitais", "\n\n".join(lines))

    # ------------------------------------------------------------------ ferramentas
    def batch(self, initial=None):
        dlg = dialogs.BatchDialog(self, initial if isinstance(initial, list) else [])
        if not dlg.exec():
            return
        files = dlg.files.files()
        if not files:
            return
        op = dlg.op.currentText()
        out_dir = dlg.out.text().strip() or None

        def done(res):
            created, errors = res
            msg = f"{len(created)} ficheiro(s) criado(s)."
            if errors:
                msg += f"\n\n{len(errors)} com problemas:\n" + "\n".join(f"• {Path(f).name}: {e[:100]}" for f, e in errors[:8])
            result_box(self, "Lote concluído", msg, created)

        run_task(self, f"Lote: {op}", batch.run, op, files, out_dir, dlg.options(), on_done=done)

    def rename_files(self):
        dlg = dialogs.RenameDialog(self)
        if not dlg.exec():
            return
        pairs = dlg.pairs()
        # fechar separadores destes ficheiros para os poder renomear
        try:
            res = rename.apply(pairs)
        except Exception as e:
            QMessageBox.warning(self, "Renomear", str(e))
            return
        result_box(self, "Renomeados", f"{len(res)} ficheiro(s) renomeado(s).", res)

    def proposta_vr(self):
        f, _ = QFileDialog.getOpenFileName(self, "Proposta do fornecedor (PDF)", dialogs.settings().value("last_dir", ""), "PDF (*.pdf)")
        if not f:
            return
        try:
            p = proposta_vr.parse_supplier_pdf(f)
        except Exception as e:
            QMessageBox.warning(self, "Proposta VR", f"Não consegui ler a proposta.\n\n{e}")
            return
        dlg = dialogs.PropostaDialog(self, p)
        if not dlg.exec():
            return
        p = dlg.result()
        safe = "".join(c for c in (p.numero or "Proposta") if c not in '\\/:*?"<>|')
        cliente = "".join(c for c in (p.cliente_curto or p.cliente or "Cliente") if c not in '\\/:*?"<>|')
        default = Path(f).parent / f"{safe} - {cliente} - Ventura Rodrigues.docx"
        dst, _ = QFileDialog.getSaveFileName(self, "Guardar proposta", str(default), "Word (*.docx)")
        if not dst:
            return
        try:
            out = proposta_vr.build_docx(p, dst)
        except Exception as e:
            QMessageBox.warning(self, "Proposta VR", f"Não consegui criar a proposta.\n\n{e}")
            return
        open_path(out)

    def protect(self):
        d = self.require()
        if not d:
            return
        dlg = dialogs.ProtectDialog(self)
        if not dlg.exec():
            return
        base = d.path or Path.home() / "Documento.pdf"
        dst, _ = QFileDialog.getSaveFileName(self, "Guardar protegido", str(base.with_name(base.stem + " (protegido).pdf")), "PDF (*.pdf)")
        if not dst:
            return
        security.save_encrypted(d.doc, dst, dlg.pw.text(), "", dlg.allow_print.isChecked(),
                                dlg.allow_copy.isChecked(), dlg.allow_edit.isChecked())
        result_box(self, "Protegido", "Documento guardado com palavra-passe.", [dst])

    def unprotect(self):
        d = self.cur()
        if d and d.password:
            base = d.path
            dst, _ = QFileDialog.getSaveFileName(self, "Guardar sem palavra-passe", str(base.with_name(base.stem + " (sem palavra-passe).pdf")), "PDF (*.pdf)")
            if dst:
                d.doc.save(dst, encryption=pymupdf.PDF_ENCRYPT_NONE, garbage=3, deflate=True)
                result_box(self, "Palavra-passe removida", "Guardado sem palavra-passe.", [dst])
            return
        f, _ = QFileDialog.getOpenFileName(self, "PDF protegido", "", "PDF (*.pdf)")
        if not f:
            return
        pw, ok = QInputDialog.getText(self, "Palavra-passe", "Palavra-passe atual:", QLineEdit.Password)
        if not ok:
            return
        try:
            out = security.remove_password(f, pw, str(out_path(f, ".pdf", "(sem palavra-passe)")))
        except Exception as e:
            QMessageBox.warning(self, "Remover palavra-passe", str(e))
            return
        result_box(self, "Palavra-passe removida", "Guardado sem palavra-passe.", [out])

    def clean_meta(self):
        d = self.require()
        if not d:
            return
        before = security.metadata(d.doc)
        d.apply_doc_op(security.clean_metadata, "Metadados removidos", structural=False)
        info = "\n".join(f"• {k}: {v}" for k, v in before.items() if k not in ("format", "encryption")) or "• (nenhum)"
        QMessageBox.information(self, "Metadados", f"Removidos:\n{info}\n\nGuarda o ficheiro para concluir.")

    def open_settings(self):
        dlg = dialogs.SettingsDialog(self)
        if dlg.exec():
            st = dialogs.settings()
            if st.value("author"):
                annot.AUTHOR = st.value("author")
            if st.value("dark", False, type=bool) != theme.is_dark():
                self.toggle_dark(save=False)

    # ------------------------------------------------------------------ atualizações
    def _auto_check_updates(self):
        """Verificação silenciosa no arranque (no máximo uma vez por dia)."""
        import datetime as _d
        from ..core import updater
        st = dialogs.settings()
        fail = updater.last_failure()
        if fail:
            updater.revert()
            QMessageBox.warning(self, "Atualização", "A última atualização não arrancou e o VR PDF voltou à versão "
                                "anterior. Envia esta mensagem ao Claude:\n\n" + fail[-800:])
        today = _d.date.today().isoformat()
        if st.value("upd_last") == today:
            return
        st.setValue("upd_last", today)
        from PySide6.QtCore import QThread, QObject, Signal as _Sig

        class W(QObject):
            done = _Sig(object)

            def run(self):
                try:
                    self.done.emit(updater.check())
                except Exception:
                    self.done.emit(None)

        self._upd_thread = QThread()
        self._upd_worker = W()
        self._upd_worker.moveToThread(self._upd_thread)
        self._upd_thread.started.connect(self._upd_worker.run)

        def got(info):
            self._upd_thread.quit()
            if info and info.get("nova"):
                b = self.ribbon.buttons["update"]
                b.setText(f"Atualizar\n({info['versao']})")
                b.setStyleSheet(f"QToolButton {{ color: {theme.colors()['accent']}; font-weight: 600; }}")
                self.status.showMessage(f"Há uma versão nova do VR PDF ({info['versao']}). Ferramentas > Atualizar.", 20000)

        self._upd_worker.done.connect(got)
        self._upd_thread.start()

    def check_updates(self):
        from ..core import updater
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
            info = updater.check()
        except Exception as e:
            QMessageBox.warning(self, "Atualizar", f"Não consegui contactar o site das atualizações. Confirma a ligação à internet.\n\n{e}")
            return
        finally:
            QApplication.restoreOverrideCursor()
        if not info.get("nova"):
            QMessageBox.information(self, "Atualizar", f"Já tens a versão mais recente ({APP_VERSION}).")
            return
        notas = "\n".join(f"• {n}" for n in info.get("notas", [])) or "• Melhorias e correções."
        if info.get("precisa_exe"):
            QMessageBox.information(self, "Atualizar",
                                    f"A versão {info['versao']} precisa de uma instalação nova (traz bibliotecas novas).\n\n"
                                    f"{notas}\n\nDescarrega a pasta nova e corre o COMPILAR.bat.")
            return
        r = QMessageBox.question(self, "Atualizar",
                                 f"Versão instalada: {APP_VERSION}\nVersão nova: {info['versao']}\n\nO que muda:\n{notas}\n\n"
                                 "Atualizar agora? O VR PDF reinicia sozinho no fim.",
                                 QMessageBox.Yes | QMessageBox.No)
        if r != QMessageBox.Yes:
            return

        def done(_):
            # fecha os documentos (pergunta se houver alterações) e reinicia
            while self.docs.count():
                if not self.close_tab(0):
                    QMessageBox.information(self, "Atualizar", "Atualização instalada. Fica ativa quando voltares a abrir o VR PDF.")
                    return
            updater.restart()
            QApplication.instance().quit()

        run_task(self, "A atualizar o VR PDF", updater.install, info, on_done=done)

    def toggle_dark(self, save=True):
        dark = not theme.is_dark()
        theme.apply(QApplication.instance(), dark)
        if save is not False:
            dialogs.settings().setValue("dark", dark)
        self.ribbon.recolor()
        for i in range(self.docs.count()):
            w = self.docs.widget(i)
            if isinstance(w, DocWidget):
                w.recolor()
                w.view.relayout()
            self.docs.setTabIcon(i, theme.icon("file-pdf-box"))
        # recria a página inicial com as cores novas
        lay = self.centralWidget().layout()
        old = self.start
        self.start = StartPage(self)
        lay.replaceWidget(old, self.start)
        old.deleteLater()
        self._tab_changed()
