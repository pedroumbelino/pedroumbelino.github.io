"""Janelas de diálogo das ferramentas."""
from __future__ import annotations

import datetime as dt
import io
from pathlib import Path

from PySide6.QtCore import Qt, QPointF, QSize, Signal, QDate, QSettings
from PySide6.QtGui import QPainter, QPen, QColor, QImage, QPainterPath, QPixmap, QFont, QIcon
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit, QComboBox,
                               QPushButton, QDialogButtonBox, QListWidget, QListWidgetItem, QFileDialog, QSpinBox,
                               QDoubleSpinBox, QCheckBox, QRadioButton, QButtonGroup, QGroupBox, QWidget,
                               QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView, QPlainTextEdit,
                               QColorDialog, QMessageBox, QSlider, QAbstractItemView, QDateEdit, QGridLayout,
                               QSizePolicy, QToolButton)

from . import theme

PDF_FILTER = "PDF (*.pdf)"
IMG_FILTER = "Imagens (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp *.heic)"


def settings() -> QSettings:
    return QSettings("Ventura Rodrigues", "VR PDF")


def _buttons(dlg, ok_text="OK"):
    bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    bb.button(QDialogButtonBox.Ok).setText(ok_text)
    bb.button(QDialogButtonBox.Ok).setObjectName("Primary")
    bb.button(QDialogButtonBox.Cancel).setText("Cancelar")
    bb.accepted.connect(dlg.accept)
    bb.rejected.connect(dlg.reject)
    return bb


class ColorButton(QPushButton):
    def __init__(self, color="#C8302B"):
        super().__init__()
        self.setFixedWidth(46)
        self.set_color(color)
        self.clicked.connect(self._pick)

    def set_color(self, c):
        self.color = c
        self.setStyleSheet(f"QPushButton {{ background: {c}; border: 1px solid #888; border-radius: 5px; min-height: 20px; }}")

    def _pick(self):
        c = QColorDialog.getColor(QColor(self.color), self, "Cor")
        if c.isValid():
            self.set_color(c.name())


# ---------------------------------------------------------------- lista de ficheiros reutilizável
class FileList(QWidget):
    changed = Signal()

    def __init__(self, filt=PDF_FILTER, hint="Arrasta ficheiros para aqui ou usa Acrescentar."):
        super().__init__()
        self.filt = filt
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.list = QListWidget()
        self.list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.list.setDragDropMode(QAbstractItemView.InternalMove)
        self.list.setMinimumHeight(180)
        self.setAcceptDrops(True)
        self.list.setToolTip(hint)
        lay.addWidget(self.list, 1)
        col = QVBoxLayout()
        for text, ic, fn in (("Acrescentar…", "plus", self.add_dialog), ("Remover", "minus", self.remove),
                             ("Subir", "arrow-up", lambda: self.move(-1)), ("Descer", "arrow-down", lambda: self.move(1)),
                             ("Ordenar A-Z", "sort-alphabetical-ascending", self.sort)):
            b = QPushButton(theme.icon(ic), text)
            b.clicked.connect(fn)
            col.addWidget(b)
        col.addStretch()
        lay.addLayout(col)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        self.add([u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()])

    def add_dialog(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Escolher ficheiros", "", self.filt + ";;Todos (*.*)")
        self.add(files)

    def add(self, files):
        for f in files:
            if Path(f).is_dir():
                continue
            it = QListWidgetItem(Path(f).name)
            it.setToolTip(f)
            it.setData(Qt.UserRole, f)
            self.list.addItem(it)
        self.changed.emit()

    def remove(self):
        for it in self.list.selectedItems():
            self.list.takeItem(self.list.row(it))
        self.changed.emit()

    def move(self, d):
        r = self.list.currentRow()
        if r < 0 or not (0 <= r + d < self.list.count()):
            return
        it = self.list.takeItem(r)
        self.list.insertItem(r + d, it)
        self.list.setCurrentRow(r + d)
        self.changed.emit()

    def sort(self):
        self.list.sortItems()
        self.changed.emit()

    def files(self) -> list[str]:
        return [self.list.item(i).data(Qt.UserRole) for i in range(self.list.count())]


def _out_row(form: QFormLayout, label: str, default: str, filt: str, folder=False):
    w = QWidget()
    l = QHBoxLayout(w)
    l.setContentsMargins(0, 0, 0, 0)
    ed = QLineEdit(default)
    b = QPushButton("Escolher…")

    def pick():
        if folder:
            d = QFileDialog.getExistingDirectory(w, "Pasta de destino", ed.text() or str(Path.home()))
            if d:
                ed.setText(d)
        else:
            f, _ = QFileDialog.getSaveFileName(w, "Guardar como", ed.text(), filt)
            if f:
                ed.setText(f)

    b.clicked.connect(pick)
    l.addWidget(ed, 1)
    l.addWidget(b)
    form.addRow(label, w)
    return ed


# ---------------------------------------------------------------- converter
class ConvertDialog(QDialog):
    def __init__(self, parent, kind: str, src: str, page_count: int):
        super().__init__(parent)
        names = {"word": "Word (.docx)", "excel": "Excel (.xlsx)", "pptx": "PowerPoint (.pptx)",
                 "images": "imagens", "text": "texto (.txt)"}
        self.setWindowTitle(f"Converter para {names[kind]}")
        self.kind = kind
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.pages = QLineEdit()
        self.pages.setPlaceholderText(f"Todas (1-{page_count}). Ex.: 1-3, 5")
        form.addRow("Páginas", self.pages)
        ext = {"word": ".docx", "excel": ".xlsx", "pptx": ".pptx", "text": ".txt"}.get(kind)
        s = Path(src)
        if kind == "images":
            self.fmt = QComboBox()
            self.fmt.addItems(["PNG", "JPG"])
            self.dpi = QSpinBox()
            self.dpi.setRange(50, 600)
            self.dpi.setValue(200)
            self.dpi.setSuffix(" ppp")
            form.addRow("Formato", self.fmt)
            form.addRow("Resolução", self.dpi)
            self.out = _out_row(form, "Pasta", str(s.parent / f"{s.stem} - imagens"), "", folder=True)
        else:
            self.out = _out_row(form, "Guardar em", str(s.with_suffix(ext)), f"*{ext}")
        if kind == "word":
            note = QLabel("Os parágrafos, tabelas e imagens são reconstruídos no Word. Em PDFs digitalizados, "
                          "usa antes OCR > Digitalização para Word.")
        elif kind == "excel":
            note = QLabel("As tabelas de cada página passam para folhas separadas. Os valores com € e vírgula "
                          "ficam como números.")
        elif kind == "pptx":
            note = QLabel("Cada página fica um diapositivo em alta resolução. O texto da página vai para as notas.")
        else:
            note = QLabel("")
        note.setWordWrap(True)
        note.setObjectName("Muted")
        lay.addLayout(form)
        lay.addWidget(note)
        self.open_after = QCheckBox("Abrir o resultado no fim")
        self.open_after.setChecked(True)
        lay.addWidget(self.open_after)
        lay.addWidget(_buttons(self, "Converter"))
        self.resize(560, 10)


# ---------------------------------------------------------------- juntar
class MergeDialog(QDialog):
    def __init__(self, parent, initial: list[str] | None = None):
        super().__init__(parent)
        self.setWindowTitle("Juntar PDFs")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Os ficheiros são juntados por esta ordem. Arrasta para reordenar."))
        self.files = FileList()
        self.files.add(initial or [])
        lay.addWidget(self.files)
        form = QFormLayout()
        first = (initial or [str(Path.home() / "x.pdf")])[0]
        self.out = _out_row(form, "Guardar em", str(Path(first).parent / "PDF juntado.pdf"), PDF_FILTER)
        self.bookmarks = QCheckBox("Criar um marcador por ficheiro")
        self.bookmarks.setChecked(True)
        form.addRow("", self.bookmarks)
        lay.addLayout(form)
        lay.addWidget(_buttons(self, "Juntar"))
        self.resize(640, 420)


class SplitDialog(QDialog):
    def __init__(self, parent, page_count):
        super().__init__(parent)
        self.setWindowTitle("Dividir PDF")
        lay = QVBoxLayout(self)
        self.group = QButtonGroup(self)
        self.r_each = QRadioButton("Uma página por ficheiro")
        self.r_n = QRadioButton("A cada")
        self.n = QSpinBox()
        self.n.setRange(1, 9999)
        self.n.setValue(2)
        self.n.setSuffix(" páginas")
        self.r_ranges = QRadioButton("Por intervalos")
        self.ranges = QLineEdit()
        self.ranges.setPlaceholderText("Ex.: 1-3, 4-7, 8-")
        self.r_size = QRadioButton("Por tamanho máximo")
        self.size = QDoubleSpinBox()
        self.size.setRange(0.5, 500)
        self.size.setValue(10)
        self.size.setSuffix(" MB")
        for r in (self.r_each, self.r_n, self.r_ranges, self.r_size):
            self.group.addButton(r)
        self.r_ranges.setChecked(True)
        grid = QGridLayout()
        grid.addWidget(self.r_each, 0, 0, 1, 2)
        grid.addWidget(self.r_n, 1, 0)
        grid.addWidget(self.n, 1, 1)
        grid.addWidget(self.r_ranges, 2, 0)
        grid.addWidget(self.ranges, 2, 1)
        grid.addWidget(self.r_size, 3, 0)
        grid.addWidget(self.size, 3, 1)
        lay.addLayout(grid)
        lay.addWidget(QLabel(f"O documento tem {page_count} páginas. Os ficheiros ficam na mesma pasta."))
        lay.addWidget(_buttons(self, "Dividir"))

    def values(self):
        if self.r_each.isChecked():
            return "cada", 0
        if self.r_n.isChecked():
            return "n", self.n.value()
        if self.r_size.isChecked():
            return "tamanho", self.size.value()
        return "intervalos", self.ranges.text()


class CompressDialog(QDialog):
    def __init__(self, parent, size_bytes: int):
        super().__init__(parent)
        self.setWindowTitle("Comprimir PDF")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(f"Tamanho atual: {size_bytes / 1024 / 1024:.2f} MB"))
        self.level = QComboBox()
        self.level.addItems(["leve (melhor qualidade)", "média (recomendado para email)", "forte (ficheiro mais pequeno)"])
        self.level.setCurrentIndex(1)
        lay.addWidget(self.level)
        note = QLabel("Reduz a resolução das imagens e otimiza o ficheiro. O texto não perde qualidade.")
        note.setObjectName("Muted")
        note.setWordWrap(True)
        lay.addWidget(note)
        lay.addWidget(_buttons(self, "Comprimir"))

    def value(self):
        return ["leve", "média", "forte"][self.level.currentIndex()]


# ---------------------------------------------------------------- cabeçalho / rodapé / marca d'água
class HeaderFooterDialog(QDialog):
    def __init__(self, parent, page_count):
        super().__init__(parent)
        self.setWindowTitle("Cabeçalho, rodapé e numeração")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Marcadores: {n} = página, {total} = nº de páginas, {data} = hoje, {ficheiro} = nome do ficheiro"))
        grid = QGridLayout()
        self.f = {}
        for r, (row, label) in enumerate((("header", "Cabeçalho"), ("footer", "Rodapé"))):
            grid.addWidget(QLabel(f"<b>{label}</b>"), r * 2, 0, 1, 3)
            for c, pos in enumerate(("left", "center", "right")):
                ed = QLineEdit()
                ed.setPlaceholderText({"left": "Esquerda", "center": "Centro", "right": "Direita"}[pos])
                grid.addWidget(ed, r * 2 + 1, c)
                self.f[f"{row}_{pos}"] = ed
        self.f["footer_right"].setText("Página {n} de {total}")
        lay.addLayout(grid)
        form = QFormLayout()
        self.size = QDoubleSpinBox()
        self.size.setRange(5, 30)
        self.size.setValue(9)
        self.color = ColorButton("#333333")
        self.margin = QDoubleSpinBox()
        self.margin.setRange(2, 40)
        self.margin.setValue(10)
        self.margin.setSuffix(" mm")
        self.start = QSpinBox()
        self.start.setRange(0, 99999)
        self.start.setValue(1)
        self.pages = QLineEdit()
        self.pages.setPlaceholderText(f"Todas (1-{page_count}). Ex.: 2-")
        self.font = QComboBox()
        from ..core.edit import font_names
        self.font.addItems(font_names())
        form.addRow("Tipo de letra", self.font)
        form.addRow("Tamanho", self.size)
        form.addRow("Cor", self.color)
        form.addRow("Margem", self.margin)
        form.addRow("Primeiro número", self.start)
        form.addRow("Páginas", self.pages)
        lay.addLayout(form)
        lay.addWidget(_buttons(self, "Aplicar"))
        self.resize(620, 10)


class WatermarkDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Marca d'água")
        lay = QVBoxLayout(self)
        tabs = QTabWidget()
        t = QWidget()
        form = QFormLayout(t)
        self.text = QComboBox()
        self.text.setEditable(True)
        self.text.addItems(["RASCUNHO", "CÓPIA", "CONFIDENCIAL", "NÃO VÁLIDO PARA OBRA", "PRELIMINAR", "ANULADO"])
        self.size = QSpinBox()
        self.size.setRange(10, 200)
        self.size.setValue(70)
        self.color = ColorButton("#C8302B")
        self.angle = QSpinBox()
        self.angle.setRange(-90, 90)
        self.angle.setValue(45)
        self.angle.setSuffix("°")
        form.addRow("Texto", self.text)
        form.addRow("Tamanho", self.size)
        form.addRow("Cor", self.color)
        form.addRow("Ângulo", self.angle)
        tabs.addTab(t, "Texto")
        i = QWidget()
        f2 = QFormLayout(i)
        self.img = QLineEdit()
        b = QPushButton("Escolher imagem…")
        b.clicked.connect(lambda: self.img.setText(QFileDialog.getOpenFileName(self, "Imagem", "", IMG_FILTER)[0] or self.img.text()))
        f2.addRow("Imagem (ex.: logótipo)", self.img)
        f2.addRow("", b)
        self.scale = QSpinBox()
        self.scale.setRange(5, 100)
        self.scale.setValue(50)
        self.scale.setSuffix(" % da largura")
        f2.addRow("Tamanho", self.scale)
        tabs.addTab(i, "Imagem")
        self.tabs = tabs
        lay.addWidget(tabs)
        form2 = QFormLayout()
        self.opacity = QSlider(Qt.Horizontal)
        self.opacity.setRange(5, 100)
        self.opacity.setValue(18)
        self.op_lab = QLabel("18 %")
        self.opacity.valueChanged.connect(lambda v: self.op_lab.setText(f"{v} %"))
        row = QHBoxLayout()
        row.addWidget(self.opacity)
        row.addWidget(self.op_lab)
        form2.addRow("Opacidade", row)
        self.pages = QLineEdit()
        self.pages.setPlaceholderText("Todas")
        form2.addRow("Páginas", self.pages)
        lay.addLayout(form2)
        lay.addWidget(_buttons(self, "Aplicar"))


class FindReplaceDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Localizar e substituir texto")
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.find = QLineEdit()
        self.repl = QLineEdit()
        form.addRow("Localizar", self.find)
        form.addRow("Substituir por", self.repl)
        lay.addLayout(form)
        note = QLabel("Funciona melhor para palavras, datas, valores e nomes. A fonte usada é a mais próxima da original.")
        note.setObjectName("Muted")
        note.setWordWrap(True)
        lay.addWidget(note)
        lay.addWidget(_buttons(self, "Substituir tudo"))


class RedactSearchDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        from ..core.edit import REDACT_PATTERNS
        self.setWindowTitle("Rasurar por texto ou tipo de dado")
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.text = QLineEdit()
        self.text.setPlaceholderText("Ex.: nome de uma pessoa, morada, preço")
        form.addRow("Texto exato", self.text)
        lay.addLayout(form)
        box = QGroupBox("Ou rasurar automaticamente")
        bl = QVBoxLayout(box)
        self.pats = {}
        for k in REDACT_PATTERNS:
            c = QCheckBox(k)
            bl.addWidget(c)
            self.pats[k] = c
        lay.addWidget(box)
        warn = QLabel("A rasura é definitiva: o texto por baixo é apagado do ficheiro e não pode ser recuperado "
                      "depois de guardar.")
        warn.setWordWrap(True)
        lay.addWidget(warn)
        lay.addWidget(_buttons(self, "Rasurar"))


class ProtectDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Proteger com palavra-passe")
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.pw = QLineEdit()
        self.pw.setEchoMode(QLineEdit.Password)
        self.pw2 = QLineEdit()
        self.pw2.setEchoMode(QLineEdit.Password)
        form.addRow("Palavra-passe para abrir", self.pw)
        form.addRow("Repetir", self.pw2)
        lay.addLayout(form)
        self.allow_print = QCheckBox("Permitir imprimir")
        self.allow_print.setChecked(True)
        self.allow_copy = QCheckBox("Permitir copiar texto")
        self.allow_edit = QCheckBox("Permitir editar")
        for c in (self.allow_print, self.allow_copy, self.allow_edit):
            lay.addWidget(c)
        note = QLabel("Encriptação AES de 256 bits. Guarda a palavra-passe: não há forma de a recuperar.")
        note.setObjectName("Muted")
        note.setWordWrap(True)
        lay.addWidget(note)
        lay.addWidget(_buttons(self, "Proteger e guardar como…"))

    def accept(self):
        if not self.pw.text():
            QMessageBox.information(self, "Palavra-passe", "Escreve uma palavra-passe.")
            return
        if self.pw.text() != self.pw2.text():
            QMessageBox.information(self, "Palavra-passe", "As palavras-passe não coincidem.")
            return
        super().accept()


class FieldDialog(QDialog):
    def __init__(self, parent, n):
        super().__init__(parent)
        from ..core.forms import FIELD_TYPES
        self.setWindowTitle("Criar campo de formulário")
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.kind = QComboBox()
        self.kind.addItems([k for k in FIELD_TYPES if k != "Assinatura"])
        self.name = QLineEdit(f"campo_{n}")
        self.options = QLineEdit()
        self.options.setPlaceholderText("Opções separadas por ;  (só para lista pendente)")
        form.addRow("Tipo", self.kind)
        form.addRow("Nome", self.name)
        form.addRow("Opções", self.options)
        lay.addLayout(form)
        lay.addWidget(_buttons(self, "Criar"))

    def values(self):
        opts = [o.strip() for o in self.options.text().split(";") if o.strip()]
        return self.kind.currentText(), self.name.text().strip() or "campo", opts


# ---------------------------------------------------------------- assinatura manuscrita
class SignaturePad(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumSize(520, 200)
        self.strokes: list[list[QPointF]] = []
        self.setCursor(Qt.CrossCursor)
        self.color = QColor(20, 30, 90)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#FFFFFF"))
        p.setPen(QPen(QColor("#C9CED6"), 1, Qt.DashLine))
        y = self.height() * 0.72
        p.drawLine(20, int(y), self.width() - 20, int(y))
        p.setPen(QPen(self.color, 2.6, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        for s in self.strokes:
            if len(s) > 1:
                path = QPainterPath(s[0])
                for pt in s[1:]:
                    path.lineTo(pt)
                p.drawPath(path)

    def mousePressEvent(self, e):
        self.strokes.append([e.position()])
        self.update()

    def mouseMoveEvent(self, e):
        if self.strokes:
            self.strokes[-1].append(e.position())
            self.update()

    def clear(self):
        self.strokes = []
        self.update()

    def to_png(self) -> bytes | None:
        pts = [p for s in self.strokes for p in s]
        if len(pts) < 2:
            return None
        scale = 3
        img = QImage(self.width() * scale, self.height() * scale, QImage.Format_ARGB32)
        img.fill(Qt.transparent)
        p = QPainter(img)
        p.setRenderHint(QPainter.Antialiasing)
        p.scale(scale, scale)
        p.setPen(QPen(self.color, 2.6, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        for s in self.strokes:
            if len(s) > 1:
                path = QPainterPath(s[0])
                for pt in s[1:]:
                    path.lineTo(pt)
                p.drawPath(path)
        p.end()
        xs = [q.x() for q in pts]
        ys = [q.y() for q in pts]
        m = 6
        crop = img.copy(int((min(xs) - m) * scale), int((min(ys) - m) * scale),
                        int((max(xs) - min(xs) + 2 * m) * scale), int((max(ys) - min(ys) + 2 * m) * scale))
        from PySide6.QtCore import QBuffer, QByteArray, QIODevice
        ba = QByteArray()
        buf = QBuffer(ba)
        buf.open(QIODevice.WriteOnly)
        crop.save(buf, "PNG")
        return bytes(ba)


class SignatureDialog(QDialog):
    """Criar (desenhar, carregar imagem ou escrever) e escolher assinaturas guardadas."""

    def __init__(self, parent):
        super().__init__(parent)
        from ..core import sign
        self.sign = sign
        self.setWindowTitle("Assinatura manuscrita")
        self.chosen = None
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Escolhe uma assinatura guardada ou cria uma nova. Depois desenha um retângulo na página."))
        self.saved = QListWidget()
        self.saved.setViewMode(QListWidget.IconMode)
        self.saved.setIconSize(QSize(180, 70))
        self.saved.setMinimumHeight(110)
        self.saved.itemDoubleClicked.connect(lambda *_: self.accept())
        lay.addWidget(self.saved)
        tabs = QTabWidget()
        w1 = QWidget()
        l1 = QVBoxLayout(w1)
        self.pad = SignaturePad()
        l1.addWidget(self.pad)
        r = QHBoxLayout()
        b_clear = QPushButton("Limpar")
        b_clear.clicked.connect(self.pad.clear)
        b_save = QPushButton("Guardar desenho")
        b_save.clicked.connect(self.save_drawn)
        r.addWidget(b_clear)
        r.addStretch()
        r.addWidget(b_save)
        l1.addLayout(r)
        tabs.addTab(w1, "Desenhar")
        w2 = QWidget()
        l2 = QVBoxLayout(w2)
        l2.addWidget(QLabel("Fotografia ou digitalização da assinatura em papel branco. O fundo fica transparente."))
        b_img = QPushButton("Escolher imagem…")
        b_img.clicked.connect(self.load_image)
        l2.addWidget(b_img)
        l2.addStretch()
        tabs.addTab(w2, "Imagem")
        w3 = QWidget()
        l3 = QFormLayout(w3)
        self.typed = QLineEdit()
        self.typed.setPlaceholderText("Nome")
        self.typed_font = QComboBox()
        self.typed_font.addItems(["Segoe Script", "Lucida Handwriting", "Brush Script MT", "Ink Free", "Mistral"])
        b_t = QPushButton("Criar assinatura escrita")
        b_t.clicked.connect(self.save_typed)
        l3.addRow("Nome", self.typed)
        l3.addRow("Estilo", self.typed_font)
        l3.addRow("", b_t)
        tabs.addTab(w3, "Escrever")
        lay.addWidget(tabs)
        lay.addWidget(_buttons(self, "Usar a selecionada"))
        self.reload()
        self.resize(640, 520)

    def reload(self, select: Path | None = None):
        self.saved.clear()
        for p in self.sign.saved_signatures():
            it = QListWidgetItem(QIcon(str(p)), "")
            it.setData(Qt.UserRole, str(p))
            it.setToolTip(p.name)
            self.saved.addItem(it)
            if select and Path(select) == p:
                self.saved.setCurrentItem(it)
        if self.saved.count() and not self.saved.currentItem():
            self.saved.setCurrentRow(0)

    def save_drawn(self):
        data = self.pad.to_png()
        if not data:
            QMessageBox.information(self, "Assinatura", "Desenha a assinatura na área branca.")
            return
        p = self.sign.save_signature_png(data)
        self.pad.clear()
        self.reload(p)

    def load_image(self):
        f, _ = QFileDialog.getOpenFileName(self, "Imagem da assinatura", "", IMG_FILTER)
        if f:
            p = self.sign.save_signature_png(self.sign.clean_signature_image(f))
            self.reload(p)

    def save_typed(self):
        name = self.typed.text().strip()
        if not name:
            return
        f = QFont(self.typed_font.currentText(), 48)
        from PySide6.QtGui import QFontMetrics
        fm = QFontMetrics(f)
        w, h = fm.horizontalAdvance(name) + 40, fm.height() + 20
        img = QImage(w, h, QImage.Format_ARGB32)
        img.fill(Qt.transparent)
        p = QPainter(img)
        p.setRenderHint(QPainter.Antialiasing)
        p.setFont(f)
        p.setPen(QColor(20, 30, 90))
        p.drawText(20, fm.ascent() + 10, name)
        p.end()
        from PySide6.QtCore import QBuffer, QByteArray, QIODevice
        ba = QByteArray()
        buf = QBuffer(ba)
        buf.open(QIODevice.WriteOnly)
        img.save(buf, "PNG")
        self.reload(self.sign.save_signature_png(bytes(ba), "assinatura escrita"))

    def accept(self):
        it = self.saved.currentItem()
        if not it:
            QMessageBox.information(self, "Assinatura", "Cria ou escolhe uma assinatura.")
            return
        self.chosen = it.data(Qt.UserRole)
        super().accept()


class DigitalSignDialog(QDialog):
    def __init__(self, parent, page_count, current_page):
        super().__init__(parent)
        from ..core import sign
        self.setWindowTitle("Assinatura digital")
        lay = QVBoxLayout(self)
        self.method = QButtonGroup(self)
        self.r_cc = QRadioButton("Cartão de Cidadão (leitor de cartões)")
        self.r_cmd = QRadioButton("Chave Móvel Digital (abre na aplicação Autenticação.gov)")
        self.r_pfx = QRadioButton("Certificado digital em ficheiro (.pfx / .p12)")
        for r in (self.r_cc, self.r_cmd, self.r_pfx):
            self.method.addButton(r)
            lay.addWidget(r)
        self.r_cc.setChecked(True)
        cc_ok = sign.cc_pkcs11_lib() is not None
        if not cc_ok:
            w = QLabel("Não encontrei o middleware do Cartão de Cidadão. Instala a aplicação Autenticação.gov "
                       "para assinar com o cartão.")
            w.setWordWrap(True)
            w.setObjectName("Muted")
            lay.addWidget(w)
        self.pfx_box = QGroupBox("Certificado")
        pf = QFormLayout(self.pfx_box)
        self.pfx = QLineEdit()
        b = QPushButton("Escolher…")
        b.clicked.connect(lambda: self.pfx.setText(QFileDialog.getOpenFileName(self, "Certificado", "", "Certificados (*.pfx *.p12)")[0] or self.pfx.text()))
        row = QHBoxLayout()
        row.addWidget(self.pfx)
        row.addWidget(b)
        pf.addRow("Ficheiro", row)
        self.pfx_pw = QLineEdit()
        self.pfx_pw.setEchoMode(QLineEdit.Password)
        pf.addRow("Palavra-passe", self.pfx_pw)
        lay.addWidget(self.pfx_box)
        form = QFormLayout()
        self.reason = QComboBox()
        self.reason.setEditable(True)
        self.reason.addItems(["Aprovação", "Responsável técnico", "Concordo com o conteúdo", "Autor do documento"])
        self.location = QLineEdit(settings().value("local", "Laranjeiro"))
        self.page = QSpinBox()
        self.page.setRange(1, page_count)
        self.page.setValue(page_count)
        self.pos = QComboBox()
        self.pos.addItems(["Canto inferior direito", "Canto inferior esquerdo", "Centro em baixo", "Invisível"])
        form.addRow("Motivo", self.reason)
        form.addRow("Local", self.location)
        form.addRow("Página", self.page)
        form.addRow("Posição", self.pos)
        lay.addLayout(form)
        self.method.buttonToggled.connect(lambda *_: self.pfx_box.setVisible(self.r_pfx.isChecked()))
        self.pfx_box.setVisible(False)
        lay.addWidget(_buttons(self, "Assinar e guardar como…"))
        self.resize(560, 10)

    def rect_for(self, page_rect):
        import pymupdf
        w, h, m = 200, 60, 36
        W, H = page_rect.width, page_rect.height
        i = self.pos.currentIndex()
        if i == 3:
            return None
        x = W - m - w if i == 0 else m if i == 1 else (W - w) / 2
        return pymupdf.Rect(x, H - m - h, x + w, H - m)


class StampDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        from ..core.annot import STAMPS, stamp_png
        self.stamp_png = stamp_png
        self.STAMPS = STAMPS
        self.setWindowTitle("Carimbo")
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.text = QComboBox()
        self.text.setEditable(True)
        self.text.addItems(list(STAMPS))
        self.color = ColorButton(STAMPS["APROVADO"])
        self.text.currentTextChanged.connect(self._update)
        self.sub = QLineEdit()
        self.sub.setPlaceholderText("Por defeito: nome do utilizador e data de hoje")
        self.width = QSpinBox()
        self.width.setRange(60, 400)
        self.width.setValue(150)
        self.width.setSuffix(" pt")
        form.addRow("Texto", self.text)
        form.addRow("Cor", self.color)
        form.addRow("Linha de baixo", self.sub)
        form.addRow("Largura", self.width)
        lay.addLayout(form)
        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setMinimumHeight(90)
        lay.addWidget(self.preview)
        self.color.clicked.connect(lambda: self._update(self.text.currentText(), False))
        self.sub.textChanged.connect(lambda: self._update(self.text.currentText(), False))
        lay.addWidget(QLabel("Depois clica na página onde queres o carimbo."))
        lay.addWidget(_buttons(self, "Escolher"))
        self._update(self.text.currentText())

    def _update(self, t, set_color=True):
        if set_color and t.upper() in self.STAMPS:
            self.color.set_color(self.STAMPS[t.upper()])
        data = self.stamp_png(t or " ", self.color.color, self.sub.text() or None, scale=2)
        pm = QPixmap()
        pm.loadFromData(data)
        self.preview.setPixmap(pm.scaledToWidth(min(320, pm.width()), Qt.SmoothTransformation))


# ---------------------------------------------------------------- fotos / imagens para PDF
class PhotosDialog(QDialog):
    def __init__(self, parent, scanner=True, initial=None):
        super().__init__(parent)
        self.setWindowTitle("Fotos de documentos para PDF" if scanner else "Imagens para PDF")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Cada imagem fica uma página, por esta ordem."))
        self.files = FileList(IMG_FILTER)
        self.files.add(initial or [])
        lay.addWidget(self.files)
        form = QFormLayout()
        self.scanner = scanner
        if scanner:
            self.mode = QComboBox()
            self.mode.addItems(["Cor (melhorada)", "Tons de cinza", "Preto e branco (tipo fotocópia)"])
            self.crop = QCheckBox("Detetar a folha e corrigir a perspetiva")
            self.crop.setChecked(True)
            form.addRow("Modo", self.mode)
            form.addRow("", self.crop)
        self.a4 = QCheckBox("Páginas em A4")
        self.a4.setChecked(True)
        form.addRow("", self.a4)
        first = (initial or [str(Path.home() / "Documento.pdf")])[0]
        self.out = _out_row(form, "Guardar em", str(Path(first).parent / ("Digitalização.pdf" if scanner else "Imagens.pdf")), PDF_FILTER)
        lay.addLayout(form)
        lay.addWidget(_buttons(self, "Criar PDF"))
        self.resize(640, 460)


class CompareDialog(QDialog):
    def __init__(self, parent, current: str | None):
        super().__init__(parent)
        self.setWindowTitle("Comparar duas versões")
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.old = QLineEdit(current or "")
        self.new = QLineEdit()
        for label, ed in (("Versão antiga", self.old), ("Versão nova", self.new)):
            w = QWidget()
            l = QHBoxLayout(w)
            l.setContentsMargins(0, 0, 0, 0)
            b = QPushButton("Escolher…")
            b.clicked.connect(lambda _=False, e=ed: e.setText(QFileDialog.getOpenFileName(self, "PDF", "", PDF_FILTER)[0] or e.text()))
            l.addWidget(ed, 1)
            l.addWidget(b)
            form.addRow(label, w)
        lay.addLayout(form)
        note = QLabel("O resultado é um PDF com as duas versões lado a lado: a vermelho o que saiu, a verde o que entrou.")
        note.setWordWrap(True)
        note.setObjectName("Muted")
        lay.addWidget(note)
        lay.addWidget(_buttons(self, "Comparar"))
        self.resize(620, 10)


# ---------------------------------------------------------------- lote
class BatchDialog(QDialog):
    def __init__(self, parent, initial=None):
        super().__init__(parent)
        from ..core.batch import OPERATIONS
        self.setWindowTitle("Processamento em lote")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Arrasta os ficheiros (ou uma pasta inteira) e escolhe o que fazer a todos."))
        self.files = FileList("PDF e Office (*.pdf *.docx *.doc *.xlsx *.xls *.pptx *.ppt *.png *.jpg *.jpeg *.tif)")
        self.files.add(initial or [])
        b_folder = QPushButton(theme.icon("folder-open"), "Acrescentar pasta…")
        b_folder.clicked.connect(self.add_folder)
        lay.addWidget(self.files)
        lay.addWidget(b_folder)
        form = QFormLayout()
        self.op = QComboBox()
        self.op.addItems(list(OPERATIONS))
        self.op.currentTextChanged.connect(self._opt_visibility)
        form.addRow("Operação", self.op)
        self.opt_text = QLineEdit()
        self.opt_level = QComboBox()
        self.opt_level.addItems(["leve", "média", "forte"])
        self.opt_level.setCurrentIndex(1)
        self.opt_pw = QLineEdit()
        self.opt_pw.setEchoMode(QLineEdit.Password)
        self.l_text = QLabel("Texto")
        self.l_level = QLabel("Nível")
        self.l_pw = QLabel("Palavra-passe")
        form.addRow(self.l_text, self.opt_text)
        form.addRow(self.l_level, self.opt_level)
        form.addRow(self.l_pw, self.opt_pw)
        self.out = _out_row(form, "Pasta de destino", "", "", folder=True)
        self.out.setPlaceholderText("Vazio = na mesma pasta de cada ficheiro")
        lay.addLayout(form)
        lay.addWidget(_buttons(self, "Executar"))
        self._opt_visibility(self.op.currentText())
        self.resize(680, 520)

    def add_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Pasta")
        if d:
            exts = {".pdf", ".docx", ".doc", ".xlsx", ".xls", ".pptx", ".ppt", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}
            self.files.add(sorted(str(p) for p in Path(d).rglob("*") if p.suffix.lower() in exts))

    def _opt_visibility(self, op):
        txt = op in ("Numerar páginas", "Marca d'água", "Carimbar todas as páginas")
        defaults = {"Numerar páginas": "Página {n} de {total}", "Marca d'água": "CÓPIA",
                    "Carimbar todas as páginas": "APROVADO"}
        self.opt_text.setText(defaults.get(op, ""))
        for w in (self.opt_text, self.l_text):
            w.setVisible(txt)
        for w in (self.opt_level, self.l_level):
            w.setVisible(op == "Comprimir")
        for w in (self.opt_pw, self.l_pw):
            w.setVisible(op == "Proteger com palavra-passe")

    def options(self):
        return {"texto": self.opt_text.text(), "nivel": self.opt_level.currentText(), "password": self.opt_pw.text()}


# ---------------------------------------------------------------- renomear
class RenameDialog(QDialog):
    def __init__(self, parent, initial=None):
        super().__init__(parent)
        from ..core import rename
        self.rename = rename
        self.setWindowTitle("Renomear PDFs pelo conteúdo")
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        b_add = QPushButton(theme.icon("plus"), "Acrescentar PDFs…")
        b_add.clicked.connect(self.add)
        b_folder = QPushButton(theme.icon("folder-open"), "Pasta…")
        b_folder.clicked.connect(self.add_folder)
        top.addWidget(b_add)
        top.addWidget(b_folder)
        top.addStretch()
        lay.addLayout(top)
        form = QFormLayout()
        self.template = QComboBox()
        self.template.setEditable(True)
        self.template.addItems(["{data} {tipo} {numero} {entidade}", "{entidade} {tipo} {numero} {data}",
                                "{data} {entidade}", "{tipo} {numero}"])
        self.template.setCurrentText(settings().value("rename_template", "{data} {tipo} {numero} {entidade}"))
        self.template.currentTextChanged.connect(self.refresh)
        form.addRow("Modelo do nome", self.template)
        hint = QLabel("Campos: {data} (AAAA-MM-DD), {tipo}, {numero}, {entidade}, {nif}. Podes editar o novo nome na tabela.")
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        form.addRow("", hint)
        lay.addLayout(form)
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Nome atual", "Novo nome"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        lay.addWidget(self.table)
        self.paths: list[str] = []
        self.infos: dict[str, dict] = {}
        lay.addWidget(_buttons(self, "Renomear"))
        self.setAcceptDrops(True)
        self.add_paths(initial or [])
        self.resize(820, 520)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        self.add_paths([u.toLocalFile() for u in e.mimeData().urls()])

    def add(self):
        files, _ = QFileDialog.getOpenFileNames(self, "PDFs", "", PDF_FILTER)
        self.add_paths(files)

    def add_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Pasta")
        if d:
            self.add_paths(sorted(str(p) for p in Path(d).glob("*.pdf")))

    def add_paths(self, paths):
        for p in paths:
            if p.lower().endswith(".pdf") and p not in self.paths:
                self.paths.append(p)
                try:
                    self.infos[p] = self.rename.extract_info(p)
                except Exception:
                    self.infos[p] = {}
        self.refresh()

    def refresh(self):
        tpl = self.template.currentText()
        self.table.setRowCount(len(self.paths))
        for i, p in enumerate(self.paths):
            a = QTableWidgetItem(Path(p).name)
            a.setFlags(a.flags() & ~Qt.ItemIsEditable)
            a.setToolTip(p)
            new = self.rename.build_name(self.infos.get(p, {}), tpl) or Path(p).stem
            self.table.setItem(i, 0, a)
            self.table.setItem(i, 1, QTableWidgetItem(new + ".pdf"))

    def pairs(self):
        settings().setValue("rename_template", self.template.currentText())
        return [(p, self.table.item(i, 1).text().strip()) for i, p in enumerate(self.paths)]


# ---------------------------------------------------------------- proposta VR
class PropostaDialog(QDialog):
    def __init__(self, parent, proposta):
        super().__init__(parent)
        self.p = proposta
        self.setWindowTitle(f"Proposta Ventura Rodrigues a partir de {proposta.origem}")
        lay = QVBoxLayout(self)
        tabs = QTabWidget()
        lay.addWidget(tabs)
        # dados gerais
        g = QWidget()
        form = QFormLayout(g)
        self.cliente = QLineEdit(proposta.cliente or proposta.cliente_curto)
        self.cliente.setPlaceholderText("Nome completo do cliente (ex.: Agência Portuguesa do Ambiente)")
        self.numero = QLineEdit(proposta.numero)
        self.titulo = QPlainTextEdit("\n".join(proposta.titulo))
        self.titulo.setFixedHeight(64)
        self.subtitulo = QLineEdit(proposta.subtitulo)
        self.subtitulo.setPlaceholderText("Ex.: CÂMARA 2 (ADITAMENTO), SALA DE PESAGEM")
        self.local = QLineEdit(settings().value("local", proposta.local))
        self.data = QDateEdit(QDate(proposta.data.year, proposta.data.month, proposta.data.day))
        self.data.setCalendarPopup(True)
        self.data.setDisplayFormat("dd/MM/yyyy")
        self.validade = QSpinBox()
        self.validade.setRange(1, 365)
        self.validade.setValue(proposta.validade_dias)
        self.validade.setSuffix(" dias")
        self.reserva = QCheckBox("Incluir secção de reserva de propriedade")
        self.reserva.setChecked(proposta.reserva_propriedade)
        form.addRow("Cliente", self.cliente)
        form.addRow("N.º da proposta", self.numero)
        form.addRow("Título (capa)", self.titulo)
        form.addRow("Subtítulo (capa)", self.subtitulo)
        form.addRow("Local", self.local)
        form.addRow("Data", self.data)
        form.addRow("Validade", self.validade)
        form.addRow("", self.reserva)
        tabs.addTab(g, "Dados gerais")
        # textos
        t = QWidget()
        tf = QFormLayout(t)
        self.intro = QPlainTextEdit(proposta.introducao)
        self.nota_intro = QLineEdit(proposta.nota_introducao)
        self.obj = QPlainTextEdit(proposta.objectivo)
        self.nota_obj = QLineEdit(proposta.nota_objectivo)
        self.pag = QPlainTextEdit(proposta.pagamento)
        self.pag2 = QLineEdit(proposta.pagamento_2)
        for w in (self.intro, self.obj, self.pag):
            w.setFixedHeight(70)
        tf.addRow("Introdução (a seguir a «A presente proposta de VENTURA RODRIGUES…»)", self.intro)
        tf.addRow("Nota da introdução", self.nota_intro)
        tf.addRow("Objectivo", self.obj)
        tf.addRow("Nota do objectivo", self.nota_obj)
        tf.addRow("Condições de pagamento", self.pag)
        tf.addRow("", self.pag2)
        tabs.addTab(t, "Textos")
        # valores
        v = QWidget()
        vl = QVBoxLayout(v)
        mr = QHBoxLayout()
        mr.addWidget(QLabel("Margem sobre o preço do fornecedor"))
        self.margem = QDoubleSpinBox()
        self.margem.setRange(-50, 500)
        self.margem.setSuffix(" %")
        self.margem.setValue(float(settings().value("margem", 0)))
        self.margem.valueChanged.connect(self._recalc)
        mr.addWidget(self.margem)
        mr.addStretch()
        vl.addLayout(mr)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Designação", "Descrição", "Quant.", "Preço fornecedor (€)", "Preço VR (€)"])
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.itemChanged.connect(self._recalc)
        vl.addWidget(self.table)
        rr = QHBoxLayout()
        b_add = QPushButton(theme.icon("plus"), "Linha")
        b_add.clicked.connect(lambda: self._add_row())
        b_del = QPushButton(theme.icon("minus"), "Remover linha")
        b_del.clicked.connect(lambda: self.table.removeRow(self.table.currentRow()) or self._recalc())
        self.total_lab = QLabel()
        self.total_lab.setStyleSheet("font-weight: 700;")
        rr.addWidget(b_add)
        rr.addWidget(b_del)
        rr.addStretch()
        rr.addWidget(self.total_lab)
        vl.addLayout(rr)
        tabs.addTab(v, "Valores")
        self.base = [l.unitario for l in proposta.linhas]
        for l in proposta.linhas:
            self._add_row(l.designacao, l.descricao, l.quantidade, l.unitario)
        tabs.setCurrentIndex(0)
        lay.addWidget(_buttons(self, "Criar proposta em Word…"))
        self._recalc()
        self.resize(820, 600)

    def _add_row(self, des="Prestação de Serviços", desc="", q=1, u=0.0):
        self.table.blockSignals(True)
        r = self.table.rowCount()
        self.table.insertRow(r)
        qs = str(int(q)) if float(q).is_integer() else str(q)
        for c, val in enumerate((des, desc, qs, f"{u:.2f}".replace(".", ","), "")):
            it = QTableWidgetItem(val)
            if c == 4:
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(r, c, it)
        self.table.blockSignals(False)
        self._recalc()

    def _num(self, s, default=0.0):
        from ..core.extenso import parse_eur
        v = parse_eur(s or "")
        return default if v is None else v

    def _recalc(self, *_):
        from ..core.extenso import fmt_eur, euros
        self.table.blockSignals(True)
        f = 1 + self.margem.value() / 100
        total = 0.0
        for r in range(self.table.rowCount()):
            q = self._num(self.table.item(r, 2).text(), 1)
            u = self._num(self.table.item(r, 3).text())
            vr = round(u * f, 2)
            self.table.item(r, 4).setText(fmt_eur(vr))
            total += round(q * vr, 2)
        self.table.blockSignals(False)
        self.total_lab.setText(f"Total: {fmt_eur(total)} + IVA  ({euros(total)})")

    def result(self):
        from ..core.proposta_vr import Linha
        p = self.p
        p.cliente = self.cliente.text().strip()
        p.numero = self.numero.text().strip()
        p.titulo = [l.strip() for l in self.titulo.toPlainText().splitlines() if l.strip()]
        p.subtitulo = self.subtitulo.text().strip()
        p.local = self.local.text().strip() or "Laranjeiro"
        d = self.data.date()
        p.data = dt.date(d.year(), d.month(), d.day())
        p.validade_dias = self.validade.value()
        p.reserva_propriedade = self.reserva.isChecked()
        p.introducao = self.intro.toPlainText().strip()
        p.nota_introducao = self.nota_intro.text().strip()
        p.objectivo = self.obj.toPlainText().strip()
        p.nota_objectivo = self.nota_obj.text().strip()
        p.pagamento = self.pag.toPlainText().strip()
        p.pagamento_2 = self.pag2.text().strip()
        f = 1 + self.margem.value() / 100
        p.linhas = []
        for r in range(self.table.rowCount()):
            p.linhas.append(Linha(self.table.item(r, 0).text(), self.table.item(r, 1).text(),
                                  self._num(self.table.item(r, 2).text(), 1),
                                  round(self._num(self.table.item(r, 3).text()) * f, 2)))
        p.margem_pct = self.margem.value()
        st = settings()
        st.setValue("local", p.local)
        st.setValue("margem", self.margem.value())
        return p


# ---------------------------------------------------------------- definições
class SettingsDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        import sys
        from ..core import winshell
        self.winshell = winshell
        self.setWindowTitle("Definições")
        lay = QVBoxLayout(self)
        st = settings()
        form = QFormLayout()
        self.dark = QCheckBox("Modo escuro")
        self.dark.setChecked(st.value("dark", False, type=bool))
        self.author = QLineEdit(st.value("author", ""))
        self.author.setPlaceholderText("Nome que aparece nos comentários e carimbos")
        self.local = QLineEdit(st.value("local", "Laranjeiro"))
        form.addRow("", self.dark)
        form.addRow("Autor", self.author)
        form.addRow("Local (propostas e assinaturas)", self.local)
        lay.addLayout(form)
        box = QGroupBox("Windows")
        bl = QVBoxLayout(box)
        win = sys.platform == "win32"
        self.ctx = QCheckBox("Opções do VR PDF no menu do botão direito (Converter para Word, Juntar, Comprimir…)")
        self.ctx.setChecked(win and winshell.context_menu_installed())
        self.ctx.setEnabled(win)
        bl.addWidget(self.ctx)
        b_def = QPushButton(theme.icon("file-pdf-box"), "Usar o VR PDF para abrir PDFs…")
        b_def.setEnabled(win)
        b_def.clicked.connect(self.make_default)
        bl.addWidget(b_def)
        note = QLabel("O Windows pede sempre a confirmação final em Definições > Aplicações predefinidas.")
        note.setObjectName("Muted")
        note.setWordWrap(True)
        bl.addWidget(note)
        lay.addWidget(box)
        from ..core.convert import ocr_available
        ocr = QLabel("OCR: " + ("instalado e pronto" if ocr_available() else
                                "não encontrado. Instala o Tesseract OCR (UB Mannheim) com o idioma português."))
        ocr.setWordWrap(True)
        lay.addWidget(ocr)
        lay.addWidget(_buttons(self, "Guardar"))
        self.resize(560, 10)

    def make_default(self):
        try:
            self.winshell.register_pdf_handler()
            self.winshell.open_default_apps_settings()
            QMessageBox.information(self, "Programa predefinido",
                                    "Nas Definições do Windows que abriram, procura «.pdf» e escolhe «VR PDF».")
        except Exception as e:
            QMessageBox.warning(self, "Programa predefinido", str(e))

    def accept(self):
        st = settings()
        st.setValue("dark", self.dark.isChecked())
        st.setValue("author", self.author.text().strip())
        st.setValue("local", self.local.text().strip() or "Laranjeiro")
        import sys
        if sys.platform == "win32":
            try:
                if self.ctx.isChecked() and not self.winshell.context_menu_installed():
                    self.winshell.install_context_menu()
                elif not self.ctx.isChecked() and self.winshell.context_menu_installed():
                    self.winshell.uninstall_context_menu()
            except Exception as e:
                QMessageBox.warning(self, "Menu do botão direito", str(e))
        super().accept()
